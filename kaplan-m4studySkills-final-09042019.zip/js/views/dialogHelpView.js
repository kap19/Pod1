(function(){
    window.pageIntialized= false;
    $(document).ready(function(){
        window.bazingaApp.dialogHelpView = new  window.bazingaApp.views.dialogHelpView();
        window.bazingaApp.dialogHelpView.load();
    });
}());
