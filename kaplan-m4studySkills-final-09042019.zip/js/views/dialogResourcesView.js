(function(){
    window.pageIntialized= false;
    $(document).ready(function(){
        window.bazingaApp.dialogResourcesView = new  window.bazingaApp.views.dialogResourcesView();
        window.bazingaApp.dialogResourcesView.load();
    });
}());
