(function(){
    window.bazingaApp.views.homeView = window.bazingaApp.views.abstractModuleView.extend({
        
        loaded: function(){
            // Put page level JS here...
				
				var lockables = window.bazingaApp.models.navigation.getLockables();
				//console.log(lockables.g3);
				//console.log(lockables.g3.locked);
			
				/*if(lockables.g3.locked){
					$(".quizBtn").addClass("is-disabled");
				}*/
			
			function pathPrepare ($el) {
							var lineLength = $el[0].getTotalLength();
							$el.css("stroke-dasharray", lineLength);
							$el.css("stroke-dashoffset", lineLength);
							//$el.css("display","block");
						}

						var $homeLine = $("path#homeLine");
	
						// prepare SVG
						pathPrepare($homeLine);
	
						//var lineLength = $("path#line1")[0].getTotalLength();

						// init controller
						var controller = new ScrollMagic.Controller();

						//line 1
						var tween1 = new TimelineMax()
							.add(TweenMax.to($homeLine, 1, {strokeDashoffset: 0, ease:Linear.easeNone}))

						// build scene
						var scene1 = new ScrollMagic.Scene({triggerElement: "#homeLineTrigger", duration: 2800, tweenChanges: true})
										.setTween(tween1)
										//.addIndicators({name:"homeLine"}) // add indicators (requires plugin)
										.addTo(controller);
			
			new Vivus('welcomeTo', {duration: 100});
			new Vivus('homeDashes', {duration: 100});
			new Vivus('clock1', {duration: 100});
			new Vivus('clock2', {duration: 100});
			new Vivus('lock2', {duration: 100});
			new Vivus('clock3', {duration: 100});
			new Vivus('lock3', {duration: 100});
			new Vivus('clock4', {duration: 100});
			new Vivus('lock4', {duration: 100});
			
			console.log("course status:"+window.bazingaApp.models.api.getCourseCompletion());
                alreadyComplete = window.bazingaApp.models.navigation.getParam(1);

            if(window.bazingaApp.models.api.getCourseCompletion() == "completed" && alreadyComplete != "y"){
                window.bazingaApp.models.navigation.setParam1("y");
                window.location = "dialog-complete.html";
            }
			
			//auto play first time
			
			if (window.bazingaApp.models.navigation.getPageCount() == 1){
				$("audio")[0].play();
			}
			
			
        }
    });

    window.pageIntialized= false;
    $(document).ready(function(){
        window.bazingaApp.homeView = new  window.bazingaApp.views.homeView();
        window.bazingaApp.homeView.load();
    });
}());
