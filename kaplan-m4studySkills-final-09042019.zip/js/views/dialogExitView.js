(function(){
    window.pageIntialized= false;
    $(document).ready(function(){
        window.bazingaApp.dialogExitView = new  window.bazingaApp.views.dialogExitView();
        window.bazingaApp.dialogExitView.load();
    });
}());
