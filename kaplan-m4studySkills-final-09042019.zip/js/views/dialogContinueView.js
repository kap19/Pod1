(function(){
    window.pageIntialized= false;
    $(document).ready(function(){
        window.bazingaApp.dialogContinueView = new  window.bazingaApp.views.dialogContinueView();
        window.bazingaApp.dialogContinueView.load();
    });
}());
