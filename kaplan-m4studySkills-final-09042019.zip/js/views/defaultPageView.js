(function(){
    window.bazingaApp.views.defaultPageView = window.bazingaApp.views.abstractModuleView.extend({
        
        loaded: function(){
			var self = this;
            // JS here
			
			$(".flipBtn").flip();
			
			$(".flipBtn").on('click', function (event) {
				$(this).off(".flip");
				$(this).find(".back").show();
			});
			
			$(".flipBtn").on('touchend', function (event) {
				$(this).off(".flip");
				$(this).find(".front").hide();
				$(this).find(".back").css("backface-visibility","visible");
				$(this).find(".back img").css("backface-visibility","visible");
				$(this).find(".back").css("opacity",100).show();
			});
			
			//same height
			$(window).resize(function(){
				
				var tallest = 0;
				//console.log("get height");
				
				$(".sameHeight:visible").each(function(i, obj) {
					
					$(".sameHeight:visible").css("height","auto");
					
					console.log($(this).outerHeight());
					
					if($(this).outerHeight() > tallest ){
						tallest = $(this).outerHeight();
					}
					
					});
				
				$(".sameHeight:visible").css("height",tallest+"px");
				
			});
			
        }

    });

    window.pageIntialized= false;
    $(document).ready(function(){
        window.bazingaApp.defaultPageView = new  window.bazingaApp.views.defaultPageView();
        window.bazingaApp.defaultPageView.load();
    });
}());
