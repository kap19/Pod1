(function(){
    window.bazingaApp.views.dialogCompleteView = window.bazingaApp.views.abstractModuleView.extend({
        loaded: function(){
			
            var currentScore = window.bazingaApp.models.api.getPrimaryScore() || 0;
			
			window.bazingaApp.models.navigation.setParam1("y");

            /*console.log("CURRENT SCORE "+currentScore);

            if(currentScore >= 80){
                //window.bazingaApp.models.api.set
                $('.final-feedback-caf').show();
                $('.final-feedback-waf').hide();
                window.bazingaApp.models.api.setCourseScore(currentScore);
                window.bazingaApp.models.api.setPageCompletion('completed');
            }
            else{
                $('.final-feedback-waf').show();
                $('final-feedback-caf').hide();
            }*/

        }
    });

    window.pageIntialized= false;
    $(document).ready(function(){
        window.bazingaApp.dialogCompleteView = new  window.bazingaApp.views.dialogCompleteView();
        window.bazingaApp.dialogCompleteView.load();
    });
}());
