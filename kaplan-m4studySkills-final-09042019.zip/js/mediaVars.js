var media = {
   usedWidth: 100, //this adds space to the right, increase it if using like a transcript button
   test:'#aaaaaa'
};