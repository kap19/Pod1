
$( document ).ready(function() {

	/*if($("#checkTopicComplete").hasClass("is-completed")){
				console.log("topic complete - show all");
				$(".pageBlock").show();
			}*/


	
										});