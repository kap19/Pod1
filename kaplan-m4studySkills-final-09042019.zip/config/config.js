var offlineConfig ={
    "title": "Kaplan Study M4",
    "navigation": {
        "src": "" },
    "launchPage": "home.html",
    "defaultHome" : "11",
    "allow_continue_after_complete":true,
    "finishPage": "complete.html",
    "language":"en",
    "popup": false,
    "popupWidth":"1020",
    "popupHeight":"688",
    "debug": true,
    "default_continue": "dcon",
    "default_complete": "dcom",
    "last_updated" : "2015-08-22T13:00:00.511Z",
    "completion": {
        "status": "passed-completed"
    },
    "accessibilityVersion" : 2 
}