var offlineNav ={
    "pages": [{
            "id": "dcom",
            "type": "dialog",
            "resource": "dialog-complete.html",
            "title": "Dialog Complete",
            "visibility": {
                "breadcrumbs": false,
                "menu": false
            },
            "track": {
                "data": false,
                "completion": false,
                "score": false,
				"mark_course_complete_on_enter": true
            },

            "role": {
                "default": {
                    "nav": {}
                }
            }
        }, {
            "id": "dcon",
            "type": "dialog",
            "resource": "dialog-continue.html",
            "track": {
                "data": false,
                "completion": false,
                "score": false
            },
            "title": "Dialog Continue",
            "visibility": {
                "breadcrumbs": false,
                "menu": false
            },
            "role": {
                "default": {
                    "nav": {
                        "resume": "currentScreen",
                        "home": "11"
                    }
                }
            }
        }, {
            "id": "dh",
            "type": "dialog",
            "resource": "dialog-help.html",
            "track": {
                "data": false,
                "completion": false,
                "score": false
            },
            "title": "Dialog Help",
            "visibility": {
                "breadcrumbs": false,
                "menu": false
            },
            "role": {
                "default": {
                    "nav": {
                        "resume": "currentScreen"
                    }
                }
            }
        }, {
            "id": "dex",
            "type": "dialog",
            "resource": "dialog-exit.html",
            "track": {
                "data": false,
                "completion": false,
                "score": false
            },
            "title": "Dialog Exit",
            "visibility": {
                "breadcrumbs": false,
                "menu": false
            },
            "role": {
                "default": {
                    "nav": {
                        "resume": "currentScreen"
                    }
                }
            }
        }, {
            "id": "dr",
            "type": "dialog",
            "resource": "dialog-resources.html",
            "track": {
                "data": false,
                "completion": false,
                "score": false
            },
            "title": "Resources",
            "visibility": {
                "breadcrumbs": false,
                "menu": false
            },
            "role": {
                "default": {
                    "nav": {
                        "resume": "currentScreen"
                    }
                }
            }
        }, 
			  {
                "id": "home",
                "type": "page",
                "resource": "home.html",
                "track": {
                    "data": false,
                    "count":false,
                    "completion": false,
                    "score": false
                },
                "title": "dummy home",
                "visibility": {
                    "breadcrumbs": true,
                    "menu": false
                },
                "role": {
                     "default": {
                        "nav": {
                        }
                    }
                }
            },
			  {
                "id": "11",
                "type": "page",
                "resource": "home.html?p=1",
                "track": {
                    "data": false,
                    "count":false,
                    "completion": true,
                    "score": false
                },
                "title": "Preparing for online study",
                "visibility": {
                    "breadcrumbs": true,
                    "menu": true
                },
                "role": {
                     "default": {
                        "nav": {
                            "next":12
                        }
                    }
                }
            }, {
                "id": "12",
                "type": "page",
                "resource": "home.html?p=2",
                "track": {
                    "data": false,
                    "completion": true,
                    "score": false
                },
                "title": "Tips to navigate online study",
                "visibility": {
                    "breadcrumbs": true,
                    "menu": true
                },
                "role": {
                    "default": {
                        "nav": {
                        }
                    }
                }, 
				"conditions": 
				{ 
					"lockedIf": [ 
						{ "id": "11", "condition": "!" } 
					] 
				}
            }, {
                "id": "13",
                "type": "page",
                "resource": "home.html?p=3",
                "track": {
                    "data": false,
                    "completion": true,
                    "score": false
                },
                "title": "Studying online",
                "visibility": {
                    "breadcrumbs": true,
                    "menu": true
                },
                "role": {
                    "default": {
                        "nav": {
                        }
                    }
                }, 
				"conditions": 
				{ 
					"lockedIf": [ 
						{ "id": "12", "condition": "!" } 
					] 
				}
            }, {
                "id": "14",
                "type": "page",
                "resource": "home.html?p=4",
                "track": {
                    "data": false,
                    "completion": true,
                    "score": false
                },
                "title": "Getting started",
                "visibility": {
                    "breadcrumbs": true,
                    "menu": true
                },
                "role": {
                    "default": {
                        "nav": {
                        }
                    }
                }, 
				"conditions": 
				{ 
					"lockedIf": [ 
						{ "id": "13", "condition": "!" } 
					] 
				}
            }, {
                "id": "15",
                "type": "page",
                "resource": "home.html?p=5",
                "track": {
                    "data": false,
                    "completion": true,
                    "score": false
                },
                "title": "Troubleshooting online access",
                "visibility": {
                    "breadcrumbs": true,
                    "menu": true
                },
                "role": {
                    "default": {
                        "nav": {
                        }
                    }
                }, 
				"conditions": 
				{ 
					"lockedIf": [ 
						{ "id": "14", "condition": "!" } 
					] 
				}
            }, {
                "id": "16",
                "type": "page",
                "resource": "home.html?p=6",
                "track": {
                    "data": false,
                    "completion": true,
                    "score": false,
                    "manual_completion":true
                },
                "title": "Connecting with Kaplan Professional",
                "visibility": {
                    "breadcrumbs": true,
                    "menu": true
                },
                "role": {
                    "default": {
                        "nav": {
							
                        }
                    }
                }, 
				"conditions": 
				{ 
					"lockedIf": [ 
						{ "id": "15", "condition": "!" } 
					] 
				}
            }, {
                "id": "17",
                "type": "page",
                "resource": "home.html?p=7",
                "track": {
                    "data": false,
                    "completion": true,
                    "score": false
                },
                "title": "Congratulations",
                "visibility": {
                    "breadcrumbs": true,
                    "menu": false
                },
                "role": {
                    "default": {
                        "nav": {
							
                        }
                    }
                }, 
				"conditions": 
				{ 
					"lockedIf": [ 
						{ "id": "16", "condition": "!" } 
					] 
				}
            }
    ]

}
