(function($){
    "use strict";

    window.bazingaApp.models.timerModel = Backbone.Model.extend({
        defaults:  {
            secs : 0,
            mins : 0,
            hrs  : 0
        }
    });

})(window.$||window.JQuery);