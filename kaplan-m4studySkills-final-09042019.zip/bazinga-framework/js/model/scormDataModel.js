(function($) {
    "use strict";

    window.bazingaApp.models.scormDataModel = Backbone.Model.extend({
        defaults: {
            "initialized": false,
            "API": null,
            "status": "new",
            "lastError": "0",
            "lastErrorDescription": "No Error",
            "autoCommit": false
        },

        sessionTime: new window.timeManager(),

        initialize: function() {
            var API,
                self = this;
            if (!this.get('API') /*|| API == undefined*/) { //on for moodle. off for kaplan t2
                this.findAPI();
            }

            this.initializeSCO();
            API = this.get('API');

            self.sessionTime
                .fromString("00:00:00.00")
                .start();


            self.totalTime = API.LMSGetValue("cmi.core.total_time");
            self.totalTime = self.totalTime || "0000:00:00.00";
            return this;
        },

        commit: function() {
            var self = context || this,
                API = self.get('API');

            API.LMSCommit("");
            return this;
        },

        setData: function(data) {
            this.data = data;
            return this;
        },

        findAPI: function() {
            var lwindow = window,
                loops = 10,
                API = null,
                self = this,
                locateAPI = function(win) {
                    while ((win.API == null) &&
                        (win.parent != null) &&
                        (win.parent != win)) {
                        // increment the number of findAPITries
                        loops++;
                        // Note: 20 is an arbitrary number, but should be more than sufficient
                        if (loops > 50) {
                            alert("Error finding API -- too deeply nested.");
                            return null;
                        }

                        // set the variable that represents the window being
                        // being searched to be the parent of the current window
                        // then search for the API again
                        win = win.parent;
                    }
                    return win.API;
                };

            API = locateAPI(lwindow);

            if (!API) {

                if (lwindow.dialogArguments) { //ie8 version
                    API = locateAPI(lwindow.dialogArguments);
                    if (window.console) {
                        console.log("look for api in lwindow.dialogArguments");
                    }
                }else if (lwindow.opener) {
                    API = locateAPI(lwindow.opener);
                    if (window.console) {
                        console.log("look for api in lwindow.opener");
                    }
                }


            }

            if (!API) {
                if (window.console) {
                    console.log("1. API NOT found. (Using local storage system)");
                }
                API = new window.bazingaApp.models.scormLocalStorage();
				window.localStorage.setItem("isOffline", true );
				
            } else {
                if (window.console) {
                    console.log("1. API found.");
                }
				window.localStorage.setItem("isOffline", false );
            }

            this.set('API', API);
        },


        setValue: function(key, value, forceCommit, context) {
            var self = context || this,
                API = self.get('API'),
                returnValue = null;

            forceCommit = forceCommit || false;

            if (!API || !key) {
                console.error("Unable to get Data . API Not initialized or the key is undefined");
                return null;
            }

            API.LMSSetValue(key, value);
			console.log("setvalue");
            self.scormError();

            if (self.get('autoCommit') || forceCommit) {
                API.LMSCommit("");
            }

            return self;
        },

        getValue: function(key, context) {
            var self = context || this,
                API = self.get('API'),
                returnValue = null;
            if (!API || !key) {
                console.error("Unable to get Data . API Not initialized or the key is undefined");
                return null;
            }
			//console.log("getvalue "+key);
            returnValue = API.LMSGetValue(key);
			//console.log("getvalue");
            self.scormError();

            return returnValue;
        },
        initializeSCO: function(context) {
			//console.log("initializeSCO");
            var self = context || this,
                API = self.get('API');

            if (self.get('initialized')) {
                //pre-initialized . then ignore.
                //console.log("API was previously initialized");
                return false
            };
			
			//console.log(API);
			//console.log(API.LMSInitialize(""));
			//console.log(API.LMSInitialize);
			
			var lms = window.bazingaCourseConfig.lms;
			
			//need the typeof 'API.LMSInitialize' === "function" below for moodle otherwise error, but having it on saves nothing in moodle and reload so changed to try
			
			if (lms == "moodle"){
				//console.log("moodle");
				try {
				self.set('initialized', (API && jQuery.isFunction(API.LMSInitialize) && API.LMSInitialize(""))); 
				}
				catch(err) {
					if (window.console) {
					console.log("ERROR: "+err.message);
					}
				}				
			}else{
				//console.log("not moodle");
				self.set('initialized', (API /*&& typeof 'API.LMSInitialize' === "function"*/ && API.LMSInitialize(""))); //for kaplan t2 and all other modules		
			}											
			
			//console.log("test2");
			
            /*console.log("test 1. api:");
            console.log(Object.getOwnPropertyNames(API));

            console.log("test 2. API.LMSInitialize is function? ");
            console.log(typeof API.LMSInitialize);

            console.log('test 3. API.LMSInitialize("")');
            console.log(API.LMSInitialize(""));*/

            //console.log("2. API initialized?: " + self.get('initialized'));

            var status = self.getValue('cmi.core.lesson_status');
            if (status == 'not attempted') { self.setValue('cmi.core.lesson_status', 'incomplete'); }

            //reset the error codes
			//console.log("initializeSCO");
            self.scormError();
            self.set('status', 'active');
        },

        switchTimers: function(context) {
            var self = context || this,
                API = self.get('API');
            API.LMSSetValue("cmi.core.session_time", self.sessionTime.toString());

            //console.log("Seting session time " + self.sessionTime.toString());
            self.sessionTime.stop();
            API.LMSCommit("");
        },
        finishSCO: function(context) {
            var self = context || this,
                API = self.get('API'),
                deferred = $.Deferred();

            if (window.bazingaApp.preloader) { window.bazingaApp.preloader.setPercentage(0).enable(); }



            //console.log("TOTAL TIME " + self.totalTime.toString() + ' ---> ' + API.LMSGetValue("cmi.core.total_time"));

            if (!self.get('initialized')) {
                //console.log("Finish sco called before initialization");
            } else {
                if (API && typeof API.LMSFinish == 'function' && API.LMSFinish("")) {
                    API.LMSFinish("");
                }
            }




            if (self.data) {
                self.data
                    .upload()
                    .always(function() {
                        API.LMSCommit("");
                        self.set('initialized', false);
                        self.set('status', 'inactive');
                        //console.log("All data synced. LMS commit called. shutting down");
                    });
            } else {
                API.LMSCommit("");
                self.set('initialized', false);
                self.set('status', 'inactive');
                //console.log("All data synced. LMS commit called. shutting down");
            }

            if (window.bazingaApp.preloader) { window.bazingaApp.preloader.incrementTo(75); }
            setTimeout(function() {
                deferred.resolve();
            }, 2000);
            return deferred.promise();
        },

        scormError: function(context) {
            var self = (context || this),
                API, lastErrorNumber;

            API = self.get('API');
            if (!API) {
                if (window.console) {
                    console.log("er: LMS API not located");
                }
                return false;
            }

            if (!self.get('initialized')) {
                if (window.console) {
                    console.log("er: LMS API NOT initialized");
                }
                return false;
            }

            lastErrorNumber = API.LMSGetLastError();

            self.set('lastError', lastErrorNumber);
            self.set('lastErrorDescription', API.LMSGetErrorString(lastErrorNumber));
			
			/*if (window.console) {
				console.log(lastErrorNumber + " : " +API.LMSGetErrorString(lastErrorNumber));
			}*/
			
            return self;
        }
    });

})(window.$ || window.JQuery);
