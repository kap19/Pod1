(function($){
    "use strict";

    window.bazingaApp.models.scormLocalStorage = Backbone.Model.extend({
        'storage' : null,
        initailizeLocalStorageObject : function(){
        },
        reset : function(){
            localStorage.clear();
            return true;
        },
        remove : function(key){
            localStorage.removeItem(key);
            return true;
        },
        LMSInitialize: function(){
            this.initailizeLocalStorageObject();
        },
        LMSGetValue : function(key){
			//console.log("LMSGetValue:"+key);
            return localStorage.getItem(key) || null;
        },
        LMSSetValue : function(key,value){
			//console.log("LMSSetValue:"+key);
            this.set(key,value || null);

            localStorage.setItem(key,value);
        },
        LMSFinish : function(){
            //console.log("LMS finish called(LS) : ");
        },
        LMSCommit : function(){
            //console.log("LMS commit called(LS) : ");
            //this.save({key:value});
        },
        LMSGetLastError : function(){
            //console.log("LMS get error called(LS) : ");
            return '0';
        },
        LMSGetErrorString : function(){
            //console.log("LMS get error string called(LS) : ");
            return 'No Error';
        }
    });

})(window.$||window.JQuery);