(function($) {
    "use strict";
    window.quedSuspendDataUpdate = false;

    /**
     * Get the query parameters from the url
     * @param qs
     * @returns {{}}
     */
    window.getQueryParams = function(qs) {
        qs = qs.split('+').join(' ');

        var params = {},
            tokens,
            re = /[?&]?([^=]+)=([^&]*)/g;

        while (tokens = re.exec(qs)) {
            params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
        }

        return params;
    }


    /**
     * Model for the current page data.
     * Every page can have 4 parameters : count / status / data / score
     * @type {*}
     */
    window.bazingaApp.models.pageData = Backbone.Model.extend({
        initialize: function() {
            _.bindAll(this, 'incrementCount', 'setStatus', 'setData', 'setScore', 'setCount');
        },
        incrementCount: function(options) {
            options = options || {};
            this.set(_('count').getKeyHash(), ((this.get(_('count').getKeyHash())) || 0) + 1);
            return this;
        },
        setStatus: function(status, options) {
            options = options || {};
            this.set(_('completion').getKeyHash(), _(status).getKeyHash(), options);
            if (_.has(this.changed, _('completion').getKeyHash())) {
                window.was_page_completed_on_load = true;
            } else {
                window.was_page_completed_on_load = false;
            }
            return this;
        },
        setData: function(data, options) {
            options = options || {};
            this.set(_('data').getKeyHash(), data, options);
            return this;
        },
        setCount: function(count, options) {
            options = options || {};
            this.set(_('count').getKeyHash(), count, options);
            return this;
        },
        setScore: function(score, options) {
            options = options || {};
            score = score || null;
            this.set(_('score').getKeyHash(), score, options);
            return this;
        },
        getScore: function() {
            return this.get(_('score').getKeyHash()) || null;
        },
        getCompletion: function() {
            return _(this.get(_('completion').getKeyHash())).getKeyHash();
        },
        setCompletion: function(status) {
            return this.setStatus(status);
        },
        getData: function() {
            return this.get(_('data').getKeyHash()) || null;
        },
        getCount: function() {
            return this.get(_('count').getKeyHash()) || 0;
        }
    });

    /**
     * Page navigation
     * @type {*}
     */
    window.bazingaApp.models.pageNav = Backbone.Model.extend({});

    /**
     * Core navigation model that controls all functionalities of the course.
     *
     * @type {*}
     */
    window.bazingaApp.models.navigationModel = Backbone.Model.extend({
        dataModel: null,

        /**
         * List of all parameters that can be set using the navigation model.
         * These parameters are hashed using the getKeyHash() mixin
         */
        defaults: {
            preferred: null,
            role: "default",
            count: 0,
            data: null,
            suspendData: null,
            currentScreen: null,
            previousScreen: null,
            currentPool: 0, //set to 0 so can randomise
            courseStatus: 'na',
            primaryScore: null,
            secondaryScore: null,
            tertiaryScore: null,
            courseData: '',
            nav: null,
            lu: null,
            param1: null,
            param2: null,
            param3: null,
            param4: null,
            quizAttempts: 0,
            progress: 0,
			lang:"null",
			offlineId:null
        },

        conditional: {
            "lockables": [],
            "locked": [],
            "unlocked": []
        },
        /**
         * These parameters are not saved into the suspend Data but used extensively inside the current model
         * Setting these never fires a 'set' or 'get' call
         */
        values: {
            allPages: [],
            allTrackablePages: [],
            suspendDataIdx: null,
            allDialogs: [],
            isDialogScreen: false
        },
        models: {
            currentSuspendData: null
        },


        initialize: function() {
            var self = this;
            _.bindAll(this, 'loadFrom', 'crunchForRole', 'retrieveSuspendData',
                'handshake', 'setUpCurrentScreen', 'suspendDataChanged', 'updateSuspendData',
                'pageInitializers', 'setSuspendDataIndices', 'getNavForScreenByRole',
                'setPageCompletion', 'setPageData', 'setInfo', 'setPageScore', 'setCourseScoreFrom',
                'setCourseScore', 'setCourseStatus', 'reattemptScreen', 'setCurrentPool', 'getCurrentPool', 'getCourseCompletion',
                'getParam', 'setParam', 'getParam1', 'setParam1', 'getParam2', 'setParam2', 'getParam3', 'setParam3', 'getParam4', 'setParam4', 'getLang', 'setLang', 'getQuizAttempts', 'setQuizAttempts', 'getQuizAttempts', 'setQuizAttempts', 'setComments', 'getComments', 'setInteractionStudentResponse','setInteractionId' ,'setSpeed', 'getProgress','setOfflineId','getOfflineId');

            this.on("change:role", this.retrieveSuspendData, self);
            this.on("change", this.suspendDataChanged, self);
        },

        /**
         * The event handler everytime data changes within the page.
         * The suspendDataChanged function will create a new suspendDataString and commit it to the LMS
         * @param __force
         * @returns {*}
         */
        suspendDataChanged: function(__force) {
            var self = this,
                suspendData = self.retrieveSuspendData(),
                dataModel = self.dataModel,
                deferred = $.Deferred();

            __force = __force || false;

			//console.log("suspend chanaged");
			
			function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

            setTimeout(function() {
                if (__force) {
                    dataModel.forceSetSuspendData(suspendData);
                } else {
                    dataModel.setSuspendData(suspendData);
				}
				
				if(getCookie("finishLoad") == "yes"){
                dataModel.commit();
				}

                window.updateOtherData = false;
                deferred.resolve();
                self.trigger("initialized:suspendData", self);
            }, window.pageLoadSpeed);


            return deferred.promise();
        },

        /**
         * STEP 1
         * Load the josn file and set up the preferred data
         * @param jsonFile
         * @returns {*}
         */
        load: function(jsonFile) {
			//console.log("navModel: load(jsonFile)");
			//console.log(jsonFile);
			
            var deferred = $.Deferred(),
                self = this,
                hashed = {
                    'completion': _('completion').getKeyHash(),
                    'completed': _('completed').getKeyHash(),
                    'passed': _('passed').getKeyHash(),
                    'incomplete': _('incomplete').getKeyHash(),
                    'failed': _('failed').getKeyHash(),
                    'not_attempted': _('not attempted').getKeyHash()
                };
			
			/*if(offlineConfig != undefined){
				console.log("offline config exists, use it");
				self.courseConfig = offlineConfig;
				//console.log(self.courseConfig);
			}*/
			
			try{ 
				self.courseConfig = offlineConfig;
				//console.log("offline config is: "+offlineConfig+", use it");
			}
				catch(err) {
					//console.log("nav model. no offlineConfig");
				}
			
			var offlineId = window.bazingaCourseConfig.title.replace(/[^\w\s]|_/g, "");
						offlineId = offlineId.split(' ').join('');
						window.localStorage.setItem("offlineId", offlineId );
						//console.log("navigation module. set offlineId: "+offlineId);
				
			//console.log("getJSON nav model");
			
            $.getJSON(jsonFile, function(data) {
				
				
			/*console.log("data - array of pages in nav");
				console.log(data);
				console.log("$.getJSON(jsonFile)");*/
				
                self.set('preferred', data, { silent: true });
                
            }).error(function(data){
				console.log(jsonFile);
				//console.log("navigation model - failed to load json ");
				
				
				if((typeof offlineNav === 'undefined') ){
					//console.log("no offline nav");
				}else{
					self.set('preferred', offlineNav, { silent: true });
				}
				
			}).complete(function(data){
					
				self.handshake()
                    .always(function() {
                        self.recalculateCompletion()
                            .always(function() {
					
								var i = self.get('courseStatus');
 
								//console.log("online - get suspenddataaa");	
							
                                var suspendData = self.get('suspendData');
								
								//console.log("m lock test");
							
								//console.log(suspendData);
								
								//console.log(self);
							
								//console.log(self.conditional);
							
							//console.log(self.conditional.lockables);
							
                                _.each(self.conditional.lockables, function(lockables, tgtId) {
                                    var locked = true,
                                        suspend,
                                        status = hashed.not_attempted,
                                        lockedStatus = [];

                                    _.map(lockables.lockedIf, function(lockable) {
										
										//only shows lockables on groups not pages
										//console.log(lockables);
										//console.log(lockables.lockedIf);
										//console.log(lockable);
										//console.log(lockable.id);
										
                                        if (!lockable.id) {
                                            return true;
                                        }

                                        //console.log("Lockable identified " + lockable.id + " .tgt = " + tgtId);
                                        var inverse = false;
                                        suspend = _.first((_.where(suspendData, { id: lockable.id })));
                                        status = hashed.not_attempted;

                                        if (suspend && !_.isEmpty(suspend) && _.has(suspend, hashed.completion)) {
                                            status = suspend[hashed.completion];
                                        }

                                        if (_.has(lockable, 'condition') && lockable.condition == "!") {
                                            inverse = true;
                                        }

                                        if ($.inArray(status, [hashed.not_attempted, hashed.incomplete, hashed.failed]) > -1) {

                                            //not completed the page
                                            lockedStatus.push(inverse);
                                        } else {
                                            //Page is complete 
                                            lockedStatus.push(!inverse);
                                        }

                                    });

                                    //console.log(lockedStatus);
                                    locked = (-1 != $.inArray(true, lockedStatus));

                                    lockables.locked = locked;
                                    self.conditional.lockables[tgtId] = lockables;
                                });

                                //resolve and start application
                                deferred.resolve(self);
                            });
                    });
				
			});
			//console.log("navmodel load end");
            return deferred.promise();
        },

        /**
         * STEP 2
         * Set up handshake between the data models
         * This will link the data model to the navigation model and initialize the navigation
         * @returns {*}
         */
        handshake: function() {
			//console.log("Hand shake1");
            var deferred = $.Deferred(),
                self = this,
                dataModel = self.dataModel,
                hashed = {
                    'completion': _('completion').getKeyHash(),
                    'completed': _('completed').getKeyHash(),
                    'passed': _('passed').getKeyHash(),
                    'incomplete': _('incomplete').getKeyHash(),
                    'failed': _('failed').getKeyHash(),
                    'not_attempted': _('not attempted').getKeyHash()
                };

            //console.log("Hand shake2");
            self.trigger("initialize:handshake", self);
            setTimeout(function() {
                self.trigger("initialize:suspendData", self);
                if (!dataModel) {
                    deferred.fail();
                    return false;
                }

                var suspendData = dataModel.getSuspendData(),
                    preferredForRole;

                /**
                 * Step 1 : Load from suspend data :
                 *          Retrieve the suspend data string and parse it .
                 *
                 * Step 2 : crunchForRole
                 *          Depending on the role and existing data a navigation structure will be populated
                 *          If suspenddata preexists then the navigation will be retrieved from the preexisting data
                 *
                 * Step 3 : setUpCurrentScreen
                 *          Reinitialize the page values to reflect changes on the current screen .
                 *
                 * Step 4 : pageInitializers
                 *          Initialize page avalues within this page
                 *
                 * Step 5 : If the page is the first page launched then either navigate to the dialog continue / home or the current page
                 *
                 *
                 * Step 6 : resolve  the promise object
                 */
                self.loadFrom((suspendData || ''), self)
                    .crunchForRole(self.get('preferred'))
                    .always(function(data) {
                        //Set up the preferred navigation
                        self.set('preferred', data, { silent: true });

                        if (!self.get('suspendData')) {
                            console.log("Error initializing suspend data: "+self.get('suspendData'));
                        }

                        self.setUpCurrentScreen();
                        self.pageInitializers()
                            .always(function() {
                                console.log("[DBG:] Page is now initialized, course status=" + self.get('courseStatus'));

                                var currentScreen,
                                    previousScreen,
                                    role,
                                    nav,
                                    pageNav,
                                    goto,
                                    nextNav,
                                    resolve = false,

                                    //Check if the course is complete
                                    isCourseComplete = (function() {
                                        if (window.was_page_completed_on_load) {
                                            console.log("Page was only just completed, course status= " + self.get('courseStatus'));
                                            return false;
                                        }

                                        return ($.inArray(self.get('courseStatus'), [hashed.completed, hashed.passed]) > -1);

                                    })(),
                                    isCurrentComplete;

                                //console.log("M: START TEST");
							//console.log("isCourseComplete: "+isCourseComplete);
							console.log("firstLaunch local storage: "+window.localStorage.getItem('firstLaunch'));

                                if (isCourseComplete || window.localStorage.getItem('firstLaunch')) {  

                                    console.log("Course is complete or first launch");
                                    window.localStorage.removeItem('firstLaunch');

                                    //check to see if a dialog needs to be shown.
                                    currentScreen = self.get('currentScreen');
                                    previousScreen = self.get('previousScreen');
                                    role = self.get('role') || 'default';

                                    if (!isCourseComplete && !previousScreen) {
                                        //Launch for the first time .  The course is incomplete
                                        //console.log("M: start");
                                        console.log("first time load and course incomplete");
                                        $(".moduleLoaded").show();
                                        resolve = true;
                                    } else {
                                        currentScreen = currentScreen || 'home';
                                        nav = self.getNavForScreenByRole(role, previousScreen); //this line is required for reenter

                                        //console.log("M test");
										console.log(nav);

                                        if (isCourseComplete) {
                                            console.log("M: Course Config ");
											
											console.log(self.courseConfig);
											console.log(self.courseConfig.allow_continue_after_complete);
											
                                            if (self.courseConfig.allow_continue_after_complete || self.courseConfig.responseJSON.allow_continue_after_complete /*seems to have changed with offline*/) {

                                                //Do not lock the course on complete. Continue
                                                $(".moduleLoaded").show();

                                                resolve = true;
                                                //debugger;
                                            } else {
                                                //force the course to go to the dcom
                                                goto = self.courseConfig.default_complete || 'dcom';

                                                //console.log("Mmmmmmmmm");

                                                isCurrentComplete = (function() {

                                                    var location = window.location.pathname,
                                                        locationHref = (location.split("/")).pop(),
                                                        dialogNav;

                                                    if (["dcom"].indexOf(goto) > -1) {
                                                        //send the course score on dialog complete
                                                        self.setCourseScoreFrom('primary');
                                                        dialogNav = self.getDialog(goto);
                                                    } else {
                                                        dialogNav = self.getNavForScreen(goto);
                                                    }


                                                    return (locationHref === dialogNav.resource)
                                                })();

                                                if (isCurrentComplete) { resolve = true; }

                                                //console.log("MM");
                                            }

                                        } else {
											console.log("course not complete, go to renter page or resume");
                                            goto = nav.reenter || self.courseConfig.default_continue || 'dcon';
											console.log(goto);
                                        }

                                        if (window.debug || resolve) {
                                            resolve = true;
                                        } else {
												
                                            if ((goto && goto != 'prevent')) {
                                                //go to a particular screen or dialog
                                                if (["dcom", "dcon", "dex", "dh", "dr"].indexOf(goto) > -1) {
                                                    nextNav = self.getDialog(goto);
                                                } else {
                                                    nextNav = self.getNavForScreen(goto);
                                                }

                                                if (nextNav && nextNav.resource) {
                                                    window.location.replace(nextNav.resource);
                                                } else {
                                                    //do nothing skip
                                                    resolve = true;
                                                }
                                            } else if (currentScreen !== previousScreen) {

                                                pageNav = self.getNavForScreen(previousScreen);

                                                if (pageNav && pageNav.resource) {
                                                    window.location.replace(pageNav.resource);
                                                } else {
                                                    //do nothing skip
                                                    //console.log("M: do nothing");
                                                    resolve = true;
                                                }
                                            } else {
                                                resolve = true;
                                            }
                                        }

                                    }
                                } else {
									
									//console.log("module loaded show");
                                    $(".moduleLoaded").show();

                                    resolve = true;
                                }

                                if (resolve) { deferred.resolve(); }

                            });

                    });
            }, window.pageLoadSpeed);

            return deferred.promise();
        },


        /**
         * Load the current data model from the suspend data string
         * @param suspendData
         * @param context
         * @returns {*}
         */
        loadFrom: function(suspendData, context) {
            var self = context || this,
                suspendDataJson = _(suspendData).uncrunchSuspendData(),
                attributes = context.attributes,
                attributeKeys = _.keys(attributes);


            _.each(attributeKeys, function(key) {

                var keyHash = _(key).getKeyHash();
                switch (key) {
                    case 'preferred':
                        break;
                    case 'suspendData':
                        var dataJson = {},
                            pageHash = _('page').getKeyHash(),
                            preventTracking = false;

                        if (_.has(self.courseConfig, 'prevent_tracking') && self.courseConfig.prevent_tracking == true) { preventTracking = true; }

                        if (!_.isEmpty(suspendDataJson) && !preventTracking) {
                            //reset the key from the suspend data
                            if (_.has(suspendDataJson, pageHash)) {
                                dataJson = suspendDataJson[pageHash];
                            }

                            self.set('suspendData', dataJson, { silent: true });
                        }
                        break;
                    case 'nav':
                        //reset the key from the suspend data
                        if (_.has(suspendDataJson, keyHash)) {
                            context.set(key, suspendDataJson[keyHash], { silent: true });
                        };
                        break;

                    default:
                        //reset the key from the suspend data
                        if (_.has(suspendDataJson, keyHash)) {
                            context.set(key, suspendDataJson[keyHash], { silent: true });
                        };
                        break
                }
            });
            return self;
        },

        /**
         * Set up the navigation for the role
         * @param data
         * @returns {*}
         */
        crunchForRole: function(data) {

            var role = this.get('role') || 'default',
                currentNav = this.get('nav') || null,
                deferred = $.Deferred(),
                self = this,
                cp = self.get('currentPool'),

                /**
                 * When the config timestame is greater than the timestamp on file
                 * Reload the config / navigation
                 * This allows us to make sure the suspendData string is in sync with the navigation
                 *
                 * @Note : changin the timestamp will reset the suspendData string
                 */
                isConfigUpdated = (function() {

                    //Compare date time with existing date tiem
                    var d = new Date(),
                        d2,
                        t = d.getTime(),
                        t2,
                        lu = self.get('lu'),
                        clu;

                    if (!self.get('suspendData') || !self.courseConfig || !lu) {
                        //time was never recorded . record it now
                        self.set('lu', t, { silent: true });
                        return false;
                    }

                    clu = self.courseConfig.last_updated;

                    if (!clu) {
                        self.set('lu', t, { silent: true });
                        return false;
                    }

                    d2 = new Date(clu);
                    t2 = d2.getTime();
                    self.set('lu', t2);



                    if (t2 > lu) {
                        return true;
                    }
                    return false;
                }()),

                /**
                 * This  is the access control within the nav controller.
                 * The page filter loops through each page and make sure the page values are parsed
                 * Also it creates easy access variables within the application
                 */
                pageFilter = function(pages, cNav, parent) {
                    //map all sub pages
                    _.map(pages, function(page) {
                        //set up the page bread crumbs
                        page.crumbs = page.crumbs || [];
                        if (parent) {
                            page.crumbs.push(parent);
                        }

                        //if the page has no items then initialize hte page
                        if (!_.has(page, 'items')) {
                            if (page.structure == 'group') {
                                return page;
                            }
                            page.structure = page.id;
                            page.parent = parent || null;
                            return page;
                        }

                        /**
                         * Step 1 : recursively filter the page items to make sure only  items with proper access levels can be accessed by the role
                         * Step 2 : randomize
                         *          randomize is dependent on the group level randomize options . Each nav key can be set to 3 different options
                         *                ">>" : Will randomize then reset the nav key with the id of the next page in the randomized list.
                         *                "<<" : Will randomize then reset the nav key with the id of the previous page in the randomized list.
                         *                "<id>" : This will set the nav key of the page to the id mentioned
                         *                "*" : this will inherit the defined nav properties for the page
                         *
                         * @type {*}
                         */
                        var items = pageFilter(page.items, (cNav ? (_.has(cNav, page.id) ? cNav[page.id] : null) : null), page.id),
                            randomize = (page.type == 'group' && _.has(page, 'randomize')) ? page.randomize : false,
                            __allIds = _.pluck(items, 'id'),
                            __static, __dynamic, itemList = [],
                            __after = {
                                "first": {
                                    "back": "*",
                                    "next": "*",
                                    "complete": "home",
                                    "passed": "home",
                                    "failed": "home"
                                },
                                "last": {
                                    "back": "*",
                                    "next": "*",
                                    "complete": "home",
                                    "passed": "home",
                                    "failed": "home"
                                },
                                "others": {
                                    "back": "*",
                                    "next": "*",
                                    "complete": "*",
                                    "passed": "*",
                                    "failed": "*"
                                }
                            };

                        //get a list of all pages (if previously set then get the right list.
                        if (_.has(cNav, page.id) && typeof cNav[page.id] === 'object') {
                            //todo clean up the code
                            //since it is an object it automatically reorders numbers. so we switch the ordering to keys and let it sort then pick the values :D
                            //hack hack hack .SCREAMS HACK!! @sundar
                            __allIds = _.values(_.object(_.values(cNav[page.id]), _.keys(cNav[page.id])));
                        } else if (randomize) {

                            //randomize the items
                            __static = page.randomize.__static || [];
                            __dynamic = _.shuffle(_.difference(__allIds, __static));

                            __allIds = _.map(_.clone(__allIds), function(id) {
                                if (_.indexOf(__static, id) > -1) {
                                    return id;
                                }
                                var dyn_id = __dynamic.pop();
                                return dyn_id;
                            });
                        }


                        if (_.has(page.randomize, '__after')) {
                            __after = _.extend(__after, ((randomize && _.has(page.randomize, '__after')) ? page.randomize.__after : {}));
                        }

                        _.each(__allIds, function(value, key) {
                            var itemForId = _.find(items, function(it) {
                                    return it.id == value;
                                }),
                                nav,
                                currentIdx = itemForId ? (_.indexOf(__allIds, itemForId.id)) : -1,
                                nextOrBack,
                                navByRoleForItem;
							
							var isOffline = window.localStorage.getItem("isOffline");
							
							if(itemForId == undefined){
								if(isOffline == "true"){
								console.log("refresh page - using nav from another module");
								
								localStorage.clear();
									
								document.cookie = "finishLoad=no";
								location.reload();
								return false;
								}
							}else{
								navByRoleForItem = itemForId.role[role].nav;
								/*console.log("itemForId:");
								console.log(itemForId);
								console.log("role " + role);
								console.log("navByRoleForItem:");
								console.log(navByRoleForItem);
								console.log("---");*/
							}

                            //This was a corrupted navigation file. Previous suspend data has since been changed
                            if (!itemForId) {
                                return true;
                            }

                            //previously the first screen always has a back to home. last screen always have next to home. now fixed
                            if (key == 0) {
                                nav = __after.first;
                            } else if (key == (__allIds.length - 1)) {
                                nav = __after.last;
                            } else {
                                nav = __after.others;
                            }


                            _.each(nav, function(v, k) { //v: *,>>,home,home,home............... k: next,complete, passed, failed
								
								//ignore subgroups
								if(itemForId.type =="group"){
									return false;
								}
								
                                //console.log("k "+k);
                                //console.log(nav);

                                //console.log("k "+k);
                                /*if (v == '?') {
                                    //Do nothing and take the defaults
                                    return true;
                                } else*/
                                if (k == 'back') {
                                    //Auto calculate back or next
                                    /*if (currentIdx == 0 || currentIdx == -1) {
                                        nextOrBack = 'home';
                                    }
                                    else {*/
                                    nextOrBack = (function() {
                                        /*if(currentIdx == 0){
                                            return 'home';
                                        }*/

                                        /**
                                         * This has been improved to add in the pool
                                         * When a back or next value is returned, the returned value is checked to verify
                                         * if the pools of the returned value matches with the currently selected pool
                                         * Or the loop continues till the match occurs
                                         *
                                         * @type {boolean}
                                         */
                                        //console.log("->BACK");

                                        var stop = false,
                                            cIdx = currentIdx - 1,
                                            idx,
                                            itForBack,
                                            retValue = 'home'; //defaults

                                        //console.log("index " + currentIdx);
											
                                        //console.log("back for " + value + " is " + itemForId.role[role].nav[k]);

                                        //check page exists

                                        if (itemForId.role[role].nav[k]) {
                                            //Do nothing and take the defaults
                                            //console.log("value is set");
                                            return itemForId.role[role].nav[k];

                                        } else {
                                            //console.log("does not exist");
                                            //auto calculate
                                            while (stop === false) {
                                                idx = __allIds[cIdx];
                                                //console.log("idx " + idx);
                                                itForBack = _.find(items, function(it) {
                                                    return it.id == idx;
                                                });

                                                if (!itForBack || !itForBack.id || !cp || !page.track || !page.track.pool) {
                                                    if (itForBack && itForBack.id) {
                                                        retValue = itForBack.id;
                                                    }
                                                    stop = true;
                                                } else {
                                                    if ((page.track.pool + "") !== (cp + "")) {
                                                        cIdx -= 1;
                                                        if (cIdx < 0) { stop = true; }
                                                    } else {
                                                        stop = true;
                                                        retValue = itForBack.id;
                                                    }
                                                }
                                            }
                                            //console.log("Back for " + value + " auto calculated as " + retValue);
                                            return retValue;
                                        }


                                    })();
                                    //}


                                    itemForId.role[role].nav[k] = (nextOrBack);
                                    return true;
                                } else if (k == 'next') {
                                    //Auto calculate back or next
                                    /*if (currentIdx == __allIds.length - 1) {
                                        nextOrBack = 'home';
                                    }
                                    else {*/
                                    nextOrBack = (function() {
                                        /*if(currentIdx >=  __allIds.length - 1){
                                            return 'home';
                                        }*/

                                        /**
                                         * This has been improved to add in the pool
                                         * When a back or next value is returned, the returned value is checked to verify
                                         * if the pools of the returned value matches with the currently selected pool
                                         * Or the loop continues till the match occurs
                                         *
                                         * @type {boolean}
                                         */

                                        //console.log("->NEXT");

                                        var stop = false,
                                            cIdx = currentIdx + 1,
                                            idx,
                                            itForNext,
                                            retValue = 'home';

                                        //console.log("currentIdx " + currentIdx);

                                        //console.log("next for " + value + " is " + itemForId.role[role].nav[k]);

                                        if (itemForId.role[role].nav[k]) {
                                            //Do nothing and take the defaults
                                            //console.log("value is set");
                                            return itemForId.role[role].nav[k];
                                        } else {
                                            //console.log("does not exist");
                                            //auto calculate
                                            while (stop === false) {
                                                idx = __allIds[cIdx];
                                                //console.log("idx " + idx);
                                                itForNext = _.find(items, function(it) {
                                                    return it.id == idx;
                                                });

                                                if (!itForNext || !itForNext.id || !cp || !page.track || !page.track.pool) {
                                                    if (itForNext && itForNext.id) {
                                                        retValue = itForNext.id;
                                                    }

                                                    stop = true;
                                                } else {
                                                    if ((page.track.pool + "") !== (cp + "")) {
                                                        cIdx += 1;
                                                        if (cIdx >= (__allIds.length - 1)) { stop = true; }
                                                    } else {
                                                        stop = true;
                                                        retValue = itForNext.id;
                                                    }
                                                }
                                            }
                                            //console.log("Next for " + value + " auto calculated as " + retValue);
                                            return retValue;
                                        }


                                    })();
                                    //}

                                    itemForId.role[role].nav[k] = (nextOrBack);
                                    return true;
                                }

                                //Set the constant page as the key
                                navByRoleForItem[k] = v;
                                //console.log("navByRoleForItem[k]" +v);
                                return true;
                            });

                            itemForId.role[role].nav = navByRoleForItem;
                            itemList.push(itemForId);
                        });
                        page.items = itemList;

                        //console.log("itemList 111111");
                        //console.log(page.items);

                        var i = 0;

                        _.map(itemList, function(it) {
							//console.log(it);
							//console.log(it.subgroup);
                            if (typeof it.structure !== 'object') {
                                it.structure = i++;
								//console.log("set structure: "+it.structure);
                            }else{
								//console.log("is object?");
							}
                            return it;
                        });

                        page.structure = _.object(_.pluck(itemList, 'id'), _.pluck(itemList, 'structure'));
						
						//console.log("struck");
						//console.log(page.structure);

                        //part 1. adds items in groups to all pages. 
                        self.values.allPages = ([].concat(self.values.allPages, itemList));
						//console.log("HERE");
						//console.log(self.values.allPages);
						
						//console.log(page);
						
                        return page;
                    });


                    return _.filter(pages, function(page) {

                        if (page.type == 'dialog') {
                            return false;
                        }

                        if (cNav && !isConfigUpdated) {
                            //if it exists in the nav use it :)
                            return _.has(cNav, page.id);
                        } else {
                            return _.has(page, 'role') && _.has(page.role, role);
                        }
                    }, this);
                };

            if (isConfigUpdated) {
                currentNav = null;
            }


            /**
             * Set up all dialogs that can be accessed from the course
             * This allows us to access the dialog help and such using hte same navigation calls as a page removing need for unwanted calls
             * @type {Array}
             */
            self.values.allDialogs = _.filter(data.pages, function(page) {
                if (page.type == 'dialog') {
                    return true;
                }
                return false;
            });

            //filter all pages within the data
            data.pages = pageFilter(data.pages, currentNav);

			//console.log("data.pages");
			//console.log(data.pages);
			
            self.conditional.lockables = (_.object(_.pluck(data.pages, 'id'), _.pluck(data.pages, 'conditions')));
			
			var pageLockables = [];
			
			_.each(data.pages,function(aGroup){
				//console.log("aGroup's items");
				//console.log(aGroup.items);
				if(aGroup.items){
					
					var somePageLockables = [];
					
					_.each(aGroup.items, function(aPage){
						
						if(aPage.conditions){
							//console.log("aPage "+aPage.id);
							//console.log(aPage.conditions);  
						 
							//mw error only gets the last group of unlockables. change pageLockables to somePageLockables 
							//pageLockables = (_.object(_.pluck(aGroup.items, 'id'), _.pluck(aGroup.items, 'conditions')));
							
							//somePageLockables = (_.object(_.pluck(aGroup.items, 'id'), _.pluck(aGroup.items, 'conditions')));
							
							//console.log(pageLockables);
							
							var thisPage = new Object();
							thisPage.id = aPage.id;
							thisPage.conditions = aPage.conditions;
							
							pageLockables[aPage.id] = aPage.conditions;
							
							//console.log(_.object(aPage.id, aPage.conditions ));
							
							//pageLockables.push(_.object(aPage.id, aPage.conditions ));
							
							
						}
					});
					
					/*_.each(somePageLockables, function(aPage){
						pageLockables[aPage.id] = aPage;
					});*/
					
					/*console.log("CMON");
					console.log(somePageLockables);
					console.log(_.size(somePageLockables));
					_.each(somePageLockables, function(item){
							//console.log(i);
							console.log(item);
					});
					
					console.log("mid pageLockables");
					console.log(pageLockables);
					*/
				}
			});
			
			//console.log("end pageLockables");
			//console.log(pageLockables);
			
			//remove undefined pagelockables
			
			pageLockables = _.omit(pageLockables, function(value, key, object) {
                return value === undefined;
            });
			
			//pageLockables = (_.object(_.pluck(data.pages.items, 'id'), _.pluck(data.pages.items, 'conditions')));
			
			//console.log("pageLockables");
			//console.log(pageLockables);
			
			//self.conditional.lockables = pageLockables.concat(self.conditional.lockables);
			
			//remove any undefined
			
            self.conditional.lockables = _.omit(self.conditional.lockables, function(value, key, object) {
                return value === undefined;
            });
			
			//self.conditional.lockables = _.union(self.conditional.lockables,pageLockables);
			
			//add pageLockable objects to self.conditional.lockables object as properties
			
						for (var property in pageLockables) {
				if (pageLockables.hasOwnProperty(property)) {
					
					self.conditional.lockables[property] = pageLockables[property];
				}
			}
			
			//console.log("end self.conditional.lockables");
			//console.log(self.conditional.lockables);

            /**
             * When the navigation is initialized the suspend data will be generated and submitted.
             * The first initialize call on the suspenddata will mean the data is saved and we can progres to the next step
             */
            self.once("initialized:suspendData", function() {
				//console.log("initialized:suspendData");
                if (!self.get('suspendData')) {
                    self.loadFrom(self.dataModel.getSuspendData(), self);
                    self.setSuspendDataIndices();
                    
					var isOffline = window.localStorage.getItem("isOffline");
			
					
					if(isOffline == "true"){
						
						//console.log("refresh - SUSPENDDATA INIT. did not exist - was successfully initialized for the first time");
						
						document.cookie = "finishLoad=no";
						location.reload();
						return false;
					}
                }
                deferred.resolve(data);
            });



            self.set('nav', _.object(_.pluck(data.pages, 'id'), _.pluck(data.pages, 'structure')), { silent: true });

            //handles cases when the suspend data string doesnt update and the execuction fails
            self.trigger("change", self);

            //part 2 adds, individual items to all pages
            self.values.allPages = ([].concat(self.values.allPages, data.pages));

            //self.values.allTrackablePages = self.values.allPages;

            return deferred.promise();
        },

        /**
         * Update the suspend data
         *
         * The suspend data will be reloaded everytime there is an update to the values within the model
         *
         * @param updateType
         * @returns {*}
         */
        updateSuspendData: function(updateType) {
            var self = this,
                currentSuspendData = (self.get('suspendData')),
				//currentSuspendData = window.bazingaApp.models.navigation.getSuspendData(), //this caused module to crash
                updatedModel = self.models.currentSuspendData.attributes,
                qued = function() {
                    var deferred = $.Deferred();

                    if (!window.quedSuspendDataUpdate) {
                        window.quedSuspendDataUpdate = true;
                        window.suspendDataReload = false;
                        self.suspendDataChanged()
                            .always(function() {
                                window.quedSuspendDataUpdate = false;
                                if (window.suspendDataReload) {
                                    window.suspendDataReload = false;
                                    qued();
                                }
                                deferred.resolve();
                                self.trigger("updated:suspendData", self, { updateType: updateType });
                            });
                    } else {
                        window.suspendDataReload = true;
                    }

                    return deferred.promise();
                };

			/*console.log("-- update suspend data. self.models.currentSuspendData");
			console.log(self.models.currentSuspendData);
			
			console.log("nav model self.models.currentSuspendData.attributes");
			console.log(self.models.currentSuspendData.attributes);*/

            /**
             * IF there is no suspend data then reload the suspend data from the LMS
             */
            if (currentSuspendData === null) {
				console.log("currenSuspendaData is null. self.dataModel.getSuspendData():");
				
                self.loadFrom(self.dataModel.getSuspendData(), self);
                currentSuspendData = (self.get('suspendData'));
				
				console.log(currentSuspendData);
				
                self.setSuspendDataIndices();
            }


            if (self.values.pageSuspendIdx == -1 || !_.has(currentSuspendData, self.values.pageSuspendIdx)) {
                console.log("INDEX NOT FOUND / NOT UPDATED "+self.values.pageSuspendIdx);
				console.log(currentSuspendData);
            } else {
                currentSuspendData[self.values.pageSuspendIdx] = updatedModel;
                self.set('suspendData', currentSuspendData);



                if (updateType == 'completion') {
                    /**
                     * IF completion of the page has changed then we need to recalcualte completion of the course
                     */
                    self.recalculateCompletion()
                        .always(qued);
                } else if (updateType == 'scoring') {
                    /**
                     * IF score of the page has changed then we need to recalcualte score of the course
                     */
                    self.recalculateScoring()
                        .always(qued);
                } else if (updateType == 'scoringAndCompletion') {
                    self.recalculateScoring()
                        .always(function() {
                            console.log("Recalculating completion");
                            self.recalculateCompletion().always(qued);
                        });

                } else {

                    window.updateOtherData = true;
                    if (!window.quedSuspendDataUpdate) {
                        qued();
                    }
                }
            }
            return self;
        },

        /**
         * Re calculate completion of the course and the topics
         * @returns {*}
         */
        recalculateCompletion: function() {
            var
                self = this,
                deferred = $.Deferred(),
                nav = this.get('nav'),
                currentSuspendData = this.get('suspendData'),
                preferred = this.get('preferred'),
                allPages = this.values.allPages,
                completion = [],
                allTrackable = [],
                dataModel = self.dataModel,
                hashMap = {
                    'completion': _('completion').getKeyHash(),
                    'not_attempted': _('not attempted').getKeyHash(),
                    'incomplete': _('incomplete').getKeyHash(),
                    'completed': _('completed').getKeyHash(),
                    'passed': _('passed').getKeyHash(),
                    'failed': _('failed').getKeyHash()
                },

                /**
                 * The main recalculate function.
                 * STEP 1 : Find all trackable pages (page.track.completion == true )
                 * STEP 2 : For each of the above pages get the suspend data and the completion
                 * STEP 3 : If this page has sub items them recursively calculate the completion of this page
                 * STEP 4 : Based on the total number of not-attempted pages / incomplete / completed pages calcualte group / coruse completion
                 *          If there are incomplete pages + not attempted pages then the course / group status is incomplete
                 *          If all sub pages are completed / passed then the even bubbles up
                 */
                recalculate = function(pages, trackable, preventCommit) {
                    preventCommit = preventCommit || false;

                    //loops through all the items and groups
                    var trackablePages = _.filter(pages, function(page) {
                        var trackable = true,
                            cp = self.get('currentPool');

                        trackable = trackable && (page.track && page.track.completion);

                        if (cp && page.track && page.track.pool) {
                            trackable = trackable && ((page.track.pool + "") === (cp + ""));
                        }

                        //console.log(page.id +" ==> trackable ?? " + trackable);
                        return trackable;
                    }, this);

                    trackable = trackable || [];

                    var numPagesComplete = 0;

                    _.map(trackablePages, function(page) {
                        var suspendKey = _.findKey(currentSuspendData, { id: page.id }),
                            it,
                            subTrackables,
                            pageCompletion,
                            counter;


                        if (!suspendKey) {
                            currentSuspendData = currentSuspendData || {};
                            currentSuspendData[page.id] = { id: page.id };
                            currentSuspendData[page.id][hashMap.completion] = hashMap.not_attempted;
                            suspendKey = _.findKey(currentSuspendData, { id: page.id });
                        }

                        it = currentSuspendData[suspendKey];
                        it.type = page.type;


                        if (!_.has(page, 'items') || page.items.length == 0) {
                            trackable.push(it);
                            return page;
                        }


                        subTrackables = (recalculate(page.items, []));
                        pageCompletion = _.pluck(subTrackables, hashMap.completion);

                        //console.log("subTrackables");
                        //console.log(subTrackables);
                        //console.log("pageCompletion");
                        //console.log(pageCompletion);

                        counter = _.countBy(pageCompletion, function(completion) {
                            if (!completion || completion == _('not attempted').getKeyHash()) {
                                return _('not attempted').getKeyHash();
                            }
                            //add to progress
                            numPagesComplete = numPagesComplete + 1;
                            return completion;
                        });

                        if (counter[hashMap.not_attempted] == trackablePages.length) {
                            it[hashMap.completion] = hashMap.not_attempted;
                        } else if (counter[hashMap.not_attempted] > 0 || counter[hashMap.incomplete] > 0 || counter[hashMap.failed] > 0) {
                            it[hashMap.completion] = hashMap.incomplete;
                        } else {
                            var sendCompletedStatus = true;
                            if (self.courseConfig && self.courseConfig.completion && (self.courseConfig.completion.status == 'passed-failed-completed' || self.courseConfig.completion.status == 'passed-completed')) {
                                if (counter[hashMap.passed] > 0) {
                                    it[hashMap.completion] = hashMap.passed;
                                    sendCompletedStatus = false;
                                } else {
                                    it[hashMap.completion] = hashMap.completed;
                                    sendCompletedStatus = false;
                                }
                            }
                            if (sendCompletedStatus) {
                                it[hashMap.completion] = hashMap.completed;
                            }
                        }

                        trackable.push(it);
                        currentSuspendData[suspendKey][hashMap.completion] = it[hashMap.completion];

                        self.set('suspendData', currentSuspendData, { silent: true });
                        return page;
                    });

                    //save number of completed pages to progress
                    //console.log(numPagesComplete);
                    //window.bazingaApp.models.api.setProgress(numPagesComplete);
                    self.set('progress', numPagesComplete, { silent: true });

                    return trackable;
                };


            setTimeout(function() {
                allTrackable = recalculate(preferred.pages, allTrackable);

                /**
                 * Get completion of all topics
                 * @type {Array}
                 */
                var allCompletion = _.pluck(allTrackable, hashMap.completion),
                    allCounter = _.countBy(allCompletion, function(completion) {
                        if (!completion || completion == hashMap.not_attempted) {
                            return hashMap.not_attempted;
                        }
                        return completion;
                    });

                /*console.log("allTrackable");
                    console.log(allTrackable);
                console.log("allCompletion");
                    console.log(allCompletion);
                    console.log("allcounter");
                    console.log(allCounter);*/

                /**
                 * Set course status based on topic completion
                 */
                if (allCounter[hashMap.not_attempted] > 0 || allCounter[hashMap.incomplete] > 0 || allCounter[hashMap.failed] > 0) {
                    self.set('courseStatus', hashMap.incomplete, { silent: true });
                    console.log("Lesson status :incomplete");
                    dataModel.setLessonStatus('incomplete');
                    dataModel.commit();
                } else {

                    var sendCompletedStatus = true;

                    if (self.courseConfig && self.courseConfig.completion) {
                        if (self.courseConfig.completion.status == 'passed-failed-completed' || self.courseConfig.completion.status == 'passed-completed' || (self.courseConfig.completion.status == 'completed-with-score')) {
                            if (allCounter[hashMap.passed] > 0) {
                                console.log("Lesson status :passed");
                                self.set('courseStatus', hashMap.passed, { silent: true });
                                dataModel.setLessonStatus('passed');
                                dataModel.commit();
                                sendCompletedStatus = false;
                            } else if (allCounter[hashMap.failed] > 0) {
                                console.log("Lesson status :failed");
                                self.set('courseStatus', hashMap.failed, { silent: true });
                                dataModel.setLessonStatus('failed');
                                dataModel.commit();
                                sendCompletedStatus = false;
                            }
                        }
                    }

                    if (sendCompletedStatus) {
                        console.log("Lesson status :completed");
                        self.set('courseStatus', hashMap.completed, { silent: true });
                        dataModel.setLessonStatus('completed');
                        dataModel.commit();
                    }
                }




                self.suspendDataChanged(true)
                    .always(function() {
                        deferred.resolve();
                    })
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        /**
         * @tpdp // complete ths
         * @returns {*}
         */
        recalculateScoring: function() {
            var
                self = this,
                deferred = $.Deferred(),
                nav = this.get('nav'),
                currentSuspendData = this.get('suspendData'),
                preferred = this.get('preferred'),
                allPages = this.values.allPages,
                scores = [],
                allScorable = [],
                dataModel = self.dataModel,
                hashMap = {
                    'score': _('score').getKeyHash()
                },

                /**
                 * Recalculate course scoring based on page scores
                 */
                recalculate = function(pages, trackable) {
                    var trackablePages = _.filter(pages, function(page) {
                            var trackable = true,
                                cp = self.get('currentPool');

                            trackable = trackable && (page.track && page.track.score && page.track.score === true);

                            if (cp && page.track && page.track.pool) {
                                trackable = trackable && ((page.track.pool + "") === (cp + ""));
                            }

                            return trackable;

                        }, this),
                        trackable = trackable || [],
                        score = 0,
                        allScores = [];

                    _.map(trackablePages, function(page) {
                        var suspendKey = _.findKey(currentSuspendData, { id: page.id }),
                            it,
                            subTrackables,
                            completion,
                            pageCompletion,
                            counter,
                            total = 0;

                        if (!suspendKey) {
                            currentSuspendData = currentSuspendData || {};
                            currentSuspendData[page.id] = { id: page.id };
                            currentSuspendData[page.id][hashMap.completion] = hashMap.not_attempted;
                            suspendKey = _.findKey(currentSuspendData, { id: page.id });
                        }

                        it = currentSuspendData[suspendKey];
                        it.type = page.type;

                        if (!_.has(page, 'items') || page.items.length == 0) {
                            trackable.push(it);
                            return page;
                        }

                        subTrackables = (recalculate(page.items, []));

                        allScores = _.pluck(subTrackables, hashMap.score);


                        total = _.reduce(allScores, function(memo, score) {
                            if (!score) { score = 0; } else {
                                score = parseInt(score);
                                if (_.isNaN(score)) { score = 0; } else if (score > 100) { score = 100; } else if (score < 0) { score = 0; }
                            }

                            return memo + (score || 0);
                        }, 0);


                        it[hashMap.score] = total;
                        trackable.push(it);



                        currentSuspendData[suspendKey][hashMap.score] = (it[hashMap.score] / allScores.length);
                        self.set('suspendData', currentSuspendData, { silent: true });
                        return page;
                    });

                    return trackable;
                };



            setTimeout(function() {
                allScorable = recalculate(preferred.pages, allScorable);
                scores = _.pluck(allScorable, hashMap.score);

                if (!scores || scores.length == 0) {
                    //no update
                    deferred.resolve();
                }


                var total = _.reduce(scores, function(memo, score) {
                    if (!score) { score = 0; } else {
                        score = parseInt(score);
                        if (_.isNaN(score)) { score = 0; } else if (score > 100) { score = 100; } else if (score < 0) { score = 0; }
                    }
                    return memo + (score || 0);
                }, 0);

                self.set('primaryScore', (total / scores.length), { silent: true });

                self.suspendDataChanged(true)
                    .always(function() { deferred.resolve(); })


                console.log("Save complete ");
            }, window.pageLoadSpeed);

            return deferred.promise();
        },


        /**
         * Set up the suspend data indices
         * @returns {boolean}
         */
        setSuspendDataIndices: function() {
            var self = this,
                currentSuspendData = self.get('suspendData') || {},
                suspend;
			
			

            if (!currentSuspendData || !self.values.pageNav || !self.values.pageConfig) {
                return false;
            }

            //find the suspend data
            self.values.pageSuspendIdx = _.findKey(currentSuspendData, function(x) {
                return x.id == self.values.pageConfig.id;
            });
			
			/*console.log("currentSuspendData:");
			console.log(currentSuspendData);

			console.log("self.values.pageSuspendIdx "+self.values.pageSuspendIdx);*/
			
            //get the previous suspend data
            self.values.previousSuspendData = suspend = (!self.values.pageSuspendIdx || self.values.pageSuspendIdx == -1) ? {} : currentSuspendData[self.values.pageSuspendIdx];
            //get the suspend default suspend value
            suspend = self.suspendDataDefaults(suspend, self.values.pageNav, self.values.pageConfig)
            self.models.currentSuspendData = new window.bazingaApp.models.pageData(suspend);

            self.models.currentSuspendData.on("change", function() {
                var changed = self.models.currentSuspendData.changed;

                if (_.has(changed, (_('completion').getKeyHash()))) {

                    self.updateSuspendData('completion');
                } else if (_.has(changed, (_('score').getKeyHash()))) {
                    self.updateSuspendData('scoring');
                } else {
                    self.updateSuspendData();
                }

            });

        },
        /**
         * Initialize the current screen
         * @returns {*}
         */
        setUpCurrentScreen: function() {
            var location = window.location.pathname,
                locationHref = (location.split("/")).pop(),
                self = this,
                allPages,
                config,
                role = self.get('role') || 'default',
                page,
                filteredByPool,
                currentScreen = self.get('currentScreen'),
                previousScreen = self.get('previousScreen'),
                currentPool = window.bazingaApp.models.api.getCurrentPool();

            if (self.values.allPages.length == 0) {
                return false;
            }

            allPages = _.clone(self.values.allPages);


            filteredByPool = _.filter(allPages, function(page) {
                var trackable = true,
                    parent = page.parent,
                    parentConfig;

                if (parent) {
                    //check the parent to see if they have a pool to track to
                    //parentConfig = (_.where(allPages,{id:parent}));
                    parentConfig = _.find(allPages, function(page) {
                        return page.id == parent
                    });

                    //get the parent pool
                    parentConfig = parentConfig && parentConfig.track && parentConfig.track.pool;
                }

                if (currentPool) {
                    if (page.track && page.track.pool) {
                        trackable = trackable && ((page.track.pool + "") === (currentPool + ""));
                    } else if (parentConfig) {
                        trackable = trackable && ((parentConfig + "") === (currentPool + ""));
                    }
                }


                return trackable;
            }, this);

            if (filteredByPool.length > 0) {
                self.values.pageNav = page = _.first(_.where(filteredByPool, { resource: locationHref }));
            } else {
                self.values.pageNav = page = _.first(_.where(self.values.allPages, { resource: locationHref }));
            }



            if (self.values.pageNav) {


                //set up the navigation model.
                self.models.currentPageNav = new window.bazingaApp.models.pageNav(page);


                //get the config
                self.values.pageConfig = config = _.extend({ "count": true, "data": true, "completion": true, "score": false, "id": page.id }, page.track),

                    //find the index of the page navigation
                    self.values.pageNavIdx = _.findIndex(self.values.allPages, function(x) {
                        return x.id == page.id;
                    });

                self.setSuspendDataIndices();

                self.dataModel.setLessonLocation(self.values.pageNav.id);

                if ($.inArray(self.get('currentScreen'), ["dcom", "dcon", "dex", "dh", "dr"]) == -1) {

                    //reset the data
                    self.set('previousScreen', self.get('currentScreen'), { silent: true }); //currentScreen:null,
                    self.set('currentScreen', self.values.pageNav.id, { silent: true });
                }

                self.values.isDialogScreen = false;
                return self.values.pageNav.resource;
            } else {
                self.values.dialogNav = _.first(_.where(self.values.allDialogs, { resource: locationHref }));
                self.values.isDialogScreen = true;

                _.map(self.values.allDialogs, function(dialog) {
                    if (!dialog.role || !dialog.role[role] || !dialog.role[role].nav) {
                        return dialog;
                    }

                    var nav = dialog.role[role].nav;
                    if (_.isEmpty(nav)) {
                        return dialog;
                    }

                    _.each(nav, function(v, k) {
                        if (v === 'currentScreen' || v === "<<<") {
							
							if(self.values.dialogNav){
								//console.log("has id");
							}else{
								//console.log("ERROR: no id");
								alert("Please clear your cache and then refresh the page");
							}
							
                            nav[k] = self.values.dialogNav.id == 'dcon' ? previousScreen : currentScreen;
                        }
                    });

                    dialog.role[role].nav = nav;
                    return dialog;
                });
            }


        },

        /**
         * Initialize the page variables
         * If mark_course_complete_on_enter is true then the course will be automatically be marked as complete when this page is visited.
         * @returns {*}
         */
        pageInitializers: function() {
			//console.log("pageInitializers");
            var self = this,
                deferred = $.Deferred(),

                commitCourseStatus = function() {
					//console.log("self.values.pageConfig.mark_course_complete_on_enter");
					
                    var deferred = $.Deferred();
                    setTimeout(function() {
						
						//console.log(self.values);
						//console.log(self.values.pageConfig);
						//console.log(self.values.pageConfig.mark_course_complete_on_enter);
						
                        if (self.values && self.values.pageConfig && (self.values.pageConfig.mark_course_complete_on_enter)) {
							//console.log("commitCourseStatus");
                            self.dataModel.setLessonStatus('completed');
                            self.dataModel.commit("");
                        }
                        deferred.resolve();
                    }, window.pageLoadSpeed);
                    return deferred.promise();
                },
                commitPageStatus = function() {
                    var deferred = $.Deferred();

                    if (self.values && self.values.pageConfig && (self.values.pageConfig.completion && self.values.pageConfig.force_complete_on_enter)) {
                        self.models.currentSuspendData.setStatus('completed');
                    }
                    setTimeout(function() { deferred.resolve(); }, window.pageLoadSpeed);
                    return deferred.promise();
                },
                commitCount = function() {
                    var deferred = $.Deferred();
                    if (self.values && self.values.pageConfig && self.values.pageConfig.count) {
                        self.models.currentSuspendData.incrementCount();
                    }
                    setTimeout(function() { deferred.resolve(); }, window.pageLoadSpeed);
                    return deferred.promise();
                },
                initializePage = function() {
					
					//console.log("initializePage function");
					//console.log(self.values);
					//console.log(self.values.pageConfig);
					//console.log(self.values.pageConfig.mark_course_complete_on_enter);
					
                    var deferred = $.Deferred();
                    
					//dialog
					if(self.values && self.values.dialogNav){
						if(self.values.dialogNav.track.mark_course_complete_on_enter){
							//dialog set course complete
							self.dataModel.setLessonStatus('completed');
						}
					}
					
					//page
					if (self.values && self.values.pageConfig) {
                        if ((self.values.pageConfig.completion && self.values.pageConfig.force_complete_on_enter)) {
                            self.models.currentSuspendData.setStatus('completed');
                        }

                        if (self.values.pageConfig.count) {
							//console.log("INCREMENT COUNNNNT");
                            self.models.currentSuspendData.incrementCount();
                        }

                        if (self.values.pageConfig.auto_reset_on_enter) {
                            self.reattemptScreen(null, 'default', true);
                        }

                        if ((self.values.pageConfig.mark_course_complete_on_enter)) {
							//console.log("mark_course_complete_on_enter");
                            self.dataModel.setLessonStatus('completed');
                        }

                        if (self.values.pageConfig.complete_course_on_score) {
                            var primaryScore = self.get('primaryScore');
                            if (_.isNumber(primaryScore) && _.isNumber(self.values.pageConfig.complete_course_on_score) && (primaryScore >= self.values.pageConfig.complete_course_on_score)) {
                                self.setCourseScoreFrom('primary');
                                self.models.currentSuspendData.setStatus('completed');
                                self.dataModel.setLessonStatus('completed');
                            }
                        }

                    }

                    setTimeout(function() { deferred.resolve(); }, window.pageLoadSpeed);
                    return deferred.promise();
                };


            //orderly commit.
            //                commitPageStatus().always(function(){
            //                    commitCount().always(function(){
            //                        commitCourseStatus().always(function(){
            //                            self.suspendDataChanged(true).always(function(){deferred.resolve();})
            //                        });
            //                    })
            //                });

            initializePage()
                .always(function() {
                    self.suspendDataChanged(true).always(function() { deferred.resolve(); })
                });

            self.trigger("initialize:page", self);
            return deferred.promise();
        },

        getPageScore: function(id) {
			
			var suspendData = this.currentSuspendData || this.models.currentSuspendData;
            if (suspendData && typeof suspendData.getCompletion === 'function') {
                if (id !== undefined) {
                    var getSuspendData = window.bazingaApp.models.api.getSuspendData();
                    console.log("id:"+id);
					//console.log(getSuspendData);
                    return getSuspendData[id].sc || 0;
                } else {
                    return this.models.currentSuspendData.getScore();
                }
            }
			
        },
		
		/*resetModule:function(){
			//reset complete/data/count for all pages
			
			console.log("test reset");
		},*/

        setMultiple: function(values) {
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {

                _.each(values, function(v) {
                    if (v.key == 'score') {
                        self.dataModel.setScore(v.value);
                    } else if (v.key == 'status') {
                        self.dataModel.setLessonStatus(v.value);
                    }
                });

                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.resolve();
        },

        setComments: function(comment) {
            console.log("navigation setcomments");
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setLessonComments(comment);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        getComments: function() {
            var self = this;
            return self.dataModel.getLessonComments();
        },
		
		setInteractionStudentResponse: function(num,data) {
            console.log("navigation set student response");
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setLessonStudentResponse(num,data);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        /*write only
		getStudentResponse: function(id) {
            var self = this;
            return self.dataModel.getLessonStudentResponse(id);
        },*/
		
		setInteractionId: function(num,id) {
            console.log("navigation set interaction id");
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setLessonInteractionId(num,id);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        setSpeed: function(speed) {
            console.log("navigation setspeed");
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setLessonSpeed(speed);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        setCourseScore: function(score) {
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setScore(score);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },
        setCourseStatus: function(status) {
            var deferred = $.Deferred(),
                self = this;

            setTimeout(function() {
                self.dataModel.setLessonStatus(status);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        /**
         * Set up the course score from one of the primary / secondary / tertiary scores
         * @param scoreFrom
         */
        setCourseScoreFrom: function(scoreFrom) {
            scoreFrom = scoreFrom || 'primary';
            var score,
                self = this,
                deferred = $.Deferred();


            switch (scoreFrom) {
                case 'secondary':
                    score = this.get('secondaryScore') || -1;
                    break;
                case 'tertiary':
                    score = this.get('tertiaryScore') || -1;
                    break;
                case 'primary':
                default:

                    score = this.get('primaryScore') || -1;
                    break;
            }

            setTimeout(function() {
                if (score != -1) {
                    self.dataModel.setScore(score);
                    self.dataModel.commit("");
                }

                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },
        getCourseCompletion: function() {
            var self = this;
            return self.dataModel.getLessonStatus();
        },
        getPageCompletion: function(id) {
            //console.log("getPageCompletion");
            var suspendData = this.currentSuspendData || this.models.currentSuspendData;
            if (suspendData && typeof suspendData.getCompletion === 'function') {
                if (id !== undefined) {
                    var getSuspendData = window.bazingaApp.models.api.getSuspendData();
                    //console.log(getSuspendData);
                    return getSuspendData[id].a;
                } else {
                    return this.models.currentSuspendData.getCompletion();
                }
            }
            return null;
        },

        getPageData: function(id) {
            if (id !== undefined) {

                var suspendData = window.bazingaApp.models.api.getSuspendData();
                return suspendData[id].da;

            } else {
                //default to this page's data
                return this.models.currentSuspendData.getData();
            }
        },

        getPageDataForPage: function() {
            return this.models.currentPageNav;
        },

        getPageCount: function() {
            if (this.models.currentSuspendData == null) {
                return;
            }
            return this.models.currentSuspendData.getCount();
        },
        getAllPages: function() {
            return this.values.allPages;
        },

        getAllTrackablePages: function() {
            return _.filter(this.values.allPages, function(page) {

                if (page.type == "page") {
                    return page.track.completion;
                } else {
                    return false;
                }
            }, this);

        },

        getInfo: function(key) {
            return this.get(key);
        },

        setPrimaryScore: function(score) {
            return this.set('primaryScore', score);
        },
        setCourseData: function(data) {
            return this.set('courseData', data);
        },
        getCourseData: function() {
            return this.get('courseData');
        },
        getPrimaryScore: function() {
            return this.get('primaryScore');
        },
        setSecondaryScore: function(score) {
            return this.set('secondaryScore', score);
        },
        getSecondaryScore: function() {
            return this.get('secondaryScore');
        },
        setTertiaryScore: function(score) {
            return this.set('tertiaryScore', score);
        },
        getTertiaryScore: function() {
            return this.get('tertiaryScore');
        },

        getIsDialog: function() {
            return this.values.isDialogScreen;
        },

        /**
        Additional and aux params for bazinga
        */
        getParam: function(ix) {
            return this.get('param' + ix);
        },
        setParam: function(ix, param) {
            return this.set('param' + ix, param);
        },
        getParam1: function() {
            return this.get('param1');
        },
        getParam2: function() {
            return this.get('param2');
        },
        getParam3: function() {
            return this.get('param3');
        },
        getParam4: function() {
            return this.get('param4');
        },
		getLang: function() {
            return this.get('lang');
        },
		getOfflineId: function() {
            return this.get('oi');
        },
        getQuizAttempts: function() {
            return this.get('quizAttempts');
        },
        getProgress: function() {
            return this.get('progress');
        },
        setParam1: function(param) {
            return this.set('param1', param);
        },
        setParam2: function(param) {
            return this.set('param2', param);
        },
        setParam3: function(param) {
            return this.set('param3', param);
        },
        setParam4: function(param) {
            return this.set('param4', param);
        },
		setLang: function(lang) {
            return this.set('lang', lang);
        },
		setOfflineId: function(oi) {
            return this.set('oi',oi);
        },
        setQuizAttempts: function(qa) {
            return this.set('quizAttempts', qa);
        },

        getPreviousScreen: function() {
            return this.get('previousScreen');
        },
        getCurrentScreen: function() {
            return this.get('currentScreen');
        },

        getConfigForScreen: function() {
            return this.values.pageConfig;
        },
        getNavForScreen: function(id) {
            //console.log("getNavForScreen "+id);
            if (!id) {
                return this.values.pageNav;
            }
            return (_.first(_.where(this.values.allPages, { id: ("" + id + "") })));
        },
        getNavForDialog: function(id) {
            //get the nav for the right screen .
            return (_.first(_.where(this.values.allDialogs, { id: id })));
        },
        getNavForScreenByRole: function(role, id) {
            role = role || 'default';
			console.log("getNavForScreenByRole. role is "+role+". id is "+id);

            var nav;
            if (!id) {
				console.log("no id");
                nav = this.values.pageNav;
				console.log(this);
				console.log(this.values);
            } else {
				console.log("id is:"+id);
                nav = this.getNavForScreen(id);
            }
			console.log("getNavForScreenByRole. use nav:");
			console.log(nav);
            return (nav && nav.role && nav.role[role]) ? nav.role[role].nav : null;

        },

        getSuspendData: function() {
            return this.get('suspendData');
        },
        getRole: function() {
            return this.get('role');
        },

        getNav: function() {
			//console.log("get nav");
            return this.get('nav');
        },

        getDecision: function(decisionPoint, role, id) {
            //console.log("getDecision. decisionPoint: " + decisionPoint);
            //console.log("role "+role);
            //console.log("id " + id);
            var self = this,
                navForRole = _.memoize(self.getNavForScreenByRole),
                nav,
                navForDialog,
                role = self.get('role') || 'default';
            //console.log("this.getIsDialog()");
            //console.log(this.getIsDialog());
			
			//console.log("id "+id);
			
            if (this.getIsDialog()) {
                navForDialog = self.values.dialogNav;
                if (navForDialog && navForDialog.role && navForDialog.role[role]) {
                    nav = navForDialog.role[role].nav;
                    if (!nav) {
                        return false;
                    }
                    return nav[decisionPoint] || 'home';
                }
            } else {
                nav = navForRole(role, id);
				console.log("nav");
				console.log(nav);
                if (nav) {
					
					var autoPage = 'home';
					
					var pageId = parseInt(this.values.pageNav.id);
					
					if(decisionPoint == "next"){
							autoPage = pageId+1;
					}else if(decisionPoint == "back"){
						autoPage = pageId-1;
					}
					
					//console.log("autoPage "+autoPage);
					
                    return nav[decisionPoint] || autoPage;
                }
            }

            return null;
        },

        getAllDialogs: function() {
            return this.values.allDialogs;
        },
        getDialog: function(dialogname) {
            var dialogs = this.values.allDialogs;

            return _.first(_.where(dialogs, { id: (_(dialogname).getKeyHash()) }));
        },

        getLockables: function() {
			//console.log("getlockables");
			//console.log(this);
			//console.log(this.conditional);
            return this.conditional.lockables;
        },
        getCrumbs: function(id) {
            var self = this,
                nav,
                crumbs = [],
                ret;

            if (this.getIsDialog()) {
                return self.values.dialogNav['title'];
            }
            nav = self.getNavForScreen(id);
            crumbs = nav.crumbs;


            if (!_.isEmpty(crumbs)) {
                ret = [];
                _.each(crumbs, function(v) {
                    var n = self.getNavForScreen(v);
                    ret.push(n);
                });
                return ret;
            }

            return crumbs;
        },

        setPageCompletion: function(completion,optionalId) {
            if (!this.models || !this.models.currentSuspendData) {
                console.log("Cannot locate model to set page completion");
                return this;
            }
			
			if(completion == "completed"){
				$("[data-decision='next']").removeClass("is-disabled");
				$("[data-decision='next']").removeAttr('disabled');
			}
			
            if (optionalId !== undefined) {

                 var self = this;
                var currentSuspendData = window.bazingaApp.models.api.getSuspendData();
                var hashed = {
                    'completion': _("completion").getKeyHash()
                };
                var deferred = $.Deferred();
				if(completion == "completed"){
					completion = "c";
				}

                _.map(currentSuspendData, function(v) {
					//console.log(v);
                    if ((v.id) == optionalId) {
                        v[hashed.completion] = completion;
						//v.track.completion = "c";
						//console.log("v.id");
						//console.log(v.id);
						
						//var pageNav = window.bazingaApp.models.api.getNavForScreen(v.id);
						//pageNav.track.completion = true;
						//console.log(pageNav.track.completion);
                    }

                    return v;

                });
				//console.log("suspendDataChangeddddddddd");
                self.suspendDataChanged();

            }else{
				var self = this;
            this.models.currentSuspendData.setCompletion(completion);
				self.suspendDataChanged();
				
            return this;
            }
        },

        reattemptScreen: function(id, role, preventCommit) {
            var self = this,
                nav,
                reset,
                resetScores,
                resetStatus,
                resetData,
                deferred = $.Deferred(),
                currentSuspendData,
                hashed = {
                    'completion': _("completion").getKeyHash(),
                    'completed': _("completed").getKeyHash(),
                    'passed': _("passed").getKeyHash(),
                    'not_attempted': _("not attempted").getKeyHash(),
                    'score': _("score").getKeyHash(),
                    'data': _("data").getKeyHash()
                };
			
			console.log("reattemptScreen");

            role = role || 'default';

            if (this.values.isDialogScreen) {
                nav = this.values.dialogNav;
            } else if (!id) {
                nav = this.values.pageNav;
            } else if(id == "all"){
				nav = window.bazingaApp.models.navigation.getNav();
				
				self.set('primaryScore', null);
				
				currentSuspendData = self.get('suspendData');
				
            _.map(currentSuspendData, function(v) {
					//console.log(v[hashed.score]);
                if(v[hashed.score]){    
				v[hashed.score] = 0;
				}
                    v[hashed.completion] = hashed.not_attempted;
                    v[hashed.data] = null;
				v.co = 0;
				//console.log(v);
				return v;
            });
				
			}else {
                nav = this.getNavForScreen(id);
            }
			
			//console.log("NAVVVV");
			//console.log(nav);
			
			if(id != "all"){
				if (!nav || !_.has(nav, 'role') || !nav.role[role]) {
					return false;
				}

				nav = nav.role[role];

				if (!_.has(nav, 'reset')) {
					return false;
				}
				reset = nav.reset;
			
				console.log("end nav ");
				console.log(nav);

				resetScores = _.has(reset, 'score');
				resetStatus = _.has(reset, 'status');
				resetData = _.has(reset, 'data');

				if (_.has(reset, 'primaryScore')) {
					self.set('primaryScore', null);
				}

				currentSuspendData = self.get('suspendData');

				_.map(currentSuspendData, function(v) {
					if (resetScores && reset.score.indexOf(v.id) > -1) {
						v[hashed.score] = 0;
					}

					if (resetStatus && reset.status.indexOf(v.id) > -1) {
						v[hashed.completion] = hashed.not_attempted;
					}

					if (resetData && reset.data.indexOf(v.id) > -1) {
						v[hashed.data] = null;
					}

					return v;
				});
			}

            if (!preventCommit) {
                self.once("updated:suspendData", function() {
                    deferred.resolve();
                });

                self.updateSuspendData('scoringAndCompletion');
            } else {
                setTimeout(function() {
                    deferred.resolve();
                }, window.pageLoadSpeed);
            }

            return deferred.promise();
        },
        setPageData: function(data, optionalId, preventCommit) {
            console.log("setPageData");
            if (optionalId !== undefined) {
                var self = this;
                var currentSuspendData = window.bazingaApp.models.api.getSuspendData();
                var hashed = {
                    'data': _("data").getKeyHash()
                };
                var deferred = $.Deferred();


                //console.log(currentSuspendData);
                _.map(currentSuspendData, function(v) {
                    if ((v.id) == optionalId) {
                        v[hashed.data] = data;
                    }

                    return v;

                    /*var suspendData = window.bazingaApp.models.api.getSuspendData();
                            console.log(suspendData);
                
                            for(var i=0;i<suspendData.length;i++){
                                    if(suspendData[i].id == optionalId){
                                        
                                    }
                            }
                
                            return suspendData[optionalId].da; //change this to set not get*/
                });

                self.suspendDataChanged();

                /*if (!preventCommit) {
                    self.once("updated:suspendData", function() {
                        deferred.resolve();
                    });

                    self.updateSuspendData('scoringAndCompletion');
                } else {
                    setTimeout(function() {
                        deferred.resolve();
                    }, window.pageLoadSpeed);
                }

                return deferred.promise();*/


            } else {
                this.models.currentSuspendData.setData(data);
                return this;
            };
        },
        setInfo: function(key, value, options) {
            this.set(key, value);
            return this;
        },
        setCurrentPool: function(poolId) {
            this.set('currentPool', poolId);
            return this;
        },
        getCurrentPool: function() {
            return this.get('currentPool');
        },
        setPageScore: function(score,optionalId) {
			
			if (optionalId !== undefined) {
				
				var self = this;
                var currentSuspendData = window.bazingaApp.models.api.getSuspendData();
                var hashed = {
                    'score': _("score").getKeyHash()
                };
                var deferred = $.Deferred();

                //console.log(currentSuspendData);
                _.map(currentSuspendData, function(v) {
                    if ((v.id) == optionalId) {
                        v[hashed.score] = score;
                    }

                    return v;
                });

                self.suspendDataChanged();
				
			}else{
            this.models.currentSuspendData.setScore(score);
			}
            return this;
        },

        suspendDataDefaults: function(suspend, page, config) {
            suspend[_('id').getKeyHash()] = page.id;


            if (config.count) {
                suspend[_('count').getKeyHash()] = suspend[_('count').getKeyHash()] || ''; //0
            }
            if (config.data) {
                suspend[_('data').getKeyHash()] = suspend[_('data').getKeyHash()] || '';
            }
            //block track
            if (_.has(page, 'block-track') || !_.has(page, 'track')) {
                //completion
                if (config.completion) {
                    suspend[_('completion').getKeyHash()] = _(suspend[_('completion').getKeyHash()] || 'not attempted').getKeyHash();
                }
                //score
                if (config.score) {
                    suspend[_('score').getKeyHash()] = suspend[_('score').getKeyHash()] || ''; //0
                }
            }
            return suspend;
        },
        /**
         * Create a suspend data
         */
        retrieveSuspendData: function() {
            var attributes = this.attributes,
                self = this,
                hashedPage = _('page').getKeyHash(),
                suspendData = (function() {
                    var sus = {};
                    sus[hashedPage] = {};
                    return sus;
                }()),
                currentSuspendData = self.get('suspendData'),
                getData = function(pages) {
                    _.map(pages, function(page) {

                        var config = _.extend({ "count": true, "data": true, "completion": true, "score": false }, page.track),
                            suspend = (function() {
                                var data = _.filter(currentSuspendData, function(it) {
                                    return it.id == page.id;
                                });
                                if (data.length == 0) {
                                    return {}
                                }
                                return _.first(data);
                            }());


                        suspend = self.suspendDataDefaults((suspend || {}), page, config);

                        if (_.has(suspend, 'type')) { delete suspend.type; }


                        if (!_.has(page, 'items')) {
                            suspendData[hashedPage][page.id] = suspend;
                        } else {
                            getData(page.items);
                        }
                    });
                };

            _.map(attributes, function(v, k) {
                var hashedKey = _(k).getKeyHash();

                if (k !== 'preferred') {
                    //Do nothing
                    if (k == 'suspendData') {
                        return true;
                    }
                    suspendData[hashedKey] = v;
                    return true;
                }
                getData(v.pages);
                return true;
            });


            return (function() {
                var stringified = _(suspendData).crunchSuspendData();
                return stringified;
            }());
        },


        setDataModel: function(dataModel) {
            this.dataModel = dataModel;
            if (typeof dataModel.setNavModel == 'function') {
                dataModel.setNavModel(this);
            }

            this.initializeDataModelListeners();
            return this;
        },
        setCourseConfig: function(courseConfig) {
            this.courseConfig = courseConfig;
            return this;
        },
        getCourseConfig: function() {
            return this.courseConfig;
        },
        initializeDataModelListeners: function() {

        }
    });

})(window.$ || window.JQuery);
