(function($){
    "use strict";

    window.bazingaApp.models.dataModel = Backbone.Model.extend({
        defaults: {
            lesson_location:  '',
            student_name: '',
            lesson_status: 'not attempted',
            score_raw: null,
            score_min: 0,
            score_max: 100,
            suspend_data: '',
            comments: 'comments',
            student_preference_audio: '0',
            student_preference_language: 'en_En',
            student_preference_speed: '0',
            student_preference_text: '0',
            mastery_score : null,
            'exit':'',
            'role':'learner',
            'courseVisits':0
        },
        changedSinceSync : [],
        dirty  : false,


        initialize : function(){
            var self=this;
			
			/*if(self.navModel){
				console.log("found navmodel in self");
			console.log(self.navModel);
		}*/
			var suspendString = 'cmi.suspend_data';
			
			//if offline
			var isOffline = window.localStorage.getItem("isOffline");
			var offlineId = window.localStorage.getItem("offlineId");
			
			//var offlineId = window.bazingaApp.models.api.getOfflineId();
			
			
			if(isOffline == "true" && offlineId != null){
				//console.log("is offline. add: "+offlineId);
				suspendString += ".";
				suspendString +=offlineId;
			}
			
			//console.log("offline id: "+suspendString);
			
            this.hash = _.extend({},{
                'lesson_location':'cmi.core.lesson_location',
                'student_name' :  'cmi.core.student_name',
                'credit':'cmi.core.credit',
                'lesson_status':'cmi.core.lesson_status',
                'entry':'cmi.core.entry',
                'score_raw':'cmi.core.score.raw',
                'score_min':'cmi.core.score.min',
                'score_max':'cmi.core.score.max',
                'suspend_data':suspendString,
                'launch_data':'cmi.core.launch_data',
                'mastery_score':'cmi.student_data.mastery_score',
                'comments':'cmi.comments',
                'comments_from_lms':'cmi.core.comments_from_lms',
                'student_preference_audio':'cmi.student_preference.audio',
                'student_preference_language':'cmi.student_preference.language',
                'student_preference_speed':'cmi.student_preference.speed',
                'student_preference_text':'cmi.student_preference.text'
            });

            _.bindAll(this,'upload','commit');
            this.on("change",this.upload ,self);
        },

        autoSave : function(){
            var self = this;
            var check = function(){
                setTimeout(function(){
                    self.upload(true).always(check);
					if (window.console) {
                    console.log("Data autosaved");
					}
                },10000);
            };
            check();
        },

        fetch : function(options){
            var self=this,
                API= self.API,
                keys,
                deferred= $.Deferred(),
                val;

            if(!API){return false;}

            setTimeout(function(){
                //Start loading all the values
                _.each(self.hash,function(keyhash,key){
                    val = API.LMSGetValue(keyhash);
                    self.set(key,val,{silent: true});
                });
                deferred.resolve(self);
            },500);
            return deferred.promise();
        },
        isDirty : function(){return this.dirty;},
        getChangedSinceSync : function(){return this.changedSinceSync;},
        commit : function(){
            var self=this,
                API= self.API;

            if(!API) return false;
            console.log("Changed called -> committing");
            API.LMSCommit("");
            return true;
        },
        upload : function (commit) {
            //options.data = _.pick(this.attributes, 'foo', 'bar', 'baz');
            var self=this,
                API= self.API,
                deferred= $.Deferred(),
                val,
                changed,
                hashedKey;

            commit = commit || false;
			
			//don't commit if loading
			function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
			
			if(getCookie("finishLoad") == "no"){
				commit = false;
			}
			
			//console.log("API?");
			//console.log(API);
			
            if(!API){
                setTimeout(function(){deferred.fail();},10);
            }
            else{
                setTimeout(function(){
                    changed = self.changed;
                    if(self.dirty){

                        console.log("---uploading value . . .");
                        _.each(self.changedSinceSync, function(key){
                             val = self.get(key);
                             if(_.has(self.hash,key)){
                                 hashedKey  = self.hash[key];
                                 API.LMSSetValue(hashedKey,val);
                                 console.log("new val: "+hashedKey +" = "+val);
                             }
                        });
						
						//save offline id to localstorage
						/*if(window.localStorage.getItem("isOffline")){
						var offlineId = window.bazingaApp.models.api.getOfflineId();
						window.localStorage.setItem("offlineId",offlineId);
						}*/
							
                        console.log("---upload complete.");

                        self.changedSinceSync = [];
                        self.dirty = false;
						if(getCookie("finishSaving") != "yes"){
						document.cookie = "finishSaving=yes"; 
						}
                    }
                    if(commit){
                        API.LMSCommit("");
                    }

                    deferred.resolve();
                },500);
            }
            return deferred.promise();
        },

        setData : function(){
			//console.log("data model setData");
            var self=this,
                argumentsArray = [].slice.apply(arguments),
                attr = argumentsArray[0],
                value = argumentsArray[1],
                change = function(attr,value){
                    self.set((""+attr+""),value);
                    if(_.indexOf(self.changedSinceSync,(""+attr+"")) == -1){
                        //if($.inArray(self.changedSinceSync,(""+attr+"")) == -1, _)){
                        self.changedSinceSync.push((""+attr+""));
                        self.dirty = true;
                    }
                };



            if(!attr){return false;}

            if(typeof attr == 'object'){
                return _.each(attr,this.setData);
            }
            else{
				
				//console.log("set data. attr: "+attr);
				
                switch(attr){
                    case "suspend_data":
                    case "lesson_location":
                    case "comments":
                        //allow write freely
                        break;
                    case "score_min":
                        var max=self.getData('score_max');
                        if( (_.isNumber(value) && value)  && value >= 0 && value <=100 && (!_.isNumber(max) || (value < max))) {
                            change(attr,value);

                            return true;
                        }

                        change(attr,0);
                        break;

                    case "score_max":
                        var min=self.getData('score_min');

                        if( (_.isNumber(value) && value)  && value > 0 && value <=100 && (!_.isNumber(min) || (value > min))) {
                            change(attr,value);
                            return true;
                        }
                        change(attr,100);
                        return false;
                        break;

                    case 'score_raw':
                        if(_.isNumber(value)) {
                            var currentStatus=self.getData('lesson_status');


//                            if(['passed','completed'].indexOf(currentStatus) > -1){
//                                //Do not update score after the course is completed
//                                return false;
//                            }


                            value =(function(){
                                var min=self.getData('score_min'),
                                    max=self.getData('score_max');

                                if(value === null || value === ''){return null;}

                                if(!_.isNumber(min)||!_.isNumber(max)){
                                    //ceil off the value
                                    return (value <= 0) ? 0 : ((value >= 100) ? 100 : value);
                                }

                                if(min >= max ){return value;}
                                value = (value <= min) ? min : ((value >= max) ? max : value);

                                //convert to percentage
                                return ((value-min)/(max-min))*100;
                            })();
                        }

                        var currentScore = self.getData('score_raw');
                        if(_.isNumber(currentScore) && (!_.isNumber(value) || currentScore > value)){
                            //If the current score is greater than the attempted set then dont update
                            return false;
                        }


                        var masteryScore = self.getData('mastery_score');

                        if(!_.isNumber(value)){
                            //Bad hack . have to return false but then have ot set values as well
                            if(!this.get(attr)){
                                this.set((""+attr+""),null);
                            }
                            return false;
                        }


                        if(masteryScore){
                            if(value < masteryScore){
                                this.setData('lesson_status','failed');
                            }
                            else if(value >= masteryScore){
                                this.setData('lesson_status','passed');
                            }
                        }

                        break
                    case 'lesson_status':
                        if( $.inArray(value, ['not attempted','incomplete','completed','passed','failed']) == -1){
                            return false;
                        }
                        var currentStatus=self.getData('lesson_status');

                        if(currentStatus == 'passed'){return false;}
                        else if(currentStatus=='completed' && value !='passed'){return false;}
                        else if(currentStatus=='failed' && ['passed','completed'].indexOf(value) == -1){return false;}
                        else if(currentStatus=='incomplete' && (value=='not attempted' || value=='incomplete')){return false;}
                        else if(currentStatus == value){return false;}
                        break;

                    case 'total_time':
                    case 'session_time':
                        //do some testing around total time
                        break;

                    case 'entry':
                        if( $.inArray(value, ['ab-initio','resume']) == -1){
                            return false;
                        }
                        break;

                    case 'exit':
                        if(['time-out','suspend','logout',''].indexOf(value) == -1){
                            return false;
                        }
                        break;

                    case 'launch_data':
                    case 'lesson_mode':
                    case 'student_name':
                    case 'comments_from_lms':
                    case 'name':
                    case 'credit':
                    case 'mastery_score':
                        //read only values
						//console.log("read only value");
                        return false;

                    case 'student_preference_audio':
                        if(value !== '' && (!_.isNumber(value) || -1 > value || 100 < value)){
                            return false;
                        }
                        break;
                    case 'student_preference_speed':
                        if(value !== '' && (!_.isNumber(value) || -100 > value || 100 < value)){
                            return false;
                        }
                        break;
                    case 'student_preference_text':
                        if(value !== '' && (!_.isNumber(value) || -1 > value || 1 < value)){
                            return false;
                        }
                        break;
                    default:
                        break;
                }

                change(attr,value);
            }

            return true;
        },
        getData : function(){
            var self=this,
                argumentsArray = [].slice.apply(arguments),
                attr = argumentsArray[0]; //eg. comments
				/*console.log("dataModel-getData");
				console.log(argumentsArray);
				console.log(attr);*/
			
			//console.log("getData. attr: "+attr);

            /*todo  : handle interactions*/
            return this.get(attr);
        },

        setAPI : function(API){
            this.API = API;
            return this;
        },
        getAPI : function(){
            return this.API;
        },
        setNavModel : function(navModel){
            this.navModel = navModel;
            return this;
        },
        getNavModel : function(){
            return this.navModel || null;
        },
        //Utility methods
        setLessonLocation: function(lesson_location){
            return this.setData('lesson_location',lesson_location);
        },

        getLessonLocation : function(){
            return this.getData('lesson_location');
        },

        setLessonStatus: function(lesson_status){
            return this.setData('lesson_status',lesson_status);
        },

        getLessonStatus : function(){
            return this.getData('lesson_status');
        },
		setLessonComments : function(comment){ 
			//console.log("data model set comments: "+comment);
			var self=this,
                API= self.API;

            //this.setData('comments',comment);
            API.LMSSetValue('cmi.comments',comment);
			
            return this;
        },
		
		getLessonComments: function(){
			//console.log("datamodel-get comments");
            return this.getData('comments');
        },
		
		setLessonStudentResponse : function(num,data){ 
			//console.log("data model set StudentResponse: "+data);
			var self=this,
                API= self.API;

            //this.setData('comments',comment);
			API.LMSSetValue('cmi.interactions.'+num+'.type','performance');
            API.LMSSetValue('cmi.interactions.'+num+'.student_response',data);
			
			//API.LMSSetValue('cmi.interactions_'+num+'.type','performance');
            API.LMSSetValue('cmi.interactions_'+num+'.student_response',data);
			
            return this;
        },
		
		setLessonInteractionId : function(num,id){ 
			//console.log("data model set interaction id: "+id);
			var self=this,
                API= self.API;

            //this.setData('comments',comment);
			API.LMSSetValue('cmi.interactions.'+num+'.type','performance');
            API.LMSSetValue('cmi.interactions.'+num+'.id',id);
			
			//API.LMSSetValue('cmi.interactions_'+num+'.type','performance');
            //API.LMSSetValue('cmi.interactions_'+num+'.id',id);
			
			//API.LMSSetValue('cmi.interactions.'+num+'objectives.0.id',id);
			
            return this;
        },
		
		/*write only
		
		getLessonStudentResponse: function(id){
			console.log("datamodel-get StudentResponse");
            return this.getData('studentResponse',id);
        },*/
		
		setLessonSpeed : function(speed){
			//console.log("data model set speed: "+speed);
			var self=this,
                API= self.API;

            //this.setData('comments',comment);
            API.LMSSetValue('cmi.student_preference.speed',speed);
            return this;
        },
        setScore : function(score){
            return this.setData('score_raw',score);
        },
        getScore : function(){
            return this.getData('score_raw');
        },
        getSuspendData : function(){
			
			var suspendString = 'suspend_data';
			
			//if offline
			var isOffline = window.localStorage.getItem("isOffline");
			var offlineId = window.bazingaApp.models.api.getOfflineId();
			
			if(offlineId == null){
				offlineId = window.localStorage.getItem("offlineId");
				window.bazingaApp.models.api.setOfflineId(offlineId);
			}
			
			//window.localStorage.setItem("offlineId",offlineId); 
			//console.log("is offline? "+isOffline+" . Id is "+offlineId);
			
			if(isOffline == "true" && offlineId != null){
				//console.log("is offline. add: "+offlineId);
				suspendString = 'cmi.suspend_data.';
				suspendString +=offlineId;
				
				//console.log("datamodel getsuspenddata offline. "+suspendString+ " : " + window.localStorage.getItem(suspendString));
				
				return window.localStorage.getItem(suspendString);
			}
			
            var d =  this.getData(suspendString);
			
			console.log(d);
			
            if(d==undefined || d == 'undefined' || d == null || !d){
                d = '';
            }
            return d;
        },
		
		//used for below
		getCookie: function(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
},
		
        forceSetSuspendData : function(suspend_data){
			
			//console.log("forceSetSuspendData");
            var self=this,
                API= self.API;
			
			/*if(this.getCookie("finishLoad") == "no"){
				return false;
			}*/
			
			//save to local storage?
			this.setData('suspend_data',suspend_data);
			
			
			var isOffline = window.localStorage.getItem("isOffline");
			var offlineId = window.bazingaApp.models.api.getOfflineId();
			
			//console.log("1) isOffline? "+isOffline + ". 2) offlineId? "+ offlineId);
			
			if(isOffline == "true" && offlineId != null){
				//console.log("is offline");
				API.LMSSetValue('cmi.suspend_data.'+offlineId,this.get('suspend_data'));
			}
            else{
				//console.log("not offline. set to: "+this.get('suspend_data'));
				API.LMSSetValue('cmi.suspend_data',this.get('suspend_data'));
				//console.log("suspend data force changed to: "+API.LMSGetValue('cmi.suspend_data') +" . ");
			}
			
            return this;
        },
        setSuspendData: function(suspend_data,force){
			//console.log("not force");
			
			//save to local storage?
            this.setData('suspend_data',suspend_data);
            return this;
        },
        getMasteryScore : function(){
            return this.getData('mastery_score');
        },
        setAudioPreference : function(audioPreference){
            this.set('student_preference_audio',audioPreference);
            return this;
        }, 
        getAudioPreference : function(){
            return this.get('student_preference_audio');
        },
        getSpeedPreference : function(){
            return this.get('student_preference_speed');
        },
        setSpeedPreference : function(speedPreference){
            this.set('student_preference_speed',speedPreference);
            return this;
        },
        getLanguagePreference : function(){
            return this.get('student_preference_language');
        },
        setLanguagePreference : function(languagePreference){
            this.set('student_preference_language',languagePreference);
            return this;
        },
        getTextPreference : function(){
            return this.get('student_preference_text');
        },
        setTextPreference : function(textPreference){
            this.set('student_preference_text',textPreference);
            return this;
        },
        incrementScore : function(increment){
            var raw = this.getScore();
            this.setScore(raw+increment);
        }
    });

})(window.$||window.JQuery);