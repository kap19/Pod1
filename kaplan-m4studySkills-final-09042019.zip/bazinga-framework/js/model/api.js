(function($){
    "use strict";

    window.bazingaApp.models.API = Backbone.Model.extend({
        'load': function(courseConfig){
			if (window.console) {
			console.log("api load start");
			}
            var self=this,
                deferred = $.Deferred();
			//console.log(self.courseConfig);
			//console.log(window.bazingaCourseConfig);
			
			self.courseConfig = window.bazingaCourseConfig;
			
			try{ self.courseConfig = offlineConfig; }
				catch(err) {
					if (window.console) {
					console.log("api. no offlineConfig");
					}
				}

            window.bazingaApp.models.scorm12 = self.scorm12 = new  window.bazingaApp.models.scormDataModel();
            self.scormAPI =  window.bazingaApp.models.scorm12.get('API');

            window.bazingaApp.models.data= this.data = new window.bazingaApp.models.dataModel();
            this.data.setAPI(self.scormAPI);
            self.trigger("initialize:dataModel",self);

            this.data
                .fetch()
                .always(function(dataModelContext){
				
                    if(window.bazingaApp.models.data.getLessonStatus()){
                        //Lets start the course
                        window.bazingaApp.models.data.setLessonStatus('incomplete');
                    }
				
				function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
				
                    // initialize
				if(getCookie("finishLoad") == "yes"){
                    self.scormAPI.LMSCommit("");
				}
					
                    self.trigger(" ",self);
                    //load the navigation/
                    window.bazingaApp.models.navigation = self.navigation = new window.bazingaApp.models.navigationModel();
					//console.log("load navigation");

                    window.bazingaApp.models.navigation.once('initialize:handshake', function () {
						//console.log("initialize:handshake1");
                        self.trigger('initialize:handshake',self);
						//console.log("initialize:handshake2");
                    });
                    window.bazingaApp.models.navigation.once('initialize:suspendData', function () {
						//console.log("initialize:suspendData");
                        self.trigger('initialize:suspendData',self);
                    });
                    window.bazingaApp.models.navigation.once('initialize:page', function () {
                        self.trigger('initialize:page',self);
                    });
				
					/*if(offlineNav != undefined){
							self.courseConfig = offlineConfig;
					}*/
				
				try{ self.courseConfig = offlineConfig; }
				catch(err) {
					if (window.console) {
					console.log("api2. no offlineconfig")
					}
				}
				
					//console.log(self.courseConfig);
					var navContent = self.courseConfig.navigation.src;
				
				//console.log("navContent is");
				//console.log(navContent);
				
                    window.bazingaApp.models.navigation
                        .setDataModel(dataModelContext)
                        .setCourseConfig(courseConfig)
                        .load(navContent)
                        .always(function(navModelContext){
                            self.trigger("initialize:navigation",self);
                            //initializing nav api
                            deferred.resolve(self);
                        });
				
				//console.log("TESTTTTTTTTTTTT");
				//console.log(courseConfig);
				//console.log(self.courseConfig);
				
                });
			//console.log("api load finish");
            return deferred.promise();
        },
		
		//apis
		getCourseCompletion : function(){return window.bazingaApp.models.navigation.getCourseCompletion();},
        setCourseStatus :  function(status){return window.bazingaApp.models.navigation.setCourseStatus(status);},
		
        setPageScore :  function(score,id){return window.bazingaApp.models.navigation.setPageScore(score,id);},
        getPageScore :  function(id){return window.bazingaApp.models.navigation.getPageScore(id);},
		
        setPageInfo : function(info){window.bazingaApp.models.navigation.setInfo(info); return self;}, //make a custom param
		getInfo : function(info){return window.bazingaApp.models.navigation.getInfo(info);},
		
        setPageCompletion : function(completion,optionalId){window.bazingaApp.models.navigation.setPageCompletion(completion,optionalId); return self;},
        setPageData : function(data,optionalId){window.bazingaApp.models.navigation.setPageData(data,optionalId); return self;},
        reattemptScreen : function(screen,role){return window.bazingaApp.models.navigation.reattemptScreen(screen,role);}, //trigger reset on pages specified in the config
        setCourseScore :  function(score){return window.bazingaApp.models.navigation.setCourseScore(score);},
        setMultiple :  function(values){return window.bazingaApp.models.navigation.setMultiple(values);},
        setCourseScoreFrom :  function(score){return window.bazingaApp.models.navigation.setCourseScoreFrom(score);},
        getPageCompletion : function(id){return window.bazingaApp.models.navigation.getPageCompletion(id);}, //returns eg: c or undefined
        getPageData : function(id){return window.bazingaApp.models.navigation.getPageData(id);}, //does this work?
		getPageDataForPage : function(){return window.bazingaApp.models.navigation.getPageDataForPage();}, //gets all info about page from config. eg: .attributes.parent
        getLockables : function(){return window.bazingaApp.models.navigation.getLockables();},
        getPageCount : function(){return window.bazingaApp.models.navigation.getPageCount();},
		getProgress : function(){return window.bazingaApp.models.navigation.getProgress();},
        getAllPages : function(){return window.bazingaApp.models.navigation.getAllPages();},
		getAllTrackablePages : function(){return window.bazingaApp.models.navigation.getAllTrackablePages();}, //gets an array of all pages with completion: true, use .length to get total number
        
        getPreviousScreen : function(){return window.bazingaApp.models.navigation.getPreviousScreen();}, //get the last screen you were on
        getConfigForScreen :function(){return window.bazingaApp.models.navigation.getConfigForScreen();}, //shorter method than getPageDataForPage, eg: var.completion
        getNavForScreen :function(id){return window.bazingaApp.models.navigation.getNavForScreen(id);},
        getNavForDialog :function(id){return window.bazingaApp.models.navigation.getNavForDialog(id);},
        getNavForScreenByRole :function(role,id){return window.bazingaApp.models.navigation.getNavForScreenByRole(role,id);},
        getDecision : function(decisionPoint,role,id){return window.bazingaApp.models.navigation.getDecision(decisionPoint,role,id);}, //gets next or back pages and any custom int/string you want stored for a page
        getRole : function(){return window.bazingaApp.models.navigation.getRole();},
        getIsDialog : function(){return window.bazingaApp.models.navigation.getIsDialog();},  
        getCrumbs : function(){return window.bazingaApp.models.navigation.getCrumbs();},
        getNav : function(){return window.bazingaApp.models.navigation.getNav();},
        getSuspendData : function(){return window.bazingaApp.models.navigation.getSuspendData();}, //can access pages' data with var.[11] <- page id
        setPrimaryScore : function(score){return window.bazingaApp.models.navigation.setPrimaryScore(score);},
        getPrimaryScore : function(score){return window.bazingaApp.models.navigation.getPrimaryScore();},
		
		setParam : function(ix,param){return window.bazingaApp.models.navigation.setParam(ix,param);},
        getParam : function(ix){return window.bazingaApp.models.navigation.getParam(ix);},
        setParam1 : function(param){return window.bazingaApp.models.navigation.setParam1(param);},
        getParam1: function(){return window.bazingaApp.models.navigation.getParam1();},
        setParam2 : function(param){return window.bazingaApp.models.navigation.setParam2(param);},
        getParam2 : function(){return window.bazingaApp.models.navigation.getParam2();},
        setParam3 : function(param){return window.bazingaApp.models.navigation.setParam3(param);},
        getParam3 : function(){return window.bazingaApp.models.navigation.getParam3();},
        setParam4 : function(param){return window.bazingaApp.models.navigation.setParam4(param);},
        getParam4 : function(){return window.bazingaApp.models.navigation.getParam4();},
		
		//resetModule: function(){return window.bazingaApp.models.navigation.resetModule();}, //resets all progress
		
		setLang : function(lang){return window.bazingaApp.models.navigation.setLang(lang);},
        getLang : function(){return window.bazingaApp.models.navigation.getLang();},
		setOfflineId : function(oi){return window.bazingaApp.models.navigation.setOfflineId(oi);},
        getOfflineId : function(){return window.bazingaApp.models.navigation.getOfflineId();},
        setQuizAttempts : function(qa){return window.bazingaApp.models.navigation.setQuizAttempts(qa);},
        getQuizAttempts : function(){return window.bazingaApp.models.navigation.getQuizAttempts();},
		setComments : function(comment){return window.bazingaApp.models.navigation.setComments(comment);}, //no mandatory field in lms. another 4,096 character string like suspend data
		getComments : function(){return window.bazingaApp.models.navigation.getComments();},
		
		setInteractionStudentResponse: function(num,data){return window.bazingaApp.models.navigation.setInteractionStudentResponse(num,data);},
		setInteractionId: function(num,id){return window.bazingaApp.models.navigation.setInteractionId(num,id);},
		//write only
		//getStudentResponse: function(id,data){return window.bazingaApp.models.navigation.getStudentResponse(id);},
		
		setSpeed : function(speed){return window.bazingaApp.models.navigation.setSpeed(speed);}, //
        setSecondaryScore : function(score){return window.bazingaApp.models.navigation.setSecondaryScore(score);},
        getSecondaryScore : function(score){return window.bazingaApp.models.navigation.getSecondaryScore();},
        setTertiaryScore : function(score){return window.bazingaApp.models.navigation.setTertiaryScore(score);},
        getTertiaryScore : function(score){return window.bazingaApp.models.navigation.getTertiaryScore();},
        setCourseData : function(data){return window.bazingaApp.models.navigation.setCourseData(data);},
        getCourseData : function(){return window.bazingaApp.models.navigation.getCourseData();},
        setCurrentPool : function(poolId){return window.bazingaApp.models.navigation.setCurrentPool(poolId);},
        getCurrentPool : function(){return window.bazingaApp.models.navigation.getCurrentPool();},
        getCourseConfig : function(){return this.courseConfig;}, //gets course config data from config.json eg: var.last_updated
		
        getScorm12DataModel : function(){return this.scorm12;},
        getScormAPI : function(){return this.scormAPI;}, //eg. var.attributes["cmi.suspend_data"]); cmi.core.lesson_location not working for some reason though
        getData : function(){return this.data;}, // gets course info eg: var._previousAttributes.role
        getNavigation : function(){return this.navigation;}, //not sure, returns a bunch of api functions
		//use getCookie sparingly, most useful for detecting when data is done saving to the lms by changing the cookie 'finishSaving' from it's default of 'yes'
		getCookie :function(cname){ 
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for(var i = 0; i < ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0) == ' ') {
					c = c.substring(1);
				}
				if (c.indexOf(name) == 0) {
					return c.substring(name.length, c.length);
				}
			}
			return "";
		},

        shutDown : function(){
            var self=this;
            window.bazingaApp.models.scorm12.switchTimers();

            window.bazingaApp.models.data.commit("");
            window.bazingaApp.models.scorm12
                .finishSCO()
                .always(function(){
                    //Navigate to exit page
				
                    window.location.replace(self.courseConfig.finishPage);
				
					//close parent for popup
				
				/*console.log("close parent for popup");
				
				setTimeout(function() {
					window.opener = top;
					window.opener.close();
    			}, 2000);*/
				
                });
        }

    });

})(window.$||window.JQuery);