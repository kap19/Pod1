(function(){

    window.pageLoadSpeed = 10;
    window.debug = false;

    window.bazingaApp = window.bazingaApp || {};
	
	window.bazingaApp.models = window.bazingaApp.models || {};
	window.bazingaApp.collections = window.bazingaApp.collections || {};
	window.bazingaApp.views = window.bazingaApp.views || {};
    window.bazingaApp.views.components = window.bazingaApp.views.components || {};


}());
