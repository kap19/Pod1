(function ($) {
    "use strict";


    var     translations= {

            },
            hashed = {
                'id': 'id',
                'preferred': 'pr',
                'data': 'da',
                'suspendData': 'sd',
                'role': 'ro',
                'currentScreen':'cs',
                'previousScreen' : 'ps',
                'score' : 'sc',
                'primaryScore' : 'x',
                'secondaryScore' : 'y',
                'tertiaryScore' : 'z',
                'gotoScreen' : 'gs',
                'count': 'co',
                'views':'vie',
                'completion': 'a',
                'page': 'pa',
                'not attempted': 'n',
                'passed': 'p',
                'failed': 'f',
                'completed': 'c',
                'incomplete': 'i',
                'courseScore' :'zs',
                'courseCompletion' : 'zc',
                'courseStatus' : 'crs',
                'progress' :'pg',
                'dialog-continue':'dcon',
                'dialog-complete':'dcom',
                'dialog-exit' : 'dex',
                'dialog-help' : 'dh',
                'courseData' : 'cd',
                'currentPool' : 'cp',
				'param1' : 'p1',
				'param2' : 'p2',
				'param3' : 'p3',
				'param4' : 'p4',
				'quizAttempts' : 'qa',
				'lang':'la',
				'offlineId':'oi'
				
            },
        sanitizeMap  = {
            '&': '_%',
            '"': '_^',
            "'": '_*'
        },
        deSanitizeMap = _.invert(sanitizeMap),
        createSanitizeEscaper = function(map) {
            var escaper = function(match) {
                return map[match];
            };
            var source = '(?:' + _.keys(map).join('|') + ')';
            var testRegexp = RegExp(source);
            var replaceRegexp = RegExp(source, 'g');
            return function(string) {
                string = string == null ? '' : '' + string;
                return testRegexp.test(string) ? string.replace(replaceRegexp, escaper) : string;
            };
        },
        crunchSuspendData = function(){
            return function(data){
                var crunched = JSON.stringify(data);
                return (crunched.replace(/"/g,'*'));
            };
        },
        uncrunchSuspendData =  function(){
            return function(data){
                if(!_.isString(data)){return data;}
                var uncrunched = (data.replace(/\*/g,'"'));
                if(!uncrunched || uncrunched == ''){return {}}
                return JSON.parse(JSON.stringify(eval("(" + uncrunched + ")")));
            };
        };

    _.mixin({sanitizeScormString : createSanitizeEscaper(sanitizeMap)});
    _.mixin({deSanitizeScormString : createSanitizeEscaper(deSanitizeMap)});
    _.mixin({crunchSuspendData : crunchSuspendData()});
    _.mixin({uncrunchSuspendData : uncrunchSuspendData()});

    _.mixin({
        getKeyHash: function (hash) {
            return _.has(hashed,hash)? hashed[hash] : hash;
        }
    });

    _.mixin({
        translateText: function(text){
            return _.has(translations,text)? translations[text] : text;
        }
    });

    _.mixin({
        padNumber : function(n, width, z) {
            z = z || '0';
            n = n + '';
            width = width || 2;
            return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
        }
    });

    _.mixin({
        capitalize: function(string) {
            return string.charAt(0).toUpperCase() + string.substring(1).toLowerCase();
        }
    });


    // Usage:
    //
    // var obj = {
    //   a: {
    //     b: {
    //       c: {
    //         d: ['e', 'f', 'g']
    //       }
    //     }
    //   }
    // };
    //
    // Get deep value
    // _.deep(obj, 'a.b.c.d[2]'); // 'g'
    //
    // Set deep value
    // _.deep(obj, 'a.b.c.d[2]', 'george');
    //
    // _.deep(obj, 'a.b.c.d[2]'); // 'george'
    _.mixin({

        // Get/set the value of a nested property
        deep: function (obj, key, value) {

            var keys = key.replace(/\[(["']?)([^\1]+?)\1?\]/g, '.$2').replace(/^\./, '').split('.'),
                root,
                i = 0,
                n = keys.length;

            // Set deep value
            if (arguments.length > 2) {

                root = obj;
                n--;

                while (i < n) {
                    key = keys[i++];
                    obj = obj[key] = _.isObject(obj[key]) ? obj[key] : {};
                }

                obj[keys[i]] = value;

                value = root;

                // Get deep value
            } else {
                while ((obj = obj[keys[i++]]) != null && i < n) {};
                value = i < n ? void 0 : obj;
            }

            return value;
        }
    });


    _.mixin({
        pluckDeep: function (obj, key) {
            return _.map(obj, function (value) { return _.deep(value, key); });
        }
    });


    _.mixin({

        // Return a copy of an object containing all but the blacklisted properties.
        unpick: function (obj) {
            obj || (obj = {});
            return _.pick(obj, _.difference(_.keys(obj), _.flatten(Array.prototype.slice.call(arguments, 1))));
        }

    });
})(window.$ || window.JQuery);