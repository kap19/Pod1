
if (!window.timeManager) {
    window.timeManager = function(){
        var self = this;
        self.hr = 0;
        self.min = 0;
        self.sec = 0;
        self.running = false;


        this.fromString = function(str){
            var split = (str || "00:00:00").split(":");

            self.hr = (parseInt(split[0]) || 0);
            self.min = (parseInt(split[1]) || 0);
            self.sec = (parseFloat(split[2]) || 0);
            //console.log(self);
            return this;
        };


        this.toString  = function(){
            var self = this;
            return ( (_(self.hr).padNumber()) +":"+(_(self.min).padNumber(2))+":"+(_(self.sec).padNumber(2)));
        };

        this.addTo =  function(time){
            if(!time){return this.toString();}

            var self=this,
                split = new window.timeManager();
            split.fromString(time);

            split.sec += self.sec;

            if(split.sec > 60){
                split.min ++;
                split.sec = split.sec%60;
            }
            if(split.min > 60){
                split.hr ++;
                split.min = split.min%60;
            }
            return split;
        };

        this.doContinue =  function(){
            setTimeout(function(){
                self.sec ++;
                if(self.sec > 60){
                    self.min ++;
                    self.sec = self.sec%60;
                }
                if(self.min > 60){
                    self.hr ++;
                    self.min = self.min%60;
                }

                if(!self.running){
                    return false;
                }

                self.doContinue();
            },1000);
        };

        this.start = function(){
            self.running=true;
            self.doContinue();
            return this;
        };

        this.stop = function(){
            self.running = false;
        };

        this.isRunning = function(){
            return self.running;
        };

    };
}
