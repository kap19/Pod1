(function() {
    window.pageIntialized = false;

    $(document).ready(function() {

     // IE9 fix
    /*if(!window.console) {
        var console = {
            log : function(){},
            warn : function(){},
            error : function(){},
            time : function(){},
            timeEnd : function(){}
        }
    }*/

        try {
        //check if ie7 or less
        function get_browser() {
            var ua = navigator.userAgent,
                tem, M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
            if (/trident/i.test(M[1])) {
                tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                return { name: 'IE', version: (tem[1] || '') };
            }
            if (M[1] === 'Chrome') {
                tem = ua.match(/\bOPR\/(\d+)/)
                if (tem != null) {
                    return { name: 'Opera', version: tem[1] };
                }
            }
            M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
            if ((tem = ua.match(/version\/(\d+)/i)) != null) { M.splice(1, 1, tem[1]); }
            return {
                name: M[0],
                version: M[1]
            };
        }

        var browser = get_browser();
        var oldBrowser = false;

            if (browser.name == "MSIE" && Number(browser.version) < 8) {
                oldBrowser = true;

                if (window.console) {
                    console.log("old browser");
                }

                $(".oldBrowser").show();
                $(".newBrowser").hide();
                if ($("#browser").length > 0) {
                    document.getElementById("browser").innerHTML = browser.name + " " + browser.version;
                }
            }

            if (window.console) {
                console.log(browser);
            }

            window.bazingaApp.launcher = new window.bazingaApp.views.launcherView();
            window.bazingaApp.launcher.load();

            if (window.console) {
                console.log("Launcher loadingxxxx");
            }

        } catch (err) {
            document.getElementById("launchErrorContainer").innerHTML = "Error: "+err.message;
        }

    });
}());