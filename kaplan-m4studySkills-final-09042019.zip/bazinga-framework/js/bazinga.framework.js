/*!
 * Copyright 2018 Savv-e Elearning.
 * http://www.savv-e.com.au/
 *
 * A powerful eLearning framework.
 */


if (!window.localStorage) {
    //see https://developer.mozilla.org/en/docs/Web/Guide/API/DOM/Storage
    Object.defineProperty(window, "localStorage", new (function () {
        var aKeys = [], oStorage = {};
        Object.defineProperty(oStorage, "getItem", {
            value: function (sKey) { return sKey ? this[sKey] : null; },
            writable: false,
            configurable: false,
            enumerable: false
        });
        Object.defineProperty(oStorage, "key", {
            value: function (nKeyId) { return aKeys[nKeyId]; },
            writable: false,
            configurable: false,
            enumerable: false
        });
        Object.defineProperty(oStorage, "setItem", {
            value: function (sKey, sValue) {
                if(!sKey) { return; }
                document.cookie = escape(sKey) + "=" + escape(sValue) + "; expires=Tue, 19 Jan 2038 03:14:07 GMT; path=/";
            },
            writable: false,
            configurable: false,
            enumerable: false
        });
        Object.defineProperty(oStorage, "length", {
            get: function () { return aKeys.length; },
            configurable: false,
            enumerable: false
        });
        Object.defineProperty(oStorage, "removeItem", {
            value: function (sKey) {
                if(!sKey) { return; }
                document.cookie = escape(sKey) + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
            },
            writable: false,
            configurable: false,
            enumerable: false
        });
        this.get = function () {
            var iThisIndx;
            for (var sKey in oStorage) {
                iThisIndx = aKeys.indexOf(sKey);
                if (iThisIndx === -1) { oStorage.setItem(sKey, oStorage[sKey]); }
                else { aKeys.splice(iThisIndx, 1); }
                delete oStorage[sKey];
            }
            for (aKeys; aKeys.length > 0; aKeys.splice(0, 1)) { oStorage.removeItem(aKeys[0]); }
            for (var aCouple, iKey, nIdx = 0, aCouples = document.cookie.split(/\s*;\s*/); nIdx < aCouples.length; nIdx++) {
                aCouple = aCouples[nIdx].split(/\s*=\s*/);
                if (aCouple.length > 1) {
                    oStorage[iKey = unescape(aCouple[0])] = unescape(aCouple[1]);
                    aKeys.push(iKey);
                }
            }
            return oStorage;
        };
        this.configurable = false;
        this.enumerable = true;
    })());
}

(function(){

    window.pageLoadSpeed = 10;
    window.debug = false;

    window.bazingaApp = window.bazingaApp || {};
	
	window.bazingaApp.models = window.bazingaApp.models || {};
	window.bazingaApp.collections = window.bazingaApp.collections || {};
	window.bazingaApp.views = window.bazingaApp.views || {};
    window.bazingaApp.views.components = window.bazingaApp.views.components || {};


}());

(function ($) {
    "use strict";


    var     translations= {

            },
            hashed = {
                'id': 'id',
                'preferred': 'pr',
                'data': 'da',
                'suspendData': 'sd',
                'role': 'ro',
                'currentScreen':'cs',
                'previousScreen' : 'ps',
                'score' : 'sc',
                'primaryScore' : 'x',
                'secondaryScore' : 'y',
                'tertiaryScore' : 'z',
                'gotoScreen' : 'gs',
                'count': 'co',
                'views':'vie',
                'completion': 'a',
                'page': 'pa',
                'not attempted': 'n',
                'passed': 'p',
                'failed': 'f',
                'completed': 'c',
                'incomplete': 'i',
                'courseScore' :'zs',
                'courseCompletion' : 'zc',
                'courseStatus' : 'crs',
                'progress' :'pg',
                'dialog-continue':'dcon',
                'dialog-complete':'dcom',
                'dialog-exit' : 'dex',
                'dialog-help' : 'dh',
                'courseData' : 'cd',
                'currentPool' : 'cp',
				'param1' : 'p1',
				'param2' : 'p2',
				'param3' : 'p3',
				'param4' : 'p4',
				'quizAttempts' : 'qa',
				'lang':'la',
				'offlineId':'oi'
				
            },
        sanitizeMap  = {
            '&': '_%',
            '"': '_^',
            "'": '_*'
        },
        deSanitizeMap = _.invert(sanitizeMap),
        createSanitizeEscaper = function(map) {
            var escaper = function(match) {
                return map[match];
            };
            var source = '(?:' + _.keys(map).join('|') + ')';
            var testRegexp = RegExp(source);
            var replaceRegexp = RegExp(source, 'g');
            return function(string) {
                string = string == null ? '' : '' + string;
                return testRegexp.test(string) ? string.replace(replaceRegexp, escaper) : string;
            };
        },
        crunchSuspendData = function(){
            return function(data){
                var crunched = JSON.stringify(data);
                return (crunched.replace(/"/g,'*'));
            };
        },
        uncrunchSuspendData =  function(){
            return function(data){
                if(!_.isString(data)){return data;}
                var uncrunched = (data.replace(/\*/g,'"'));
                if(!uncrunched || uncrunched == ''){return {}}
                return JSON.parse(JSON.stringify(eval("(" + uncrunched + ")")));
            };
        };

    _.mixin({sanitizeScormString : createSanitizeEscaper(sanitizeMap)});
    _.mixin({deSanitizeScormString : createSanitizeEscaper(deSanitizeMap)});
    _.mixin({crunchSuspendData : crunchSuspendData()});
    _.mixin({uncrunchSuspendData : uncrunchSuspendData()});

    _.mixin({
        getKeyHash: function (hash) {
            return _.has(hashed,hash)? hashed[hash] : hash;
        }
    });

    _.mixin({
        translateText: function(text){
            return _.has(translations,text)? translations[text] : text;
        }
    });

    _.mixin({
        padNumber : function(n, width, z) {
            z = z || '0';
            n = n + '';
            width = width || 2;
            return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
        }
    });

    _.mixin({
        capitalize: function(string) {
            return string.charAt(0).toUpperCase() + string.substring(1).toLowerCase();
        }
    });


    // Usage:
    //
    // var obj = {
    //   a: {
    //     b: {
    //       c: {
    //         d: ['e', 'f', 'g']
    //       }
    //     }
    //   }
    // };
    //
    // Get deep value
    // _.deep(obj, 'a.b.c.d[2]'); // 'g'
    //
    // Set deep value
    // _.deep(obj, 'a.b.c.d[2]', 'george');
    //
    // _.deep(obj, 'a.b.c.d[2]'); // 'george'
    _.mixin({

        // Get/set the value of a nested property
        deep: function (obj, key, value) {

            var keys = key.replace(/\[(["']?)([^\1]+?)\1?\]/g, '.$2').replace(/^\./, '').split('.'),
                root,
                i = 0,
                n = keys.length;

            // Set deep value
            if (arguments.length > 2) {

                root = obj;
                n--;

                while (i < n) {
                    key = keys[i++];
                    obj = obj[key] = _.isObject(obj[key]) ? obj[key] : {};
                }

                obj[keys[i]] = value;

                value = root;

                // Get deep value
            } else {
                while ((obj = obj[keys[i++]]) != null && i < n) {};
                value = i < n ? void 0 : obj;
            }

            return value;
        }
    });


    _.mixin({
        pluckDeep: function (obj, key) {
            return _.map(obj, function (value) { return _.deep(value, key); });
        }
    });


    _.mixin({

        // Return a copy of an object containing all but the blacklisted properties.
        unpick: function (obj) {
            obj || (obj = {});
            return _.pick(obj, _.difference(_.keys(obj), _.flatten(Array.prototype.slice.call(arguments, 1))));
        }

    });
})(window.$ || window.JQuery);

if (!window.timeManager) {
    window.timeManager = function(){
        var self = this;
        self.hr = 0;
        self.min = 0;
        self.sec = 0;
        self.running = false;


        this.fromString = function(str){
            var split = (str || "00:00:00").split(":");

            self.hr = (parseInt(split[0]) || 0);
            self.min = (parseInt(split[1]) || 0);
            self.sec = (parseFloat(split[2]) || 0);
            //console.log(self);
            return this;
        };


        this.toString  = function(){
            var self = this;
            return ( (_(self.hr).padNumber()) +":"+(_(self.min).padNumber(2))+":"+(_(self.sec).padNumber(2)));
        };

        this.addTo =  function(time){
            if(!time){return this.toString();}

            var self=this,
                split = new window.timeManager();
            split.fromString(time);

            split.sec += self.sec;

            if(split.sec > 60){
                split.min ++;
                split.sec = split.sec%60;
            }
            if(split.min > 60){
                split.hr ++;
                split.min = split.min%60;
            }
            return split;
        };

        this.doContinue =  function(){
            setTimeout(function(){
                self.sec ++;
                if(self.sec > 60){
                    self.min ++;
                    self.sec = self.sec%60;
                }
                if(self.min > 60){
                    self.hr ++;
                    self.min = self.min%60;
                }

                if(!self.running){
                    return false;
                }

                self.doContinue();
            },1000);
        };

        this.start = function(){
            self.running=true;
            self.doContinue();
            return this;
        };

        this.stop = function(){
            self.running = false;
        };

        this.isRunning = function(){
            return self.running;
        };

    };
}

(function($){
    "use strict";

    window.bazingaApp.models.scormLocalStorage = Backbone.Model.extend({
        'storage' : null,
        initailizeLocalStorageObject : function(){
        },
        reset : function(){
            localStorage.clear();
            return true;
        },
        remove : function(key){
            localStorage.removeItem(key);
            return true;
        },
        LMSInitialize: function(){
            this.initailizeLocalStorageObject();
        },
        LMSGetValue : function(key){
			//console.log("LMSGetValue:"+key);
            return localStorage.getItem(key) || null;
        },
        LMSSetValue : function(key,value){
			//console.log("LMSSetValue:"+key);
            this.set(key,value || null);

            localStorage.setItem(key,value);
        },
        LMSFinish : function(){
            //console.log("LMS finish called(LS) : ");
        },
        LMSCommit : function(){
            //console.log("LMS commit called(LS) : ");
            //this.save({key:value});
        },
        LMSGetLastError : function(){
            //console.log("LMS get error called(LS) : ");
            return '0';
        },
        LMSGetErrorString : function(){
            //console.log("LMS get error string called(LS) : ");
            return 'No Error';
        }
    });

})(window.$||window.JQuery);
(function($){
    "use strict";

    window.bazingaApp.models.timerModel = Backbone.Model.extend({
        defaults:  {
            secs : 0,
            mins : 0,
            hrs  : 0
        }
    });

})(window.$||window.JQuery);
(function($){
    "use strict";

    window.bazingaApp.models.dataModel = Backbone.Model.extend({
        defaults: {
            lesson_location:  '',
            student_name: '',
            lesson_status: 'not attempted',
            score_raw: null,
            score_min: 0,
            score_max: 100,
            suspend_data: '',
            comments: 'comments',
            student_preference_audio: '0',
            student_preference_language: 'en_En',
            student_preference_speed: '0',
            student_preference_text: '0',
            mastery_score : null,
            'exit':'',
            'role':'learner',
            'courseVisits':0
        },
        changedSinceSync : [],
        dirty  : false,


        initialize : function(){
            var self=this;
			
			/*if(self.navModel){
				console.log("found navmodel in self");
			console.log(self.navModel);
		}*/
			var suspendString = 'cmi.suspend_data';
			
			//if offline
			var isOffline = window.localStorage.getItem("isOffline");
			var offlineId = window.localStorage.getItem("offlineId");
			
			//var offlineId = window.bazingaApp.models.api.getOfflineId();
			
			
			if(isOffline == "true" && offlineId != null){
				//console.log("is offline. add: "+offlineId);
				suspendString += ".";
				suspendString +=offlineId;
			}
			
			//console.log("offline id: "+suspendString);
			
            this.hash = _.extend({},{
                'lesson_location':'cmi.core.lesson_location',
                'student_name' :  'cmi.core.student_name',
                'credit':'cmi.core.credit',
                'lesson_status':'cmi.core.lesson_status',
                'entry':'cmi.core.entry',
                'score_raw':'cmi.core.score.raw',
                'score_min':'cmi.core.score.min',
                'score_max':'cmi.core.score.max',
                'suspend_data':suspendString,
                'launch_data':'cmi.core.launch_data',
                'mastery_score':'cmi.student_data.mastery_score',
                'comments':'cmi.comments',
                'comments_from_lms':'cmi.core.comments_from_lms',
                'student_preference_audio':'cmi.student_preference.audio',
                'student_preference_language':'cmi.student_preference.language',
                'student_preference_speed':'cmi.student_preference.speed',
                'student_preference_text':'cmi.student_preference.text'
            });

            _.bindAll(this,'upload','commit');
            this.on("change",this.upload ,self);
        },

        autoSave : function(){
            var self = this;
            var check = function(){
                setTimeout(function(){
                    self.upload(true).always(check);
					if (window.console) {
                    console.log("Data autosaved");
					}
                },10000);
            };
            check();
        },

        fetch : function(options){
            var self=this,
                API= self.API,
                keys,
                deferred= $.Deferred(),
                val;

            if(!API){return false;}

            setTimeout(function(){
                //Start loading all the values
                _.each(self.hash,function(keyhash,key){
                    val = API.LMSGetValue(keyhash);
                    self.set(key,val,{silent: true});
                });
                deferred.resolve(self);
            },500);
            return deferred.promise();
        },
        isDirty : function(){return this.dirty;},
        getChangedSinceSync : function(){return this.changedSinceSync;},
        commit : function(){
            var self=this,
                API= self.API;

            if(!API) return false;
            console.log("Changed called -> committing");
            API.LMSCommit("");
            return true;
        },
        upload : function (commit) {
            //options.data = _.pick(this.attributes, 'foo', 'bar', 'baz');
            var self=this,
                API= self.API,
                deferred= $.Deferred(),
                val,
                changed,
                hashedKey;

            commit = commit || false;
			
			//don't commit if loading
			function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
			
			if(getCookie("finishLoad") == "no"){
				commit = false;
			}
			
			//console.log("API?");
			//console.log(API);
			
            if(!API){
                setTimeout(function(){deferred.fail();},10);
            }
            else{
                setTimeout(function(){
                    changed = self.changed;
                    if(self.dirty){

                        console.log("---uploading value . . .");
                        _.each(self.changedSinceSync, function(key){
                             val = self.get(key);
                             if(_.has(self.hash,key)){
                                 hashedKey  = self.hash[key];
                                 API.LMSSetValue(hashedKey,val);
                                 console.log("new val: "+hashedKey +" = "+val);
                             }
                        });
						
						//save offline id to localstorage
						/*if(window.localStorage.getItem("isOffline")){
						var offlineId = window.bazingaApp.models.api.getOfflineId();
						window.localStorage.setItem("offlineId",offlineId);
						}*/
							
                        console.log("---upload complete.");

                        self.changedSinceSync = [];
                        self.dirty = false;
						if(getCookie("finishSaving") != "yes"){
						document.cookie = "finishSaving=yes"; 
						}
                    }
                    if(commit){
                        API.LMSCommit("");
                    }

                    deferred.resolve();
                },500);
            }
            return deferred.promise();
        },

        setData : function(){
			//console.log("data model setData");
            var self=this,
                argumentsArray = [].slice.apply(arguments),
                attr = argumentsArray[0],
                value = argumentsArray[1],
                change = function(attr,value){
                    self.set((""+attr+""),value);
                    if(_.indexOf(self.changedSinceSync,(""+attr+"")) == -1){
                        //if($.inArray(self.changedSinceSync,(""+attr+"")) == -1, _)){
                        self.changedSinceSync.push((""+attr+""));
                        self.dirty = true;
                    }
                };



            if(!attr){return false;}

            if(typeof attr == 'object'){
                return _.each(attr,this.setData);
            }
            else{
				
				//console.log("set data. attr: "+attr);
				
                switch(attr){
                    case "suspend_data":
                    case "lesson_location":
                    case "comments":
                        //allow write freely
                        break;
                    case "score_min":
                        var max=self.getData('score_max');
                        if( (_.isNumber(value) && value)  && value >= 0 && value <=100 && (!_.isNumber(max) || (value < max))) {
                            change(attr,value);

                            return true;
                        }

                        change(attr,0);
                        break;

                    case "score_max":
                        var min=self.getData('score_min');

                        if( (_.isNumber(value) && value)  && value > 0 && value <=100 && (!_.isNumber(min) || (value > min))) {
                            change(attr,value);
                            return true;
                        }
                        change(attr,100);
                        return false;
                        break;

                    case 'score_raw':
                        if(_.isNumber(value)) {
                            var currentStatus=self.getData('lesson_status');


//                            if(['passed','completed'].indexOf(currentStatus) > -1){
//                                //Do not update score after the course is completed
//                                return false;
//                            }


                            value =(function(){
                                var min=self.getData('score_min'),
                                    max=self.getData('score_max');

                                if(value === null || value === ''){return null;}

                                if(!_.isNumber(min)||!_.isNumber(max)){
                                    //ceil off the value
                                    return (value <= 0) ? 0 : ((value >= 100) ? 100 : value);
                                }

                                if(min >= max ){return value;}
                                value = (value <= min) ? min : ((value >= max) ? max : value);

                                //convert to percentage
                                return ((value-min)/(max-min))*100;
                            })();
                        }

                        var currentScore = self.getData('score_raw');
                        if(_.isNumber(currentScore) && (!_.isNumber(value) || currentScore > value)){
                            //If the current score is greater than the attempted set then dont update
                            return false;
                        }


                        var masteryScore = self.getData('mastery_score');

                        if(!_.isNumber(value)){
                            //Bad hack . have to return false but then have ot set values as well
                            if(!this.get(attr)){
                                this.set((""+attr+""),null);
                            }
                            return false;
                        }


                        if(masteryScore){
                            if(value < masteryScore){
                                this.setData('lesson_status','failed');
                            }
                            else if(value >= masteryScore){
                                this.setData('lesson_status','passed');
                            }
                        }

                        break
                    case 'lesson_status':
                        if( $.inArray(value, ['not attempted','incomplete','completed','passed','failed']) == -1){
                            return false;
                        }
                        var currentStatus=self.getData('lesson_status');

                        if(currentStatus == 'passed'){return false;}
                        else if(currentStatus=='completed' && value !='passed'){return false;}
                        else if(currentStatus=='failed' && ['passed','completed'].indexOf(value) == -1){return false;}
                        else if(currentStatus=='incomplete' && (value=='not attempted' || value=='incomplete')){return false;}
                        else if(currentStatus == value){return false;}
                        break;

                    case 'total_time':
                    case 'session_time':
                        //do some testing around total time
                        break;

                    case 'entry':
                        if( $.inArray(value, ['ab-initio','resume']) == -1){
                            return false;
                        }
                        break;

                    case 'exit':
                        if(['time-out','suspend','logout',''].indexOf(value) == -1){
                            return false;
                        }
                        break;

                    case 'launch_data':
                    case 'lesson_mode':
                    case 'student_name':
                    case 'comments_from_lms':
                    case 'name':
                    case 'credit':
                    case 'mastery_score':
                        //read only values
						//console.log("read only value");
                        return false;

                    case 'student_preference_audio':
                        if(value !== '' && (!_.isNumber(value) || -1 > value || 100 < value)){
                            return false;
                        }
                        break;
                    case 'student_preference_speed':
                        if(value !== '' && (!_.isNumber(value) || -100 > value || 100 < value)){
                            return false;
                        }
                        break;
                    case 'student_preference_text':
                        if(value !== '' && (!_.isNumber(value) || -1 > value || 1 < value)){
                            return false;
                        }
                        break;
                    default:
                        break;
                }

                change(attr,value);
            }

            return true;
        },
        getData : function(){
            var self=this,
                argumentsArray = [].slice.apply(arguments),
                attr = argumentsArray[0]; //eg. comments
				/*console.log("dataModel-getData");
				console.log(argumentsArray);
				console.log(attr);*/
			
			//console.log("getData. attr: "+attr);

            /*todo  : handle interactions*/
            return this.get(attr);
        },

        setAPI : function(API){
            this.API = API;
            return this;
        },
        getAPI : function(){
            return this.API;
        },
        setNavModel : function(navModel){
            this.navModel = navModel;
            return this;
        },
        getNavModel : function(){
            return this.navModel || null;
        },
        //Utility methods
        setLessonLocation: function(lesson_location){
			
			console.log("data mod setLessonLocation");
			
            return this.setData('lesson_location',lesson_location);
        },

        getLessonLocation : function(){
			//console.log("--------------------data mod getLessonLocation--------------");
            return this.getData('lesson_location');
        },

        setLessonStatus: function(lesson_status){
            return this.setData('lesson_status',lesson_status);
        },

        getLessonStatus : function(){
            return this.getData('lesson_status');
        },
		setLessonComments : function(comment){ 
			//console.log("data model set comments: "+comment);
			var self=this,
                API= self.API;

            //this.setData('comments',comment);
            API.LMSSetValue('cmi.comments',comment);
			
            return this;
        },
		
		getLessonComments: function(){
			//console.log("datamodel-get comments");
            return this.getData('comments');
        },
		
		setLessonStudentResponse : function(num,data){ 
			//console.log("data model set StudentResponse: "+data);
			var self=this,
                API= self.API;

            //this.setData('comments',comment);
			API.LMSSetValue('cmi.interactions.'+num+'.type','performance');
            API.LMSSetValue('cmi.interactions.'+num+'.student_response',data);
			
			//API.LMSSetValue('cmi.interactions_'+num+'.type','performance');
            API.LMSSetValue('cmi.interactions_'+num+'.student_response',data);
			
            return this;
        },
		
		setLessonInteractionId : function(num,id){ 
			//console.log("data model set interaction id: "+id);
			var self=this,
                API= self.API;

            //this.setData('comments',comment);
			API.LMSSetValue('cmi.interactions.'+num+'.type','performance');
            API.LMSSetValue('cmi.interactions.'+num+'.id',id);
			
			//API.LMSSetValue('cmi.interactions_'+num+'.type','performance');
            //API.LMSSetValue('cmi.interactions_'+num+'.id',id);
			
			//API.LMSSetValue('cmi.interactions.'+num+'objectives.0.id',id);
			
            return this;
        },
		
		/*write only
		
		getLessonStudentResponse: function(id){
			console.log("datamodel-get StudentResponse");
            return this.getData('studentResponse',id);
        },*/
		
		setLessonSpeed : function(speed){
			//console.log("data model set speed: "+speed);
			var self=this,
                API= self.API;

            //this.setData('comments',comment);
            API.LMSSetValue('cmi.student_preference.speed',speed);
            return this;
        },
        setScore : function(score){
            return this.setData('score_raw',score);
        },
        getScore : function(){
            return this.getData('score_raw');
        },
        getSuspendData : function(){
			
			var suspendString = 'suspend_data';
			
			//if offline
			var isOffline = window.localStorage.getItem("isOffline");
			var offlineId = window.bazingaApp.models.api.getOfflineId();
			
			if(offlineId == null){
				offlineId = window.localStorage.getItem("offlineId");
				window.bazingaApp.models.api.setOfflineId(offlineId);
			}
			
			//window.localStorage.setItem("offlineId",offlineId); 
			//console.log("is offline? "+isOffline+" . Id is "+offlineId);
			
			if(isOffline == "true" && offlineId != null){
				//console.log("is offline. add: "+offlineId);
				suspendString = 'cmi.suspend_data.';
				suspendString +=offlineId;
				
				//console.log("datamodel getsuspenddata offline. "+suspendString+ " : " + window.localStorage.getItem(suspendString));
				
				return window.localStorage.getItem(suspendString);
			}
			
            var d =  this.getData(suspendString);
			
			console.log(d);
			
            if(d==undefined || d == 'undefined' || d == null || !d){
                d = '';
            }
            return d;
        },
		
		//used for below
		getCookie: function(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
},
		
        forceSetSuspendData : function(suspend_data){
			
			//console.log("forceSetSuspendData");
            var self=this,
                API= self.API;
			
			/*if(this.getCookie("finishLoad") == "no"){
				return false;
			}*/
			
			//save to local storage?
			this.setData('suspend_data',suspend_data);
			
			
			var isOffline = window.localStorage.getItem("isOffline");
			var offlineId = window.bazingaApp.models.api.getOfflineId();
			
			//console.log("1) isOffline? "+isOffline + ". 2) offlineId? "+ offlineId);
			
			if(isOffline == "true" && offlineId != null){
				//console.log("is offline");
				API.LMSSetValue('cmi.suspend_data.'+offlineId,this.get('suspend_data'));
			}
            else{
				//console.log("not offline. set to: "+this.get('suspend_data'));
				API.LMSSetValue('cmi.suspend_data',this.get('suspend_data'));
				//console.log("suspend data force changed to: "+API.LMSGetValue('cmi.suspend_data') +" . ");
			}
			
            return this;
        },
        setSuspendData: function(suspend_data,force){
			//console.log("not force");
			
			//save to local storage?
            this.setData('suspend_data',suspend_data);
            return this;
        },
        getMasteryScore : function(){
            return this.getData('mastery_score');
        },
        setAudioPreference : function(audioPreference){
            this.set('student_preference_audio',audioPreference);
            return this;
        }, 
        getAudioPreference : function(){
            return this.get('student_preference_audio');
        },
        getSpeedPreference : function(){
            return this.get('student_preference_speed');
        },
        setSpeedPreference : function(speedPreference){
            this.set('student_preference_speed',speedPreference);
            return this;
        },
        getLanguagePreference : function(){
            return this.get('student_preference_language');
        },
        setLanguagePreference : function(languagePreference){
            this.set('student_preference_language',languagePreference);
            return this;
        },
        getTextPreference : function(){
            return this.get('student_preference_text');
        },
        setTextPreference : function(textPreference){
            this.set('student_preference_text',textPreference);
            return this;
        },
        incrementScore : function(increment){
            var raw = this.getScore();
            this.setScore(raw+increment);
        }
    });

})(window.$||window.JQuery);
(function($) {
    "use strict";

    window.bazingaApp.models.scormDataModel = Backbone.Model.extend({
        defaults: {
            "initialized": false,
            "API": null,
            "status": "new",
            "lastError": "0",
            "lastErrorDescription": "No Error",
            "autoCommit": false
        },

        sessionTime: new window.timeManager(),

        initialize: function() {
            var API,
                self = this;
            if (!this.get('API') /*|| API == undefined*/) { //on for moodle. off for kaplan t2
                this.findAPI();
            }

            this.initializeSCO();
            API = this.get('API');

            self.sessionTime
                .fromString("00:00:00.00")
                .start();


            self.totalTime = API.LMSGetValue("cmi.core.total_time");
            self.totalTime = self.totalTime || "0000:00:00.00";
            return this;
        },

        commit: function() {
            var self = context || this,
                API = self.get('API');

            API.LMSCommit("");
            return this;
        },

        setData: function(data) {
            this.data = data;
            return this;
        },

        findAPI: function() {
            var lwindow = window,
                loops = 10,
                API = null,
                self = this,
                locateAPI = function(win) {
                    while ((win.API == null) &&
                        (win.parent != null) &&
                        (win.parent != win)) {
                        // increment the number of findAPITries
                        loops++;
                        // Note: 20 is an arbitrary number, but should be more than sufficient
                        if (loops > 50) {
                            alert("Error finding API -- too deeply nested.");
                            return null;
                        }

                        // set the variable that represents the window being
                        // being searched to be the parent of the current window
                        // then search for the API again
                        win = win.parent;
                    }
                    return win.API;
                };

            API = locateAPI(lwindow);

            if (!API) {

                if (lwindow.dialogArguments) { //ie8 version
                    API = locateAPI(lwindow.dialogArguments);
                    if (window.console) {
                        console.log("look for api in lwindow.dialogArguments");
                    }
                }else if (lwindow.opener) {
                    API = locateAPI(lwindow.opener);
                    if (window.console) {
                        console.log("look for api in lwindow.opener");
                    }
                }


            }

            if (!API) {
                if (window.console) {
                    console.log("1. API NOT found. (Using local storage system)");
                }
                API = new window.bazingaApp.models.scormLocalStorage();
				window.localStorage.setItem("isOffline", true );
				
            } else {
                if (window.console) {
                    console.log("1. API found.");
                }
				window.localStorage.setItem("isOffline", false );
            }

            this.set('API', API);
        },


        setValue: function(key, value, forceCommit, context) {
            var self = context || this,
                API = self.get('API'),
                returnValue = null;

            forceCommit = forceCommit || false;

            if (!API || !key) {
                console.error("Unable to get Data . API Not initialized or the key is undefined");
                return null;
            }

            API.LMSSetValue(key, value);
			console.log("setvalue");
            self.scormError();

            if (self.get('autoCommit') || forceCommit) {
                API.LMSCommit("");
            }

            return self;
        },

        getValue: function(key, context) {
            var self = context || this,
                API = self.get('API'),
                returnValue = null;
            if (!API || !key) {
                console.error("Unable to get Data . API Not initialized or the key is undefined");
                return null;
            }
			//console.log("getvalue "+key);
            returnValue = API.LMSGetValue(key);
			//console.log("getvalue");
            self.scormError();

            return returnValue;
        },
        initializeSCO: function(context) {
			//console.log("initializeSCO");
            var self = context || this,
                API = self.get('API');

            if (self.get('initialized')) {
                //pre-initialized . then ignore.
                //console.log("API was previously initialized");
                return false
            };
			
			//console.log(API);
			//console.log(API.LMSInitialize(""));
			//console.log(API.LMSInitialize);
			
			var lms = window.bazingaCourseConfig.lms;
			
			//need the typeof 'API.LMSInitialize' === "function" below for moodle otherwise error, but having it on saves nothing in moodle and reload so changed to try
			
			if (lms == "moodle"){
				//console.log("moodle");
				try {
				self.set('initialized', (API && jQuery.isFunction(API.LMSInitialize) && API.LMSInitialize(""))); 
				}
				catch(err) {
					if (window.console) {
					console.log("ERROR: "+err.message);
					}
				}				
			}else{
				//console.log("not moodle");
				self.set('initialized', (API /*&& typeof 'API.LMSInitialize' === "function"*/ && API.LMSInitialize(""))); //for kaplan t2 and all other modules		
			}											
			
			//console.log("test2");
			
            /*console.log("test 1. api:");
            console.log(Object.getOwnPropertyNames(API));

            console.log("test 2. API.LMSInitialize is function? ");
            console.log(typeof API.LMSInitialize);

            console.log('test 3. API.LMSInitialize("")');
            console.log(API.LMSInitialize(""));*/

            //console.log("2. API initialized?: " + self.get('initialized'));

            var status = self.getValue('cmi.core.lesson_status');
            if (status == 'not attempted') { self.setValue('cmi.core.lesson_status', 'incomplete'); }

            //reset the error codes
			//console.log("initializeSCO");
            self.scormError();
            self.set('status', 'active');
        },

        switchTimers: function(context) {
            var self = context || this,
                API = self.get('API');
            API.LMSSetValue("cmi.core.session_time", self.sessionTime.toString());

            //console.log("Seting session time " + self.sessionTime.toString());
            self.sessionTime.stop();
            API.LMSCommit("");
        },
        finishSCO: function(context) {
            var self = context || this,
                API = self.get('API'),
                deferred = $.Deferred();

            if (window.bazingaApp.preloader) { window.bazingaApp.preloader.setPercentage(0).enable(); }



            //console.log("TOTAL TIME " + self.totalTime.toString() + ' ---> ' + API.LMSGetValue("cmi.core.total_time"));

            if (!self.get('initialized')) {
                //console.log("Finish sco called before initialization");
            } else {
                if (API && typeof API.LMSFinish == 'function' && API.LMSFinish("")) {
                    API.LMSFinish("");
                }
            }




            if (self.data) {
                self.data
                    .upload()
                    .always(function() {
                        API.LMSCommit("");
                        self.set('initialized', false);
                        self.set('status', 'inactive');
                        //console.log("All data synced. LMS commit called. shutting down");
                    });
            } else {
                API.LMSCommit("");
                self.set('initialized', false);
                self.set('status', 'inactive');
                //console.log("All data synced. LMS commit called. shutting down");
            }

            if (window.bazingaApp.preloader) { window.bazingaApp.preloader.incrementTo(75); }
            setTimeout(function() {
                deferred.resolve();
            }, 2000);
            return deferred.promise();
        },

        scormError: function(context) {
            var self = (context || this),
                API, lastErrorNumber;

            API = self.get('API');
            if (!API) {
                if (window.console) {
                    console.log("er: LMS API not located");
                }
                return false;
            }

            if (!self.get('initialized')) {
                if (window.console) {
                    console.log("er: LMS API NOT initialized");
                }
                return false;
            }

            lastErrorNumber = API.LMSGetLastError();

            self.set('lastError', lastErrorNumber);
            self.set('lastErrorDescription', API.LMSGetErrorString(lastErrorNumber));
			
			/*if (window.console) {
				console.log(lastErrorNumber + " : " +API.LMSGetErrorString(lastErrorNumber));
			}*/
			
            return self;
        }
    });

})(window.$ || window.JQuery);

(function($) {
    "use strict";
    window.quedSuspendDataUpdate = false;

    /**
     * Get the query parameters from the url
     * @param qs
     * @returns {{}}
     */
    window.getQueryParams = function(qs) {
        qs = qs.split('+').join(' ');

        var params = {},
            tokens,
            re = /[?&]?([^=]+)=([^&]*)/g;

        while (tokens = re.exec(qs)) {
            params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
        }

        return params;
    }


    /**
     * Model for the current page data.
     * Every page can have 4 parameters : count / status / data / score
     * @type {*}
     */
    window.bazingaApp.models.pageData = Backbone.Model.extend({
        initialize: function() {
            _.bindAll(this, 'incrementCount', 'setStatus', 'setData', 'setScore', 'setCount');
        },
        incrementCount: function(options) {
            options = options || {};
            this.set(_('count').getKeyHash(), ((this.get(_('count').getKeyHash())) || 0) + 1);
            return this;
        },
        setStatus: function(status, options) {
            options = options || {};
            this.set(_('completion').getKeyHash(), _(status).getKeyHash(), options);
            if (_.has(this.changed, _('completion').getKeyHash())) {
                window.was_page_completed_on_load = true;
            } else {
                window.was_page_completed_on_load = false;
            }
            return this;
        },
        setData: function(data, options) {
            options = options || {};
            this.set(_('data').getKeyHash(), data, options);
            return this;
        },
        setCount: function(count, options) {
            options = options || {};
            this.set(_('count').getKeyHash(), count, options);
            return this;
        },
        setScore: function(score, options) {
            options = options || {};
            score = score || null;
            this.set(_('score').getKeyHash(), score, options);
            return this;
        },
        getScore: function() {
            return this.get(_('score').getKeyHash()) || null;
        },
        getCompletion: function() {
            return _(this.get(_('completion').getKeyHash())).getKeyHash();
        },
        setCompletion: function(status) {
            return this.setStatus(status);
        },
        getData: function() {
            return this.get(_('data').getKeyHash()) || null;
        },
        getCount: function() {
            return this.get(_('count').getKeyHash()) || 0;
        }
    });

    /**
     * Page navigation
     * @type {*}
     */
    window.bazingaApp.models.pageNav = Backbone.Model.extend({});

    /**
     * Core navigation model that controls all functionalities of the course.
     *
     * @type {*}
     */
    window.bazingaApp.models.navigationModel = Backbone.Model.extend({
        dataModel: null,

        /**
         * List of all parameters that can be set using the navigation model.
         * These parameters are hashed using the getKeyHash() mixin
         */
        defaults: {
            preferred: null,
            role: "default",
            count: 0,
            data: null,
            suspendData: null,
            currentScreen: null,
            previousScreen: null,
            currentPool: 0, //set to 0 so can randomise
            courseStatus: 'na',
            primaryScore: null,
            secondaryScore: null,
            tertiaryScore: null,
            courseData: '',
            nav: null,
            lu: null,
            param1: null,
            param2: null,
            param3: null,
            param4: null,
            quizAttempts: 0,
            progress: 0,
			lang:"null",
			offlineId:null
        },

        conditional: {
            "lockables": [],
            "locked": [],
            "unlocked": []
        },
        /**
         * These parameters are not saved into the suspend Data but used extensively inside the current model
         * Setting these never fires a 'set' or 'get' call
         */
        values: {
            allPages: [],
            allTrackablePages: [],
            suspendDataIdx: null,
            allDialogs: [],
            isDialogScreen: false
        },
        models: {
            currentSuspendData: null
        },


        initialize: function() {
            var self = this;
            _.bindAll(this, 'loadFrom', 'crunchForRole', 'retrieveSuspendData',
                'handshake', 'setUpCurrentScreen', 'suspendDataChanged', 'updateSuspendData',
                'pageInitializers', 'setSuspendDataIndices', 'getNavForScreenByRole',
                'setPageCompletion', 'setPageData', 'setInfo', 'setPageScore', 'setCourseScoreFrom',
                'setCourseScore', 'setCourseStatus', 'reattemptScreen', 'setCurrentPool', 'getCurrentPool', 'getCourseCompletion',
                'getParam', 'setParam', 'getParam1', 'setParam1', 'getParam2', 'setParam2', 'getParam3', 'setParam3', 'getParam4', 'setParam4', 'getLang', 'setLang', 'getQuizAttempts', 'setQuizAttempts', 'getQuizAttempts', 'setQuizAttempts', 'setComments', 'getComments', 'setInteractionStudentResponse','setInteractionId' ,'setSpeed', 'getProgress','setOfflineId','getOfflineId');

            this.on("change:role", this.retrieveSuspendData, self);
            this.on("change", this.suspendDataChanged, self);
        },

        /**
         * The event handler everytime data changes within the page.
         * The suspendDataChanged function will create a new suspendDataString and commit it to the LMS
         * @param __force
         * @returns {*}
         */
        suspendDataChanged: function(__force) {
            var self = this,
                suspendData = self.retrieveSuspendData(),
                dataModel = self.dataModel,
                deferred = $.Deferred();

            __force = __force || false;

			console.log("suspend chanaged");
			
			function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

            setTimeout(function() {
                if (__force) {
                    dataModel.forceSetSuspendData(suspendData);
                } else {
                    dataModel.setSuspendData(suspendData);
				}
				
				if(getCookie("finishLoad") == "yes"){
                dataModel.commit();
				}

                window.updateOtherData = false;
                deferred.resolve();
                self.trigger("initialized:suspendData", self);
            }, window.pageLoadSpeed);


            return deferred.promise();
        },

        /**
         * STEP 1
         * Load the josn file and set up the preferred data
         * @param jsonFile
         * @returns {*}
         */
        load: function(jsonFile) {
			//console.log("navModel: load(jsonFile)");
			//console.log(jsonFile);
			
            var deferred = $.Deferred(),
                self = this,
                hashed = {
                    'completion': _('completion').getKeyHash(),
                    'completed': _('completed').getKeyHash(),
                    'passed': _('passed').getKeyHash(),
                    'incomplete': _('incomplete').getKeyHash(),
                    'failed': _('failed').getKeyHash(),
                    'not_attempted': _('not attempted').getKeyHash()
                };
			
			/*if(offlineConfig != undefined){
				console.log("offline config exists, use it");
				self.courseConfig = offlineConfig;
				//console.log(self.courseConfig);
			}*/
			
			try{ 
				self.courseConfig = offlineConfig;
				//console.log("offline config is: "+offlineConfig+", use it");
			}
				catch(err) {
					//console.log("nav model. no offlineConfig");
				}
			
			var offlineId = window.bazingaCourseConfig.title.replace(/[^\w\s]|_/g, "");
						offlineId = offlineId.split(' ').join('');
						window.localStorage.setItem("offlineId", offlineId );
						//console.log("navigation module. set offlineId: "+offlineId);
				
            $.getJSON(jsonFile, function(data) {
				
				
			/*console.log("data - array of pages in nav");
				console.log(data);
				console.log("$.getJSON(jsonFile)");*/
				
                self.set('preferred', data, { silent: true });
                
            }).error(function(data){
				console.log(jsonFile);
				console.log("navigation model - failed to load json ");
				
				if((typeof offlineNav === 'undefined') ){
					console.log("no offline nav");
				}else{
					self.set('preferred', offlineNav, { silent: true });
				}
				
			}).complete(function(data){
					
				self.handshake()
                    .always(function() {
                        self.recalculateCompletion()
                            .always(function() {
					
								var i = self.get('courseStatus');
							console.log("self.get('courseStatus') = "+self.get('courseStatus'));
 
								//console.log("online - get suspenddataaa");	
							
                                var suspendData = self.get('suspendData');
								
								//console.log("m lock test");
							
								//console.log(suspendData);
								
								//console.log(self);
							
								//console.log(self.conditional);
							
							//console.log(self.conditional.lockables);
							
                                _.each(self.conditional.lockables, function(lockables, tgtId) {
                                    var locked = true,
                                        suspend,
                                        status = hashed.not_attempted,
                                        lockedStatus = [];

                                    _.map(lockables.lockedIf, function(lockable) {
										
										//only shows lockables on groups not pages
										//console.log(lockables);
										//console.log(lockables.lockedIf);
										//console.log(lockable);
										//console.log(lockable.id);
										
                                        if (!lockable.id) {
                                            return true;
                                        }

                                        //console.log("Lockable identified " + lockable.id + " .tgt = " + tgtId);
                                        var inverse = false;
                                        suspend = _.first((_.where(suspendData, { id: lockable.id })));
                                        status = hashed.not_attempted;

                                        if (suspend && !_.isEmpty(suspend) && _.has(suspend, hashed.completion)) {
                                            status = suspend[hashed.completion];
                                        }

                                        if (_.has(lockable, 'condition') && lockable.condition == "!") {
                                            inverse = true;
                                        }

                                        if ($.inArray(status, [hashed.not_attempted, hashed.incomplete, hashed.failed]) > -1) {

                                            //not completed the page
                                            lockedStatus.push(inverse);
                                        } else {
                                            //Page is complete 
                                            lockedStatus.push(!inverse);
                                        }

                                    });

                                    //console.log(lockedStatus);
                                    locked = (-1 != $.inArray(true, lockedStatus));

                                    lockables.locked = locked;
                                    self.conditional.lockables[tgtId] = lockables;
                                });

                                //resolve and start application
                                deferred.resolve(self);
                            });
                    });
				
			});
			//console.log("navmodel load end");
            return deferred.promise();
        },

        /**
         * STEP 2
         * Set up handshake between the data models
         * This will link the data model to the navigation model and initialize the navigation
         * @returns {*}
         */
        handshake: function() {
			//console.log("Hand shake1");
            var deferred = $.Deferred(),
                self = this,
                dataModel = self.dataModel,
                hashed = {
                    'completion': _('completion').getKeyHash(),
                    'completed': _('completed').getKeyHash(),
                    'passed': _('passed').getKeyHash(),
                    'incomplete': _('incomplete').getKeyHash(),
                    'failed': _('failed').getKeyHash(),
                    'not_attempted': _('not attempted').getKeyHash()
                };

            //console.log("Hand shake2");
            self.trigger("initialize:handshake", self);
            setTimeout(function() {
                self.trigger("initialize:suspendData", self);
                if (!dataModel) {
                    deferred.fail();
                    return false;
                }

                var suspendData = dataModel.getSuspendData(),
                    preferredForRole;

                /**
                 * Step 1 : Load from suspend data :
                 *          Retrieve the suspend data string and parse it .
                 *
                 * Step 2 : crunchForRole
                 *          Depending on the role and existing data a navigation structure will be populated
                 *          If suspenddata preexists then the navigation will be retrieved from the preexisting data
                 *
                 * Step 3 : setUpCurrentScreen
                 *          Reinitialize the page values to reflect changes on the current screen .
                 *
                 * Step 4 : pageInitializers
                 *          Initialize page avalues within this page
                 *
                 * Step 5 : If the page is the first page launched then either navigate to the dialog continue / home or the current page
                 *
                 *
                 * Step 6 : resolve  the promise object
                 */
                self.loadFrom((suspendData || ''), self)
                    .crunchForRole(self.get('preferred'))
                    .always(function(data) {
                        //Set up the preferred navigation
                        self.set('preferred', data, { silent: true });

                        if (!self.get('suspendData')) {
                            console.log("Error initializing suspend data: "+self.get('suspendData'));
                        }

                        self.setUpCurrentScreen();
                        self.pageInitializers()
                            .always(function() {
                                console.log("[DBG:] Page is now initialized, course status=" + self.get('courseStatus'));

                                var currentScreen,
                                    previousScreen,
                                    role,
                                    nav,
                                    pageNav,
                                    goto,
                                    nextNav,
                                    resolve = false,

                                    //Check if the course is complete
                                    isCourseComplete = (function() {
                                        if (window.was_page_completed_on_load) {
                                            console.log("Page was only just completed, course status= " + self.get('courseStatus'));
                                            return false;
                                        }

                                        return ($.inArray(self.get('courseStatus'), [hashed.completed, hashed.passed]) > -1);

                                    })(),
                                    isCurrentComplete;

                                console.log("M: START TEST "+self.get('courseStatus'));
							console.log("isCourseComplete: "+isCourseComplete);
							console.log("firstLaunch local storage: "+window.localStorage.getItem('firstLaunch'));

                                if (isCourseComplete || window.localStorage.getItem('firstLaunch')) {  

                                    console.log("Course is complete or first launch");
                                    window.localStorage.removeItem('firstLaunch');

                                    //check to see if a dialog needs to be shown.
                                    currentScreen = self.get('currentScreen');
                                    previousScreen = self.get('previousScreen');
                                    role = self.get('role') || 'default';

                                    if (!isCourseComplete && !previousScreen) {
                                        //Launch for the first time .  The course is incomplete
                                        //console.log("M: start");
                                        console.log("first time load and course incomplete");
                                        $(".moduleLoaded").show();
                                        resolve = true;
                                    } else {
                                        currentScreen = currentScreen || 'home';
                                        nav = self.getNavForScreenByRole(role, previousScreen); //this line is required for reenter

                                        //console.log("M test");
										console.log(nav);

                                        if (isCourseComplete) {
                                            console.log("M: Course Config ");
											
											console.log(self.courseConfig);
											console.log(self.courseConfig.allow_continue_after_complete);
											
                                            if (self.courseConfig.allow_continue_after_complete || self.courseConfig.responseJSON.allow_continue_after_complete /*seems to have changed with offline*/) {

                                                //Do not lock the course on complete. Continue
                                                $(".moduleLoaded").show();

                                                resolve = true;
                                                //debugger;
                                            } else {
                                                //force the course to go to the dcom
                                                goto = self.courseConfig.default_complete || 'dcom';

                                                //console.log("Mmmmmmmmm");

                                                isCurrentComplete = (function() {

                                                    var location = window.location.pathname,
                                                        locationHref = (location.split("/")).pop(),
                                                        dialogNav;

                                                    if (["dcom"].indexOf(goto) > -1) {
                                                        //send the course score on dialog complete
                                                        self.setCourseScoreFrom('primary');
                                                        dialogNav = self.getDialog(goto);
                                                    } else {
                                                        dialogNav = self.getNavForScreen(goto);
                                                    }


                                                    return (locationHref === dialogNav.resource)
                                                })();

                                                if (isCurrentComplete) { resolve = true; }

                                                //console.log("MM");
                                            }

                                        } else {
											console.log("course not complete, go to renter page or resume");
                                            goto = nav.reenter || self.courseConfig.default_continue || 'dcon';
											console.log(goto);
                                        }

                                        if (window.debug || resolve) {
                                            resolve = true;
                                        } else {
												
                                            if ((goto && goto != 'prevent')) {
                                                //go to a particular screen or dialog
                                                if (["dcom", "dcon", "dex", "dh", "dr"].indexOf(goto) > -1) {
                                                    nextNav = self.getDialog(goto);
                                                } else {
                                                    nextNav = self.getNavForScreen(goto);
                                                }

                                                if (nextNav && nextNav.resource) {
                                                    window.location.replace(nextNav.resource);
                                                } else {
                                                    //do nothing skip
                                                    resolve = true;
                                                }
                                            } else if (currentScreen !== previousScreen) {

                                                pageNav = self.getNavForScreen(previousScreen);

                                                if (pageNav && pageNav.resource) {
                                                    window.location.replace(pageNav.resource);
                                                } else {
                                                    //do nothing skip
                                                    //console.log("M: do nothing");
                                                    resolve = true;
                                                }
                                            } else {
                                                resolve = true;
                                            }
                                        }

                                    }
                                } else {
									
									//console.log("module loaded show");
                                    $(".moduleLoaded").show();

                                    resolve = true;
                                }

                                if (resolve) { deferred.resolve(); }

                            });

                    });
            }, window.pageLoadSpeed);

            return deferred.promise();
        },


        /**
         * Load the current data model from the suspend data string
         * @param suspendData
         * @param context
         * @returns {*}
         */
        loadFrom: function(suspendData, context) {
            var self = context || this,
                suspendDataJson = _(suspendData).uncrunchSuspendData(),
                attributes = context.attributes,
                attributeKeys = _.keys(attributes);


            _.each(attributeKeys, function(key) {

                var keyHash = _(key).getKeyHash();
                switch (key) {
                    case 'preferred':
                        break;
                    case 'suspendData':
                        var dataJson = {},
                            pageHash = _('page').getKeyHash(),
                            preventTracking = false;

                        if (_.has(self.courseConfig, 'prevent_tracking') && self.courseConfig.prevent_tracking == true) { preventTracking = true; }

                        if (!_.isEmpty(suspendDataJson) && !preventTracking) {
                            //reset the key from the suspend data
                            if (_.has(suspendDataJson, pageHash)) {
                                dataJson = suspendDataJson[pageHash];
                            }

                            self.set('suspendData', dataJson, { silent: true });
                        }
                        break;
                    case 'nav':
                        //reset the key from the suspend data
                        if (_.has(suspendDataJson, keyHash)) {
                            context.set(key, suspendDataJson[keyHash], { silent: true });
                        };
                        break;

                    default:
                        //reset the key from the suspend data
                        if (_.has(suspendDataJson, keyHash)) {
                            context.set(key, suspendDataJson[keyHash], { silent: true });
                        };
                        break
                }
            });
            return self;
        },

        /**
         * Set up the navigation for the role
         * @param data
         * @returns {*}
         */
        crunchForRole: function(data) {

            var role = this.get('role') || 'default',
                currentNav = this.get('nav') || null,
                deferred = $.Deferred(),
                self = this,
                cp = self.get('currentPool'),

                /**
                 * When the config timestame is greater than the timestamp on file
                 * Reload the config / navigation
                 * This allows us to make sure the suspendData string is in sync with the navigation
                 *
                 * @Note : changin the timestamp will reset the suspendData string
                 */
                isConfigUpdated = (function() {

                    //Compare date time with existing date tiem
                    var d = new Date(),
                        d2,
                        t = d.getTime(),
                        t2,
                        lu = self.get('lu'),
                        clu;

                    if (!self.get('suspendData') || !self.courseConfig || !lu) {
                        //time was never recorded . record it now
                        self.set('lu', t, { silent: true });
                        return false;
                    }

                    clu = self.courseConfig.last_updated;

                    if (!clu) {
                        self.set('lu', t, { silent: true });
                        return false;
                    }

                    d2 = new Date(clu);
                    t2 = d2.getTime();
                    self.set('lu', t2);



                    if (t2 > lu) {
                        return true;
                    }
                    return false;
                }()),

                /**
                 * This  is the access control within the nav controller.
                 * The page filter loops through each page and make sure the page values are parsed
                 * Also it creates easy access variables within the application
                 */
                pageFilter = function(pages, cNav, parent) {
                    //map all sub pages
                    _.map(pages, function(page) {
                        //set up the page bread crumbs
                        page.crumbs = page.crumbs || [];
                        if (parent) {
                            page.crumbs.push(parent);
                        }

                        //if the page has no items then initialize hte page
                        if (!_.has(page, 'items')) {
                            if (page.structure == 'group') {
                                return page;
                            }
                            page.structure = page.id;
                            page.parent = parent || null;
                            return page;
                        }

                        /**
                         * Step 1 : recursively filter the page items to make sure only  items with proper access levels can be accessed by the role
                         * Step 2 : randomize
                         *          randomize is dependent on the group level randomize options . Each nav key can be set to 3 different options
                         *                ">>" : Will randomize then reset the nav key with the id of the next page in the randomized list.
                         *                "<<" : Will randomize then reset the nav key with the id of the previous page in the randomized list.
                         *                "<id>" : This will set the nav key of the page to the id mentioned
                         *                "*" : this will inherit the defined nav properties for the page
                         *
                         * @type {*}
                         */
                        var items = pageFilter(page.items, (cNav ? (_.has(cNav, page.id) ? cNav[page.id] : null) : null), page.id),
                            randomize = (page.type == 'group' && _.has(page, 'randomize')) ? page.randomize : false,
                            __allIds = _.pluck(items, 'id'),
                            __static, __dynamic, itemList = [],
                            __after = {
                                "first": {
                                    "back": "*",
                                    "next": "*",
                                    "complete": "home",
                                    "passed": "home",
                                    "failed": "home"
                                },
                                "last": {
                                    "back": "*",
                                    "next": "*",
                                    "complete": "home",
                                    "passed": "home",
                                    "failed": "home"
                                },
                                "others": {
                                    "back": "*",
                                    "next": "*",
                                    "complete": "*",
                                    "passed": "*",
                                    "failed": "*"
                                }
                            };

                        //get a list of all pages (if previously set then get the right list.
                        if (_.has(cNav, page.id) && typeof cNav[page.id] === 'object') {
                            //todo clean up the code
                            //since it is an object it automatically reorders numbers. so we switch the ordering to keys and let it sort then pick the values :D
                            //hack hack hack .SCREAMS HACK!! @sundar
                            __allIds = _.values(_.object(_.values(cNav[page.id]), _.keys(cNav[page.id])));
                        } else if (randomize) {

                            //randomize the items
                            __static = page.randomize.__static || [];
                            __dynamic = _.shuffle(_.difference(__allIds, __static));

                            __allIds = _.map(_.clone(__allIds), function(id) {
                                if (_.indexOf(__static, id) > -1) {
                                    return id;
                                }
                                var dyn_id = __dynamic.pop();
                                return dyn_id;
                            });
                        }


                        if (_.has(page.randomize, '__after')) {
                            __after = _.extend(__after, ((randomize && _.has(page.randomize, '__after')) ? page.randomize.__after : {}));
                        }

                        _.each(__allIds, function(value, key) {
                            var itemForId = _.find(items, function(it) {
                                    return it.id == value;
                                }),
                                nav,
                                currentIdx = itemForId ? (_.indexOf(__allIds, itemForId.id)) : -1,
                                nextOrBack,
                                navByRoleForItem;
							
							var isOffline = window.localStorage.getItem("isOffline");
							
							if(itemForId == undefined){
								if(isOffline == "true"){
								console.log("refresh page - using nav from another module");
								
								localStorage.clear();
									
								document.cookie = "finishLoad=no";
								location.reload();
								return false;
								}
							}else{
								navByRoleForItem = itemForId.role[role].nav;
								/*console.log("itemForId:");
								console.log(itemForId);
								console.log("role " + role);
								console.log("navByRoleForItem:");
								console.log(navByRoleForItem);
								console.log("---");*/
							}

                            //This was a corrupted navigation file. Previous suspend data has since been changed
                            if (!itemForId) {
                                return true;
                            }

                            //previously the first screen always has a back to home. last screen always have next to home. now fixed
                            if (key == 0) {
                                nav = __after.first;
                            } else if (key == (__allIds.length - 1)) {
                                nav = __after.last;
                            } else {
                                nav = __after.others;
                            }

                            _.each(nav, function(v, k) { //v: *,>>,home,home,home............... k: next,complete, passed, failed
								
								//ignore subgroups
								if(itemForId.type =="group"){
									return false;
								}
								
                                //console.log("k "+k);
                                //console.log(nav);

                                //console.log("k "+k);
                                /*if (v == '?') {
                                    //Do nothing and take the defaults
                                    return true;
                                } else*/
                                if (k == 'back') {
                                    //Auto calculate back or next
                                    /*if (currentIdx == 0 || currentIdx == -1) {
                                        nextOrBack = 'home';
                                    }
                                    else {*/
                                    nextOrBack = (function() {
                                        /*if(currentIdx == 0){
                                            return 'home';
                                        }*/

                                        /**
                                         * This has been improved to add in the pool
                                         * When a back or next value is returned, the returned value is checked to verify
                                         * if the pools of the returned value matches with the currently selected pool
                                         * Or the loop continues till the match occurs
                                         *
                                         * @type {boolean}
                                         */
                                        //console.log("->BACK");

                                        var stop = false,
                                            cIdx = currentIdx - 1,
                                            idx,
                                            itForBack,
                                            retValue = 'home'; //defaults

                                        //console.log("index " + currentIdx);
											
                                        //console.log("back for " + value + " is " + itemForId.role[role].nav[k]);

                                        //check page exists

                                        if (itemForId.role[role].nav[k]) {
                                            //Do nothing and take the defaults
                                            //console.log("value is set");
                                            return itemForId.role[role].nav[k];

                                        } else {
                                            //console.log("does not exist");
                                            //auto calculate
                                            while (stop === false) {
                                                idx = __allIds[cIdx];
                                                //console.log("idx " + idx);
                                                itForBack = _.find(items, function(it) {
                                                    return it.id == idx;
                                                });

                                                if (!itForBack || !itForBack.id || !cp || !page.track || !page.track.pool) {
                                                    if (itForBack && itForBack.id) {
                                                        retValue = itForBack.id;
                                                    }
                                                    stop = true;
                                                } else {
                                                    if ((page.track.pool + "") !== (cp + "")) {
                                                        cIdx -= 1;
                                                        if (cIdx < 0) { stop = true; }
                                                    } else {
                                                        stop = true;
                                                        retValue = itForBack.id;
                                                    }
                                                }
                                            }
                                            //console.log("Back for " + value + " auto calculated as " + retValue);
                                            return retValue;
                                        }


                                    })();
                                    //}


                                    itemForId.role[role].nav[k] = (nextOrBack);
                                    return true;
                                } else if (k == 'next') {
                                    //Auto calculate back or next
                                    /*if (currentIdx == __allIds.length - 1) {
                                        nextOrBack = 'home';
                                    }
                                    else {*/
                                    nextOrBack = (function() {
                                        /*if(currentIdx >=  __allIds.length - 1){
                                            return 'home';
                                        }*/

                                        /**
                                         * This has been improved to add in the pool
                                         * When a back or next value is returned, the returned value is checked to verify
                                         * if the pools of the returned value matches with the currently selected pool
                                         * Or the loop continues till the match occurs
                                         *
                                         * @type {boolean}
                                         */

                                        //console.log("->NEXT");

                                        var stop = false,
                                            cIdx = currentIdx + 1,
                                            idx,
                                            itForNext,
                                            retValue = 'home';

                                        //console.log("currentIdx " + currentIdx);

                                        //console.log("next for " + value + " is " + itemForId.role[role].nav[k]);

                                        if (itemForId.role[role].nav[k]) {
                                            //Do nothing and take the defaults
                                            //console.log("value is set");
                                            return itemForId.role[role].nav[k];
                                        } else {
                                            //console.log("does not exist");
                                            //auto calculate
                                            while (stop === false) {
                                                idx = __allIds[cIdx];
                                                //console.log("idx " + idx);
                                                itForNext = _.find(items, function(it) {
                                                    return it.id == idx;
                                                });

                                                if (!itForNext || !itForNext.id || !cp || !page.track || !page.track.pool) {
                                                    if (itForNext && itForNext.id) {
                                                        retValue = itForNext.id;
                                                    }

                                                    stop = true;
                                                } else {
                                                    if ((page.track.pool + "") !== (cp + "")) {
                                                        cIdx += 1;
                                                        if (cIdx >= (__allIds.length - 1)) { stop = true; }
                                                    } else {
                                                        stop = true;
                                                        retValue = itForNext.id;
                                                    }
                                                }
                                            }
                                            //console.log("Next for " + value + " auto calculated as " + retValue);
                                            return retValue;
                                        }


                                    })();
                                    //}

                                    itemForId.role[role].nav[k] = (nextOrBack);
                                    return true;
                                }

                                //Set the constant page as the key
                                navByRoleForItem[k] = v;
                                //console.log("navByRoleForItem[k]" +v);
                                return true;
                            });

                            itemForId.role[role].nav = navByRoleForItem;
                            itemList.push(itemForId);
                        });
                        page.items = itemList;

                        //console.log("itemList 111111");
                        //console.log(page.items);

                        var i = 0;

                        _.map(itemList, function(it) {
							//console.log(it);
							//console.log(it.subgroup);
                            if (typeof it.structure !== 'object') {
                                it.structure = i++;
								//console.log("set structure: "+it.structure);
                            }else{
								//console.log("is object?");
							}
                            return it;
                        });

                        page.structure = _.object(_.pluck(itemList, 'id'), _.pluck(itemList, 'structure'));
						
						//console.log("struck");
						//console.log(page.structure);

                        //part 1. adds items in groups to all pages. 
                        self.values.allPages = ([].concat(self.values.allPages, itemList));
						//console.log("HERE");
						//console.log(self.values.allPages);
						
						//console.log(page);
						
                        return page;
                    });


                    return _.filter(pages, function(page) {

                        if (page.type == 'dialog') {
                            return false;
                        }

                        if (cNav && !isConfigUpdated) {
                            //if it exists in the nav use it :)
                            return _.has(cNav, page.id);
                        } else {
                            return _.has(page, 'role') && _.has(page.role, role);
                        }
                    }, this);
                };

            if (isConfigUpdated) {
                currentNav = null;
            }


            /**
             * Set up all dialogs that can be accessed from the course
             * This allows us to access the dialog help and such using hte same navigation calls as a page removing need for unwanted calls
             * @type {Array}
             */
            self.values.allDialogs = _.filter(data.pages, function(page) {
                if (page.type == 'dialog') {
                    return true;
                }
                return false;
            });

            //filter all pages within the data
            data.pages = pageFilter(data.pages, currentNav);

			//console.log("data.pages");
			//console.log(data.pages);
			
            self.conditional.lockables = (_.object(_.pluck(data.pages, 'id'), _.pluck(data.pages, 'conditions')));
			
			var pageLockables = [];
			
			_.each(data.pages,function(aGroup){
				//console.log("aGroup's items");
				//console.log(aGroup.items);
				if(aGroup.items){
					
					var somePageLockables = [];
					
					_.each(aGroup.items, function(aPage){
						
						if(aPage.conditions){
							//console.log("aPage "+aPage.id);
							//console.log(aPage.conditions);  
						 
							//mw error only gets the last group of unlockables. change pageLockables to somePageLockables 
							//pageLockables = (_.object(_.pluck(aGroup.items, 'id'), _.pluck(aGroup.items, 'conditions')));
							
							//somePageLockables = (_.object(_.pluck(aGroup.items, 'id'), _.pluck(aGroup.items, 'conditions')));
							
							//console.log(pageLockables);
							
							var thisPage = new Object();
							thisPage.id = aPage.id;
							thisPage.conditions = aPage.conditions;
							
							pageLockables[aPage.id] = aPage.conditions;
							
							//console.log(_.object(aPage.id, aPage.conditions ));
							
							//pageLockables.push(_.object(aPage.id, aPage.conditions ));
							
							
						}
					});
					
					/*_.each(somePageLockables, function(aPage){
						pageLockables[aPage.id] = aPage;
					});*/
					
					/*console.log("CMON");
					console.log(somePageLockables);
					console.log(_.size(somePageLockables));
					_.each(somePageLockables, function(item){
							//console.log(i);
							console.log(item);
					});
					
					console.log("mid pageLockables");
					console.log(pageLockables);
					*/
				}
			});
			
			//console.log("end pageLockables");
			//console.log(pageLockables);
			
			//remove undefined pagelockables
			
			pageLockables = _.omit(pageLockables, function(value, key, object) {
                return value === undefined;
            });
			
			//pageLockables = (_.object(_.pluck(data.pages.items, 'id'), _.pluck(data.pages.items, 'conditions')));
			
			//console.log("pageLockables");
			//console.log(pageLockables);
			
			//self.conditional.lockables = pageLockables.concat(self.conditional.lockables);
			
			//remove any undefined
			
            self.conditional.lockables = _.omit(self.conditional.lockables, function(value, key, object) {
                return value === undefined;
            });
			
			//self.conditional.lockables = _.union(self.conditional.lockables,pageLockables);
			
			//add pageLockable objects to self.conditional.lockables object as properties
			
						for (var property in pageLockables) {
				if (pageLockables.hasOwnProperty(property)) {
					
					self.conditional.lockables[property] = pageLockables[property];
				}
			}
			
			//console.log("end self.conditional.lockables");
			//console.log(self.conditional.lockables);

            /**
             * When the navigation is initialized the suspend data will be generated and submitted.
             * The first initialize call on the suspenddata will mean the data is saved and we can progres to the next step
             */
            self.once("initialized:suspendData", function() {
				//console.log("initialized:suspendData");
                if (!self.get('suspendData')) {
                    self.loadFrom(self.dataModel.getSuspendData(), self);
                    self.setSuspendDataIndices();
                    
					var isOffline = window.localStorage.getItem("isOffline");
			
					
					if(isOffline == "true"){
						
						//console.log("refresh - SUSPENDDATA INIT. did not exist - was successfully initialized for the first time");
						
						document.cookie = "finishLoad=no";
						location.reload();
						return false;
					}
                }
                deferred.resolve(data);
            });



            self.set('nav', _.object(_.pluck(data.pages, 'id'), _.pluck(data.pages, 'structure')), { silent: true });

            //handles cases when the suspend data string doesnt update and the execuction fails
            self.trigger("change", self);

            //part 2 adds, individual items to all pages
            self.values.allPages = ([].concat(self.values.allPages, data.pages));

            //self.values.allTrackablePages = self.values.allPages;

            return deferred.promise();
        },

        /**
         * Update the suspend data
         *
         * The suspend data will be reloaded everytime there is an update to the values within the model
         *
         * @param updateType
         * @returns {*}
         */
        updateSuspendData: function(updateType) {
            var self = this,
                currentSuspendData = (self.get('suspendData')),
				//currentSuspendData = window.bazingaApp.models.navigation.getSuspendData(), //this caused module to crash
                updatedModel = self.models.currentSuspendData.attributes,
                qued = function() {
                    var deferred = $.Deferred();

                    if (!window.quedSuspendDataUpdate) {
                        window.quedSuspendDataUpdate = true;
                        window.suspendDataReload = false;
                        self.suspendDataChanged()
                            .always(function() {
                                window.quedSuspendDataUpdate = false;
                                if (window.suspendDataReload) {
                                    window.suspendDataReload = false;
                                    qued();
                                }
                                deferred.resolve();
                                self.trigger("updated:suspendData", self, { updateType: updateType });
                            });
                    } else {
                        window.suspendDataReload = true;
                    }

                    return deferred.promise();
                };

			/*console.log("-- update suspend data. self.models.currentSuspendData");
			console.log(self.models.currentSuspendData);
			
			console.log("nav model self.models.currentSuspendData.attributes");
			console.log(self.models.currentSuspendData.attributes);*/

            /**
             * IF there is no suspend data then reload the suspend data from the LMS
             */
            if (currentSuspendData === null) {
				console.log("currenSuspendaData is null. self.dataModel.getSuspendData():");
				
                self.loadFrom(self.dataModel.getSuspendData(), self);
                currentSuspendData = (self.get('suspendData'));
				
				console.log(currentSuspendData);
				
                self.setSuspendDataIndices();
            }


            if (self.values.pageSuspendIdx == -1 || !_.has(currentSuspendData, self.values.pageSuspendIdx)) {
                console.log("INDEX NOT FOUND / NOT UPDATED "+self.values.pageSuspendIdx);
				console.log(currentSuspendData);
            } else {
                currentSuspendData[self.values.pageSuspendIdx] = updatedModel;
                self.set('suspendData', currentSuspendData);



                if (updateType == 'completion') {
                    /**
                     * IF completion of the page has changed then we need to recalcualte completion of the course
                     */
                    self.recalculateCompletion()
                        .always(qued);
                } else if (updateType == 'scoring') {
                    /**
                     * IF score of the page has changed then we need to recalcualte score of the course
                     */
                    self.recalculateScoring()
                        .always(qued);
                } else if (updateType == 'scoringAndCompletion') {
                    self.recalculateScoring()
                        .always(function() {
                            console.log("Recalculating completion");
                            self.recalculateCompletion().always(qued);
                        });

                } else {

                    window.updateOtherData = true;
                    if (!window.quedSuspendDataUpdate) {
                        qued();
                    }
                }
            }
            return self;
        },

        /**
         * Re calculate completion of the course and the topics
         * @returns {*}
         */
        recalculateCompletion: function() {
			
			console.log("recalculateCompletion");
			
            var
                self = this,
                deferred = $.Deferred(),
                nav = this.get('nav'),
                currentSuspendData = this.get('suspendData'),
                preferred = this.get('preferred'),
                allPages = this.values.allPages,
                completion = [],
                allTrackable = [],
                dataModel = self.dataModel,
                hashMap = {
                    'completion': _('completion').getKeyHash(),
                    'not_attempted': _('not attempted').getKeyHash(),
                    'incomplete': _('incomplete').getKeyHash(),
                    'completed': _('completed').getKeyHash(),
                    'passed': _('passed').getKeyHash(),
                    'failed': _('failed').getKeyHash()
                },

                /**
                 * The main recalculate function.
                 * STEP 1 : Find all trackable pages (page.track.completion == true )
                 * STEP 2 : For each of the above pages get the suspend data and the completion
                 * STEP 3 : If this page has sub items them recursively calculate the completion of this page
                 * STEP 4 : Based on the total number of not-attempted pages / incomplete / completed pages calcualte group / coruse completion
                 *          If there are incomplete pages + not attempted pages then the course / group status is incomplete
                 *          If all sub pages are completed / passed then the even bubbles up
                 */
                recalculate = function(pages, trackable, preventCommit) {
                    preventCommit = preventCommit || false;

                    //loops through all the items and groups
                    var trackablePages = _.filter(pages, function(page) {
                        var trackable = true,
                            cp = self.get('currentPool');

                        trackable = trackable && (page.track && page.track.completion);

                        if (cp && page.track && page.track.pool) {
                            trackable = trackable && ((page.track.pool + "") === (cp + ""));
                        }

                        //console.log(page.id +" ==> trackable ?? " + trackable);
                        return trackable;
                    }, this);

                    trackable = trackable || [];

                    var numPagesComplete = 0;

                    _.map(trackablePages, function(page) {
                        var suspendKey = _.findKey(currentSuspendData, { id: page.id }),
                            it,
                            subTrackables,
                            pageCompletion,
                            counter;


                        if (!suspendKey) {
                            currentSuspendData = currentSuspendData || {};
                            currentSuspendData[page.id] = { id: page.id };
                            currentSuspendData[page.id][hashMap.completion] = hashMap.not_attempted;
                            suspendKey = _.findKey(currentSuspendData, { id: page.id });
                        }

                        it = currentSuspendData[suspendKey];
                        it.type = page.type;


                        if (!_.has(page, 'items') || page.items.length == 0) {
                            trackable.push(it);
                            return page;
                        }


                        subTrackables = (recalculate(page.items, []));
                        pageCompletion = _.pluck(subTrackables, hashMap.completion);

                        //console.log("subTrackables");
                        //console.log(subTrackables);
                        //console.log("pageCompletion");
                        //console.log(pageCompletion);

                        counter = _.countBy(pageCompletion, function(completion) {
							
							//id is group instead
							//console.log(page.id);
							//console.log(completion);
							
                            if (!completion || completion == _('not attempted').getKeyHash() || completion == "i") {
                                return _('not attempted').getKeyHash();
                            }
                            //add to progress
							
							//console.log("ADD PROGRESS");
							
                            numPagesComplete = numPagesComplete + 1;
                            return completion;
                        });

                        if (counter[hashMap.not_attempted] == trackablePages.length) {
                            it[hashMap.completion] = hashMap.not_attempted;
                        } else if (counter[hashMap.not_attempted] > 0 || counter[hashMap.incomplete] > 0 || counter[hashMap.failed] > 0) {
                            it[hashMap.completion] = hashMap.incomplete;
                        } else {
                            var sendCompletedStatus = true;
                            if (self.courseConfig && self.courseConfig.completion && (self.courseConfig.completion.status == 'passed-failed-completed' || self.courseConfig.completion.status == 'passed-completed')) {
                                if (counter[hashMap.passed] > 0) {
                                    it[hashMap.completion] = hashMap.passed;
                                    sendCompletedStatus = false;
                                } else {
                                    it[hashMap.completion] = hashMap.completed;
                                    sendCompletedStatus = false;
                                }
                            }
                            if (sendCompletedStatus) {
                                it[hashMap.completion] = hashMap.completed;
                            }
                        }

                        trackable.push(it);
                        currentSuspendData[suspendKey][hashMap.completion] = it[hashMap.completion];

                        self.set('suspendData', currentSuspendData, { silent: true });
                        return page;
                    });

                    //save number of completed pages to progress
                    //console.log(numPagesComplete);
                    //window.bazingaApp.models.api.setProgress(numPagesComplete);
                    self.set('progress', numPagesComplete, { silent: true });

                    return trackable;
                };


            setTimeout(function() {
                allTrackable = recalculate(preferred.pages, allTrackable);

                /**
                 * Get completion of all topics
                 * @type {Array}
                 */
                var allCompletion = _.pluck(allTrackable, hashMap.completion),
                    allCounter = _.countBy(allCompletion, function(completion) {
                        if (!completion || completion == hashMap.not_attempted) {
                            return hashMap.not_attempted;
                        }
                        return completion;
                    });

                /*console.log("allTrackable");
                    console.log(allTrackable);
                console.log("allCompletion");
                    console.log(allCompletion);
                    console.log("allcounter");
                    console.log(allCounter);*/

                /**
                 * Set course status based on topic completion
                 */
                if (allCounter[hashMap.not_attempted] > 0 || allCounter[hashMap.incomplete] > 0 || allCounter[hashMap.failed] > 0) {
                    self.set('courseStatus', hashMap.incomplete, { silent: true });
                    console.log("Lesson status :incomplete");
                    dataModel.setLessonStatus('incomplete');
                    dataModel.commit();
                } else {

                    var sendCompletedStatus = true;

                    if (self.courseConfig && self.courseConfig.completion) {
                        if (self.courseConfig.completion.status == 'passed-failed-completed' || self.courseConfig.completion.status == 'passed-completed' || (self.courseConfig.completion.status == 'completed-with-score')) {
                            if (allCounter[hashMap.passed] > 0) {
                                console.log("Lesson status :passed");
                                self.set('courseStatus', hashMap.passed, { silent: true });
                                dataModel.setLessonStatus('passed');
                                dataModel.commit();
                                sendCompletedStatus = false;
                            } else if (allCounter[hashMap.failed] > 0) {
                                console.log("Lesson status :failed");
                                self.set('courseStatus', hashMap.failed, { silent: true });
                                dataModel.setLessonStatus('failed');
                                dataModel.commit();
                                sendCompletedStatus = false;
                            }
                        }
                    }

                    if (sendCompletedStatus) {
                        console.log("Lesson status :completed");
                        self.set('courseStatus', hashMap.completed, { silent: true });
                        dataModel.setLessonStatus('completed');
                        dataModel.commit();
                    }
                }




                self.suspendDataChanged(true)
                    .always(function() {
                        deferred.resolve();
                    })
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        /**
         * @tpdp // complete ths
         * @returns {*}
         */
        recalculateScoring: function() {
            var
                self = this,
                deferred = $.Deferred(),
                nav = this.get('nav'),
                currentSuspendData = this.get('suspendData'),
                preferred = this.get('preferred'),
                allPages = this.values.allPages,
                scores = [],
                allScorable = [],
                dataModel = self.dataModel,
                hashMap = {
                    'score': _('score').getKeyHash()
                },

                /**
                 * Recalculate course scoring based on page scores
                 */
                recalculate = function(pages, trackable) {
                    var trackablePages = _.filter(pages, function(page) {
                            var trackable = true,
                                cp = self.get('currentPool');

                            trackable = trackable && (page.track && page.track.score && page.track.score === true);

                            if (cp && page.track && page.track.pool) {
                                trackable = trackable && ((page.track.pool + "") === (cp + ""));
                            }

                            return trackable;

                        }, this),
                        trackable = trackable || [],
                        score = 0,
                        allScores = [];

                    _.map(trackablePages, function(page) {
                        var suspendKey = _.findKey(currentSuspendData, { id: page.id }),
                            it,
                            subTrackables,
                            completion,
                            pageCompletion,
                            counter,
                            total = 0;

                        if (!suspendKey) {
                            currentSuspendData = currentSuspendData || {};
                            currentSuspendData[page.id] = { id: page.id };
                            currentSuspendData[page.id][hashMap.completion] = hashMap.not_attempted;
                            suspendKey = _.findKey(currentSuspendData, { id: page.id });
                        }

                        it = currentSuspendData[suspendKey];
                        it.type = page.type;

                        if (!_.has(page, 'items') || page.items.length == 0) {
                            trackable.push(it);
                            return page;
                        }

                        subTrackables = (recalculate(page.items, []));

                        allScores = _.pluck(subTrackables, hashMap.score);


                        total = _.reduce(allScores, function(memo, score) {
                            if (!score) { score = 0; } else {
                                score = parseInt(score);
                                if (_.isNaN(score)) { score = 0; } else if (score > 100) { score = 100; } else if (score < 0) { score = 0; }
                            }

                            return memo + (score || 0);
                        }, 0);


                        it[hashMap.score] = total;
                        trackable.push(it);



                        currentSuspendData[suspendKey][hashMap.score] = (it[hashMap.score] / allScores.length);
                        self.set('suspendData', currentSuspendData, { silent: true });
                        return page;
                    });

                    return trackable;
                };



            setTimeout(function() {
                allScorable = recalculate(preferred.pages, allScorable);
                scores = _.pluck(allScorable, hashMap.score);

                if (!scores || scores.length == 0) {
                    //no update
                    deferred.resolve();
                }


                var total = _.reduce(scores, function(memo, score) {
                    if (!score) { score = 0; } else {
                        score = parseInt(score);
                        if (_.isNaN(score)) { score = 0; } else if (score > 100) { score = 100; } else if (score < 0) { score = 0; }
                    }
                    return memo + (score || 0);
                }, 0);

                self.set('primaryScore', (total / scores.length), { silent: true });

                self.suspendDataChanged(true)
                    .always(function() { deferred.resolve(); })


                console.log("Save complete ");
            }, window.pageLoadSpeed);

            return deferred.promise();
        },


        /**
         * Set up the suspend data indices
         * @returns {boolean}
         */
        setSuspendDataIndices: function() {
            var self = this,
                currentSuspendData = self.get('suspendData') || {},
                suspend;
			
			

            if (!currentSuspendData || !self.values.pageNav || !self.values.pageConfig) {
                return false;
            }

            //find the suspend data
            self.values.pageSuspendIdx = _.findKey(currentSuspendData, function(x) {
                return x.id == self.values.pageConfig.id;
            });
			
			/*console.log("currentSuspendData:");
			console.log(currentSuspendData);

			console.log("self.values.pageSuspendIdx "+self.values.pageSuspendIdx);*/
			
            //get the previous suspend data
            self.values.previousSuspendData = suspend = (!self.values.pageSuspendIdx || self.values.pageSuspendIdx == -1) ? {} : currentSuspendData[self.values.pageSuspendIdx];
            //get the suspend default suspend value
            suspend = self.suspendDataDefaults(suspend, self.values.pageNav, self.values.pageConfig)
            self.models.currentSuspendData = new window.bazingaApp.models.pageData(suspend);

            self.models.currentSuspendData.on("change", function() {
                var changed = self.models.currentSuspendData.changed;

                if (_.has(changed, (_('completion').getKeyHash()))) {

                    self.updateSuspendData('completion');
                } else if (_.has(changed, (_('score').getKeyHash()))) {
                    self.updateSuspendData('scoring');
                } else {
                    self.updateSuspendData();
                }

            });

        },
        /**
         * Initialize the current screen
         * @returns {*}
         */
        setUpCurrentScreen: function() {
            var location = window.location.pathname,
                locationHref = (location.split("/")).pop(),
                self = this,
                allPages,
                config,
                role = self.get('role') || 'default',
                page,
                filteredByPool,
                currentScreen = self.get('currentScreen'),
                previousScreen = self.get('previousScreen'),
                currentPool = window.bazingaApp.models.api.getCurrentPool();
			
			
			//console.log("setUpCurrentScreen "+currentScreen);

            if (self.values.allPages.length == 0) {
                return false;
            }

            allPages = _.clone(self.values.allPages);


            filteredByPool = _.filter(allPages, function(page) {
                var trackable = true,
                    parent = page.parent,
                    parentConfig;

                if (parent) {
                    //check the parent to see if they have a pool to track to
                    //parentConfig = (_.where(allPages,{id:parent}));
                    parentConfig = _.find(allPages, function(page) {
                        return page.id == parent
                    });

                    //get the parent pool
                    parentConfig = parentConfig && parentConfig.track && parentConfig.track.pool;
                }

                if (currentPool) {
                    if (page.track && page.track.pool) {
                        trackable = trackable && ((page.track.pool + "") === (currentPool + ""));
                    } else if (parentConfig) {
                        trackable = trackable && ((parentConfig + "") === (currentPool + ""));
                    }
                }


                return trackable;
            }, this);

            if (filteredByPool.length > 0) {
                self.values.pageNav = page = _.first(_.where(filteredByPool, { resource: locationHref }));
            } else {
                self.values.pageNav = page = _.first(_.where(self.values.allPages, { resource: locationHref }));
            }



            if (self.values.pageNav) {


                //set up the navigation model.
                self.models.currentPageNav = new window.bazingaApp.models.pageNav(page);


                //get the config
                self.values.pageConfig = config = _.extend({ "count": true, "data": true, "completion": true, "score": false, "id": page.id }, page.track),

                    //find the index of the page navigation
                    self.values.pageNavIdx = _.findIndex(self.values.allPages, function(x) {
                        return x.id == page.id;
                    });

                self.setSuspendDataIndices();

                self.dataModel.setLessonLocation(self.values.pageNav.id);

                if ($.inArray(self.get('currentScreen'), ["dcom", "dcon", "dex", "dh", "dr"]) == -1) {

                    //reset the data
                    self.set('previousScreen', self.get('currentScreen'), { silent: true }); //currentScreen:null,
                    self.set('currentScreen', self.values.pageNav.id, { silent: true });
                }

                self.values.isDialogScreen = false;
                return self.values.pageNav.resource;
            } else {
                self.values.dialogNav = _.first(_.where(self.values.allDialogs, { resource: locationHref }));
                self.values.isDialogScreen = true;

                _.map(self.values.allDialogs, function(dialog) {
                    if (!dialog.role || !dialog.role[role] || !dialog.role[role].nav) {
                        return dialog;
                    }

                    var nav = dialog.role[role].nav;
                    if (_.isEmpty(nav)) {
                        return dialog;
                    }

                    _.each(nav, function(v, k) {
                        if (v === 'currentScreen' || v === "<<<") {
							
							if(self.values.dialogNav){
								//console.log("has id");
							}else{
								//console.log("ERROR: no id");
								alert("Please clear your cache and then refresh the page");
							}
							
                            nav[k] = self.values.dialogNav.id == 'dcon' ? previousScreen : currentScreen;
                        }
                    });

                    dialog.role[role].nav = nav;
                    return dialog;
                });
            }


        },

        /**
         * Initialize the page variables
         * If mark_course_complete_on_enter is true then the course will be automatically be marked as complete when this page is visited.
         * @returns {*}
         */
        pageInitializers: function() {
			//console.log("pageInitializers");
            var self = this,
                deferred = $.Deferred(),

                commitCourseStatus = function() {
					//console.log("self.values.pageConfig.mark_course_complete_on_enter");
					
                    var deferred = $.Deferred();
                    setTimeout(function() {
						
						//console.log(self.values);
						//console.log(self.values.pageConfig);
						//console.log(self.values.pageConfig.mark_course_complete_on_enter);
						
                        if (self.values && self.values.pageConfig && (self.values.pageConfig.mark_course_complete_on_enter)) {
							//console.log("commitCourseStatus");
                            self.dataModel.setLessonStatus('completed');
                            self.dataModel.commit("");
                        }
                        deferred.resolve();
                    }, window.pageLoadSpeed);
                    return deferred.promise();
                },
                commitPageStatus = function() {
                    var deferred = $.Deferred();

                    if (self.values && self.values.pageConfig && (self.values.pageConfig.completion && self.values.pageConfig.force_complete_on_enter)) {
                        self.models.currentSuspendData.setStatus('completed');
                    }
                    setTimeout(function() { deferred.resolve(); }, window.pageLoadSpeed);
                    return deferred.promise();
                },
                commitCount = function() {
                    var deferred = $.Deferred();
                    if (self.values && self.values.pageConfig && self.values.pageConfig.count) {
                        self.models.currentSuspendData.incrementCount();
                    }
                    setTimeout(function() { deferred.resolve(); }, window.pageLoadSpeed);
                    return deferred.promise();
                },
                initializePage = function() {
					
					//console.log("initializePage function");
					//console.log(self.values);
					//console.log(self.values.pageConfig);
					//console.log(self.values.pageConfig.mark_course_complete_on_enter);
					
                    var deferred = $.Deferred();
                    
					//dialog
					if(self.values && self.values.dialogNav){
						if(self.values.dialogNav.track.mark_course_complete_on_enter){
							//dialog set course complete
							self.dataModel.setLessonStatus('completed');
						}
					}
					
					//page
					if (self.values && self.values.pageConfig) {
                        if ((self.values.pageConfig.completion && self.values.pageConfig.force_complete_on_enter)) {
                            self.models.currentSuspendData.setStatus('completed');
                        }

                        if (self.values.pageConfig.count) {
							//console.log("INCREMENT COUNNNNT");
                            self.models.currentSuspendData.incrementCount();
                        }

                        if (self.values.pageConfig.auto_reset_on_enter) {
                            self.reattemptScreen(null, 'default', true);
                        }

                        if ((self.values.pageConfig.mark_course_complete_on_enter)) {
							//console.log("mark_course_complete_on_enter");
                            self.dataModel.setLessonStatus('completed');
                        }

                        if (self.values.pageConfig.complete_course_on_score) {
                            var primaryScore = self.get('primaryScore');
                            if (_.isNumber(primaryScore) && _.isNumber(self.values.pageConfig.complete_course_on_score) && (primaryScore >= self.values.pageConfig.complete_course_on_score)) {
                                self.setCourseScoreFrom('primary');
                                self.models.currentSuspendData.setStatus('completed');
                                self.dataModel.setLessonStatus('completed');
                            }
                        }

                    }

                    setTimeout(function() { deferred.resolve(); }, window.pageLoadSpeed);
                    return deferred.promise();
                };


            //orderly commit.
            //                commitPageStatus().always(function(){
            //                    commitCount().always(function(){
            //                        commitCourseStatus().always(function(){
            //                            self.suspendDataChanged(true).always(function(){deferred.resolve();})
            //                        });
            //                    })
            //                });

            initializePage()
                .always(function() {
                    self.suspendDataChanged(true).always(function() { deferred.resolve(); })
                });

            self.trigger("initialize:page", self);
            return deferred.promise();
        },

        getPageScore: function(id) {
			
			var suspendData = this.currentSuspendData || this.models.currentSuspendData;
            if (suspendData && typeof suspendData.getCompletion === 'function') {
                if (id !== undefined) {
                    var getSuspendData = window.bazingaApp.models.api.getSuspendData();
                    console.log("id:"+id);
					//console.log(getSuspendData);
                    return getSuspendData[id].sc || 0;
                } else {
                    return this.models.currentSuspendData.getScore();
                }
            }
			
        },
		
		/*resetModule:function(){
			//reset complete/data/count for all pages
			
			console.log("test reset");
		},*/

        setMultiple: function(values) {
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
				
                _.each(values, function(v) {
                    if (v.key == 'score') {
						console.log(v);
                        self.dataModel.setScore(v.value);
                    } else if (v.key == 'status') {
                        self.dataModel.setLessonStatus(v.value);
                    }
                });

                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.resolve();
        },

        setComments: function(comment) {
            console.log("navigation setcomments");
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setLessonComments(comment);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        getComments: function() {
            var self = this;
            return self.dataModel.getLessonComments();
        },
		
		setInteractionStudentResponse: function(num,data) {
            console.log("navigation set student response");
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setLessonStudentResponse(num,data);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        /*write only
		getStudentResponse: function(id) {
            var self = this;
            return self.dataModel.getLessonStudentResponse(id);
        },*/
		
		setInteractionId: function(num,id) {
            console.log("navigation set interaction id");
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setLessonInteractionId(num,id);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        setSpeed: function(speed) {
            console.log("navigation setspeed");
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setLessonSpeed(speed);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        setCourseScore: function(score) {
            var deferred = $.Deferred(),
                self = this;
            setTimeout(function() {
                self.dataModel.setScore(score);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },
        setCourseStatus: function(status) {
			
			console.log("navmodel setcoursestatus "+status);
			var self = this;
			
			if(status == "completed"){
				self.set('courseStatus', "c", { silent: true });
			}
				
            var deferred = $.Deferred(),
                self = this;

            setTimeout(function() {
                self.dataModel.setLessonStatus(status);
                self.dataModel.commit("");
                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },

        /**
         * Set up the course score from one of the primary / secondary / tertiary scores
         * @param scoreFrom
         */
        setCourseScoreFrom: function(scoreFrom) {
            scoreFrom = scoreFrom || 'primary';
            var score,
                self = this,
                deferred = $.Deferred();


            switch (scoreFrom) {
                case 'secondary':
                    score = this.get('secondaryScore') || -1;
                    break;
                case 'tertiary':
                    score = this.get('tertiaryScore') || -1;
                    break;
                case 'primary':
                default:

                    score = this.get('primaryScore') || -1;
                    break;
            }

            setTimeout(function() {
                if (score != -1) {
                    self.dataModel.setScore(score);
                    self.dataModel.commit("");
                }

                deferred.resolve();
            }, window.pageLoadSpeed);

            return deferred.promise();
        },
        getCourseCompletion: function() {
            var self = this;
            return self.dataModel.getLessonStatus();
        },
        getPageCompletion: function(id) {
            //console.log("getPageCompletion");
            var suspendData = this.currentSuspendData || this.models.currentSuspendData;
            if (suspendData && typeof suspendData.getCompletion === 'function') {
                if (id !== undefined) {
                    var getSuspendData = window.bazingaApp.models.api.getSuspendData();
                    //console.log(getSuspendData);
                    return getSuspendData[id].a;
                } else {
                    return this.models.currentSuspendData.getCompletion();
                }
            }
            return null;
        },

        getPageData: function(id) {
            if (id !== undefined) {

                var suspendData = window.bazingaApp.models.api.getSuspendData();
                return suspendData[id].da;

            } else {
                //default to this page's data
                return this.models.currentSuspendData.getData();
            }
        },

        getPageDataForPage: function() {
            return this.models.currentPageNav;
        },

        getPageCount: function(id) {
            if (this.models.currentSuspendData == null) {
                return;
            }
			
			if (id !== undefined) {
					var suspendData = window.bazingaApp.models.api.getSuspendData();
                return suspendData[id].co;	
			}else{
            return this.models.currentSuspendData.getCount();
			}
        },
        getAllPages: function() {
            return this.values.allPages;
        },

        getAllTrackablePages: function() {
            return _.filter(this.values.allPages, function(page) {

                if (page.type == "page") {
                    return page.track.completion;
                } else {
                    return false;
                }
            }, this);

        },
		
		getAllTopicPages: function(id) {
			var pageData = window.bazingaApp.models.navigation.getPageDataForPage();
			var groupId = pageData.attributes.parent;
			if(id !== undefined){
				groupId = id;
			}
			var nav = window.bazingaApp.models.navigation.getNav();
			
			//console.log(_.size(nav[groupId]));
			
			return nav[groupId];
			
		},
		
		getAllTopicPagesNum: function(id) {
			var pageData = window.bazingaApp.models.navigation.getPageDataForPage();
			var groupId = pageData.attributes.parent;
			if(id !== undefined){
				groupId = id;
			}
			var nav = window.bazingaApp.models.navigation.getNav();
			
			//console.log(_.size(nav[groupId]));
			
			return _.size(nav[groupId]);
			
		},
		
		getAllCompletedTopicPagesNum: function(id) {
			var pageData = window.bazingaApp.models.navigation.getPageDataForPage();
			var groupId = pageData.attributes.parent;
			if(id !== undefined){
				groupId = id;
			}
			var nav = window.bazingaApp.models.navigation.getNav();
			//console.log(nav);
			var groupNav = nav[groupId];
			var numCompleted = 0;
			
			for (var property in groupNav) {
					if (groupNav.hasOwnProperty(property)) { //only works for top level topic pages
        			if(window.bazingaApp.models.navigation.getPageCompletion(property) == "c"){
						console.log(property + " - completed");
						numCompleted = numCompleted + 1;
					}
						}
					}
    			
			
			return numCompleted;
			
		},

        getInfo: function(key) {
            return this.get(key);
        },

        setPrimaryScore: function(score) {
            return this.set('primaryScore', score);
        },
        setCourseData: function(data) {
            return this.set('courseData', data);
        },
        getCourseData: function() {
            return this.get('courseData');
        },
        getPrimaryScore: function() {
            return this.get('primaryScore');
        },
        setSecondaryScore: function(score) {
            return this.set('secondaryScore', score);
        },
        getSecondaryScore: function() {
            return this.get('secondaryScore');
        },
        setTertiaryScore: function(score) {
            return this.set('tertiaryScore', score);
        },
        getTertiaryScore: function() {
            return this.get('tertiaryScore');
        },

        getIsDialog: function() {
            return this.values.isDialogScreen;
        },

        /**
        Additional and aux params for bazinga
        */
        getParam: function(ix) {
            return this.get('param' + ix);
        },
        setParam: function(ix, param) {
            return this.set('param' + ix, param);
        },
        getParam1: function() {
            return this.get('param1');
        },
        getParam2: function() {
            return this.get('param2');
        },
        getParam3: function() {
            return this.get('param3');
        },
        getParam4: function() {
            return this.get('param4');
        },
		getLang: function() {
            return this.get('lang');
        },
		getOfflineId: function() {
            return this.get('oi');
        },
        getQuizAttempts: function() {
            return this.get('quizAttempts');
        },
        getProgress: function() {
            return this.get('progress');
        },
        setParam1: function(param) {
            return this.set('param1', param);
        },
        setParam2: function(param) {
            return this.set('param2', param);
        },
        setParam3: function(param) {
            return this.set('param3', param);
        },
        setParam4: function(param) {
            return this.set('param4', param);
        },
		setLang: function(lang) {
            return this.set('lang', lang);
        },
		setOfflineId: function(oi) {
            return this.set('oi',oi);
        },
        setQuizAttempts: function(qa) {
            return this.set('quizAttempts', qa);
        },

        getPreviousScreen: function() {
            return this.get('previousScreen');
        },
        getCurrentScreen: function() {
            return this.get('currentScreen');
        },
		setCurrentScreen: function(id) {
            return this.set('currentScreen',id);
        },

        getConfigForScreen: function() {
            return this.values.pageConfig;
        },
        getNavForScreen: function(id) {
            //console.log("getNavForScreen "+id);
            if (!id) {
                return this.values.pageNav;
            }
            return (_.first(_.where(this.values.allPages, { id: ("" + id + "") })));
        },
        getNavForDialog: function(id) {
            //get the nav for the right screen .
            return (_.first(_.where(this.values.allDialogs, { id: id })));
        },
        getNavForScreenByRole: function(role, id) {
            role = role || 'default';
			console.log("getNavForScreenByRole. role is "+role+". id is "+id);

            var nav;
            if (!id) {
				console.log("no id");
                nav = this.values.pageNav;
				console.log(this);
				console.log(this.values);
            } else {
				console.log("id is:"+id);
                nav = this.getNavForScreen(id);
            }
			console.log("getNavForScreenByRole. use nav:");
			console.log(nav);
            return (nav && nav.role && nav.role[role]) ? nav.role[role].nav : null;

        },

        getSuspendData: function() {
            return this.get('suspendData');
        },
        getRole: function() {
            return this.get('role');
        },

        getNav: function() {
			//console.log("get nav");
            return this.get('nav');
        },

        getDecision: function(decisionPoint, role, id) {
            //console.log("getDecision. decisionPoint: " + decisionPoint);
            //console.log("role "+role);
            //console.log("id " + id);
            var self = this,
                navForRole = _.memoize(self.getNavForScreenByRole),
                nav,
                navForDialog,
                role = self.get('role') || 'default';
            //console.log("this.getIsDialog()");
            //console.log(this.getIsDialog());
			
			//console.log("id "+id);
			
            if (this.getIsDialog()) {
                navForDialog = self.values.dialogNav;
                if (navForDialog && navForDialog.role && navForDialog.role[role]) {
                    nav = navForDialog.role[role].nav;
                    if (!nav) {
                        return false;
                    }
                    return nav[decisionPoint] || 'home';
                }
            } else {
                nav = navForRole(role, id);
				console.log("nav");
				console.log(nav);
                if (nav) {
					
					var autoPage = 'home';
					
					var pageId = parseInt(this.values.pageNav.id);
					
					if(decisionPoint == "next"){
							autoPage = pageId+1;
					}else if(decisionPoint == "back"){
						autoPage = pageId-1;
					}
					
					//console.log("autoPage "+autoPage);
					
                    return nav[decisionPoint] || autoPage;
                }
            }

            return null;
        },

        getAllDialogs: function() {
            return this.values.allDialogs;
        },
        getDialog: function(dialogname) {
            var dialogs = this.values.allDialogs;

            return _.first(_.where(dialogs, { id: (_(dialogname).getKeyHash()) }));
        },

        getLockables: function() {
			//console.log("getlockables");
			//console.log(this);
			//console.log(this.conditional);
            return this.conditional.lockables;
        },
        getCrumbs: function(id) {
            var self = this,
                nav,
                crumbs = [],
                ret;

            if (this.getIsDialog()) {
                return self.values.dialogNav['title'];
            }
            nav = self.getNavForScreen(id);
            crumbs = nav.crumbs;


            if (!_.isEmpty(crumbs)) {
                ret = [];
                _.each(crumbs, function(v) {
                    var n = self.getNavForScreen(v);
                    ret.push(n);
                });
                return ret;
            }

            return crumbs;
        },

        setPageCompletion: function(completion,optionalId) {
            if (!this.models || !this.models.currentSuspendData) {
                console.log("Cannot locate model to set page completion");
                return this;
            }
			
			if(completion == "completed"){
				$("[data-decision='next']").removeClass("is-disabled").prop("disabled", false);
			}
			
            if (optionalId !== undefined) {

                 var self = this;
                var currentSuspendData = window.bazingaApp.models.api.getSuspendData();
                var hashed = {
                    'completion': _("completion").getKeyHash()
                };
                var deferred = $.Deferred();
				if(completion == "completed"){
					completion = "c";
				}

                _.map(currentSuspendData, function(v) {
					//console.log(v);
                    if ((v.id) == optionalId) {
                        v[hashed.completion] = completion;
						//v.track.completion = "c";
						//console.log("v.id");
						//console.log(v.id);
						
						//var pageNav = window.bazingaApp.models.api.getNavForScreen(v.id);
						//pageNav.track.completion = true;
						//console.log(pageNav.track.completion);
                    }

                    return v;

                });
				//console.log("suspendDataChangeddddddddd");
                self.suspendDataChanged(true);

            }else{
				var self = this;
            this.models.currentSuspendData.setCompletion(completion);
				self.suspendDataChanged(true);
				
            return this;
            }
        },

        reattemptScreen: function(id, role, preventCommit) {
            var self = this,
                nav,
                reset,
                resetScores,
                resetStatus,
                resetData,
                deferred = $.Deferred(),
                currentSuspendData,
                hashed = {
                    'completion': _("completion").getKeyHash(),
                    'completed': _("completed").getKeyHash(),
                    'passed': _("passed").getKeyHash(),
                    'not_attempted': _("not attempted").getKeyHash(),
                    'score': _("score").getKeyHash(),
                    'data': _("data").getKeyHash()
                };
			
			console.log("reattemptScreen");

            role = role || 'default';

            if (this.values.isDialogScreen) {
                nav = this.values.dialogNav;
            } else if (!id) {
                nav = this.values.pageNav;
            } else if(id == "all"){
				nav = window.bazingaApp.models.navigation.getNav();
				
				self.set('primaryScore', null);
				
				currentSuspendData = self.get('suspendData');
				
            _.map(currentSuspendData, function(v) {
					//console.log(v[hashed.score]);
                if(v[hashed.score]){    
				v[hashed.score] = 0;
				}
                    v[hashed.completion] = hashed.not_attempted;
                    v[hashed.data] = null;
				v.co = 0;
				//console.log(v);
				return v;
            });
				
			}else {
                nav = this.getNavForScreen(id);
            }
			
			//console.log("NAVVVV");
			//console.log(nav);
			
			if(id != "all"){
				if (!nav || !_.has(nav, 'role') || !nav.role[role]) {
					return false;
				}

				nav = nav.role[role];

				if (!_.has(nav, 'reset')) {
					return false;
				}
				reset = nav.reset;
			
				console.log("end nav ");
				console.log(nav);

				resetScores = _.has(reset, 'score');
				resetStatus = _.has(reset, 'status');
				resetData = _.has(reset, 'data');

				if (_.has(reset, 'primaryScore')) {
					self.set('primaryScore', null);
				}

				currentSuspendData = self.get('suspendData');

				_.map(currentSuspendData, function(v) {
					if (resetScores && reset.score.indexOf(v.id) > -1) {
						v[hashed.score] = 0;
					}

					if (resetStatus && reset.status.indexOf(v.id) > -1) {
						v[hashed.completion] = hashed.not_attempted;
					}

					if (resetData && reset.data.indexOf(v.id) > -1) {
						v[hashed.data] = null;
					}

					return v;
				});
			}

            if (!preventCommit) {
                self.once("updated:suspendData", function() {
                    deferred.resolve();
                });

                self.updateSuspendData('scoringAndCompletion');
            } else {
                setTimeout(function() {
                    deferred.resolve();
                }, window.pageLoadSpeed);
            }

            return deferred.promise();
        },
        setPageData: function(data, optionalId, preventCommit) {
            console.log("setPageData");
            if (optionalId !== undefined) {
                var self = this;
                var currentSuspendData = window.bazingaApp.models.api.getSuspendData();
                var hashed = {
                    'data': _("data").getKeyHash()
                };
                var deferred = $.Deferred();

                //console.log(currentSuspendData);
                _.map(currentSuspendData, function(v) {
                    if ((v.id) == optionalId) {
                        v[hashed.data] = data;
                    }

                    return v;

                    /*var suspendData = window.bazingaApp.models.api.getSuspendData();
                            console.log(suspendData);
                
                            for(var i=0;i<suspendData.length;i++){
                                    if(suspendData[i].id == optionalId){
                                        
                                    }
                            }
                
                            return suspendData[optionalId].da; //change this to set not get*/
                });

                self.suspendDataChanged(true);

                /*if (!preventCommit) {
                    self.once("updated:suspendData", function() {
                        deferred.resolve();
                    });

                    self.updateSuspendData('scoringAndCompletion');
                } else {
                    setTimeout(function() {
                        deferred.resolve();
                    }, window.pageLoadSpeed);
                }

                return deferred.promise();*/


            } else {
                this.models.currentSuspendData.setData(data);
                return this;
            };
        },
        setInfo: function(key, value, options) {
            this.set(key, value);
            return this;
        },
        setCurrentPool: function(poolId) {
            this.set('currentPool', poolId);
            return this;
        },
        getCurrentPool: function() {
            return this.get('currentPool');
        },
        setPageScore: function(score,optionalId) {
			
			if (optionalId !== undefined) {
				
				var self = this;
                var currentSuspendData = window.bazingaApp.models.api.getSuspendData();
                var hashed = {
                    'score': _("score").getKeyHash()
                };
                var deferred = $.Deferred();

                //console.log(currentSuspendData);
                _.map(currentSuspendData, function(v) {
                    if ((v.id) == optionalId) {
                        v[hashed.score] = score;
                    }

                    return v;
                });

                self.suspendDataChanged(true);
				
			}else{
            	this.models.currentSuspendData.setScore(score);
			}
            return this;
        },

        suspendDataDefaults: function(suspend, page, config) {
            suspend[_('id').getKeyHash()] = page.id;


            if (config.count) {
                suspend[_('count').getKeyHash()] = suspend[_('count').getKeyHash()] || ''; //0
            }
            if (config.data) {
                suspend[_('data').getKeyHash()] = suspend[_('data').getKeyHash()] || '';
            }
            //block track
            if (_.has(page, 'block-track') || !_.has(page, 'track')) {
                //completion
                if (config.completion) {
                    suspend[_('completion').getKeyHash()] = _(suspend[_('completion').getKeyHash()] || 'not attempted').getKeyHash();
                }
                //score
                if (config.score) {
                    suspend[_('score').getKeyHash()] = suspend[_('score').getKeyHash()] || ''; //0
                }
            }
            return suspend;
        },
        /**
         * Create a suspend data
         */
        retrieveSuspendData: function() {
            var attributes = this.attributes,
                self = this,
                hashedPage = _('page').getKeyHash(),
                suspendData = (function() {
                    var sus = {};
                    sus[hashedPage] = {};
                    return sus;
                }()),
                currentSuspendData = self.get('suspendData'),
                getData = function(pages) {
                    _.map(pages, function(page) {

                        var config = _.extend({ "count": true, "data": true, "completion": true, "score": false }, page.track),
                            suspend = (function() {
                                var data = _.filter(currentSuspendData, function(it) {
                                    return it.id == page.id;
                                });
                                if (data.length == 0) {
                                    return {}
                                }
                                return _.first(data);
                            }());


                        suspend = self.suspendDataDefaults((suspend || {}), page, config);

                        if (_.has(suspend, 'type')) { delete suspend.type; }


                        if (!_.has(page, 'items')) {
                            suspendData[hashedPage][page.id] = suspend;
                        } else {
                            getData(page.items);
                        }
                    });
                };

            _.map(attributes, function(v, k) {
                var hashedKey = _(k).getKeyHash();
				
				//console.log("k");
				//console.log(k);
				//console.log("v");
				//console.log(v);
				
                if (k !== 'preferred') {
                    //Do nothing
                    if (k == 'suspendData') {
                        return true;
                    }
                    suspendData[hashedKey] = v;
                    return true;
                }
                getData(v.pages);
                return true;
            });


            return (function() {
                var stringified = _(suspendData).crunchSuspendData();
                return stringified;
            }());
        },


        setDataModel: function(dataModel) {
            this.dataModel = dataModel;
            if (typeof dataModel.setNavModel == 'function') {
                dataModel.setNavModel(this);
            }

            this.initializeDataModelListeners();
            return this;
        },
        setCourseConfig: function(courseConfig) {
            this.courseConfig = courseConfig;
            return this;
        },
        getCourseConfig: function() {
            return this.courseConfig;
        },
        initializeDataModelListeners: function() {

        }
    });

})(window.$ || window.JQuery);

(function($) {
	"use strict";
	$(function() {
		/**
         * control the visibility of global navigation bar
         */
		var conbinationMenu = $('#js-dropdown-mobile'),
		    mainMenu = $('#js-dropdown-mobile > ul:first-child'),
		    subMenu = $('#js-dropdown');
		function setVisibility() {
			if ($(window).width() <= 768) {//mobile
				conbinationMenu.addClass('collapse');//in mobile view, conbinationMenu should be hidden
				if (subMenu.hasClass('in')) {//if submenu has already opened in largeScreen
					conbinationMenu.addClass('collapse in');
				}
			} else {//large screen
				conbinationMenu.removeClass('collapse in');//in large screen, conbinationMenu should be shown
				if (conbinationMenu.hasClass('in')) {//conbinationMenu has already opened in mobile
					subMenu.addClass('collapse in');
				}
			}
		}

		//detect on page load
		setVisibility();
		//detect on window resize
		$(window).on('resize', function() {
			setVisibility();
		});
		//ready for show, remove all hidden classes
		$('.navbar').on('show.bs.collapse', function() {
			if ($(window).width() <= 768) {
				$('#js-dropdown-mobile > ul', $(this)).addClass('in');
			}
		});
		//ready for hidden, remove all display classes
		$('.navbar').on('hidden.bs.collapse', function(e) {
			if ($(window).width() <= 768) {
				if(e.target.id == 'js-dropdown-mobile'){
					subMenu.removeClass('in');
					mainMenu.removeClass('in');
				}
			}else{
				conbinationMenu.removeClass('in');
			}
		});
	});
})(window.$ || window.JQuery); 
(function($){
    "use strict";

    /**
     * todo: convert to a template . So that the preloader gets compiled
     * @type {*}
     */
    window.bazingaApp.views.preloaderView = Backbone.View.extend({
        el:$("[data-preloader='1']"),
        selector : {
            'icon':"[data-icon]",
            'label':"[data-label]",
            'percentage':"[data-percentage]"
        },

        show : {
            'label':true,
            "percentage":true,
            "icon":true,
            "symbol" : "%"
        },

        shown : true,
        label : "Loading..",
        percentage : 0,
        delay : 15,


        initialize:function(){
            this.$el.find(this.selector.label).text(this.label);
            this.$el.find(this.selector.percentage).text(this.percentage);
            this.resetVisibleElements();
            _.bindAll(this, 'setPercentage', 'incrementTo');
        },
        setLabel : function(label){
            this.label = label;
            this.$el.find(this.selector.label).text(label);
            return this;
        },
        setPercentage : function(percentage){
            this.percentage = percentage;
            this.$el.find(this.selector.percentage).text(percentage + this.show.symbol);
            if(percentage == 100){
                this.shown = false;
                this.$el.hide();
            }
            else{
                if(!this.shown){
                    this.$el.show();
                    this.shown = true;
                }
            }
            return this;
        },

        incrementTo : function(incrementTo,delay){
            var current = this.percentage,
                self = this,
                interval,
                deferred = $.Deferred();
                delay = delay || self.delay || 30;

                interval = setInterval(function(){
                    if(current > 100){
                        current = 100;
                    }
                    else if(current > incrementTo){
                        current = incrementTo;
                    }
                    if(current == 100 || current == incrementTo /*|| incrementTo == 100*/){
						//preloader finished
                        clearInterval(interval);
                        deferred.resolve();
						//self.setPercentage(100); maybe change this to 100 if incrementTo is 100
                        return false;
                    }
                    current +=10; //1
                    self.setPercentage(current);
					//console.log("incrementinggggg "+current+"/"+incrementTo);
                },delay);

                return deferred.promise();
        },
        resetVisibleElements: function(){
            if(this.show.icon){
                this.$el.find(this.selector.icon).show();
            }
            else{
                this.$el.find(this.selector.icon).hide();
            }

            if(this.show.percentage){
                this.$el.find(this.selector.percentage).show();
            }
            else{
                this.$el.find(this.selector.percentage).hide();
            }

            if(this.show.label){
                this.$el.find(this.selector.label).show();
            }
            else{
                this.$el.find(this.selector.label).hide();
            }

            return this;
        },
        setShow : function(show){
            _.extend(this.show,show );
            return this.resetVisibleElements();
        },

        enable : function(){
            this.$el.show();
            return this;
        },
        disable : function(){
            this.$el.hide();
            return this;
        }

    });
})(window.$||window.JQuery);
(function ($) {
    "use strict";
    window.bazingaApp.views.abstractComponentView = Backbone.View.extend({
        completed: 'not-attempted',
        componentType:'abstract',
        enabled : true,

        getComponentType : function(){return this.componentType;},
        /**
         * Make sure this is included in the component js
         */
        isEnabled : function(){return this.enabled;},
        /**
         * Make sure this is included in the component js
         */
        getIsCompleted: function () {
            return this.completed == 'completed' || this.completed === true || this.completed === 1;
        },

        init : function(){

        }

    });
})(window.$ || window.JQuery);
(function($) {
    "use strict";

    /*
    
Mandatory Attributes:
data-reveal-object="#pop1" for button, the id of popup should be "pop1")
data-reveal-type (the way to render the popup, options: "popup", "overlay") 

Unused types: 'dialog' (just use overlay) and 'tooltip' doesn't work and seems to only works on hover.moved to bottom

Optional:
class="js-popup-focus" (if set to one of the html element inside in popup, the element will be focused after popup displayed.)
                 (if not set, will focus the popup self) doesn't work?

usage:

1) html structure for type: "popup":

<button data-reveal-type="popup" data-reveal-object="#pop1">1btn</button>
<button data-reveal-type="popup" data-reveal-object="#pop2">2btn</button>

<div id="pop1" data-reveal-target="popbox">1content</div>
<div id="pop2" data-reveal-target="popbox">2content</div>
  
     */
    window.bazingaApp.views.popupView = window.bazingaApp.views.abstractComponentView.extend({
        el: $('[data-reveal-type]:not(.js-prevent-interaction)'),
		
        events: {
            "click": "dispatch",
            "touchend": "dispatch",
            "keydown": "onKeyPress"
        },
        clickable: true,
        selector: {
            container: '[data-reveal-type]',
            popup: '[data-reveal-target="popbox"]',
            tooltip: '[data-reveal-target="tooltip"]',
            dialog: '[data-reveal-target="pop-dialog"]',
            overlay: '[data-reveal-target="overlay"]',
            close: '[data-reveal-target="pop-close"]'
        },
        initialize: function() {
            _.bindAll(this, 'dispatch', 'show', 'hide', 'appendContent', 'dialog', 'recalculate', 'doFocus', 'applyAccessibility', 'delegateCloseEvent', 'onKeyPress');
            this.delegateEvents();
            this.componentType = 'popup';
            //console.log("number popups :" + this.$el.length);
            if (this.$el.length == 0) {
                //console.log("0 completed");
                this.enabled = false;
				this.completed = 'completed';
            } else {
                //console.log("not 0 incomplete");
                this.completed = "incomplete";
            }
			
			//get number of non trackables
			
			var nonTrackables = 0;
			
			for (var i=0;i<this.$el.length;i++){
				var anEl = this.$el[i];
				
				for(var e=0;e<anEl.attributes.length;e++){
					var anAttr = anEl.attributes[e];
					//console.log(anAttr);
					if(anAttr.name == "data-prevent-track"){
						nonTrackables += 1;
					}
				}
			}
			
			//console.log(this.$el);
			//console.log(this.$el[0].attributes);
			
			//console.log("trackable popups "+nonTrackables+"/"+this.$el.length);
			
			if(this.$el.length == nonTrackables){
				//only non trackables
                this.completed = 'completed';
			}


            this.delegateCloseEvent();
            this.dialog();
            this.recalculate();
			
			/*$('#overlay').keypress(function(e){
				console.log("overlaykeypress "+e.which);
				if(e.which == 27){
					// Close my modal window
					console.log("is escape");
					$(".button-close").trigger( "click" );
				}
			});*/
			
			document.onkeydown = function(evt) {
				evt = evt || window.event;
				var isEscape = false;
				if ("key" in evt) {
					isEscape = (evt.key == "Escape" || evt.key == "Esc");
				} else {
					isEscape = (evt.keyCode == 27);
				}
				if (isEscape) {
					//console.log("trigger button close");
					$(".button-close:visible").trigger( "click" );
				}
			};
			
        },
        onKeyPress: function(e) {
			console.log("keypressssssssssssssss");
            if (e.keyCode == 13) {
				console.log("is 13/enter");
                this.dispatch(e);
            }
			if (e.keyCode == 27) {
				console.log("ESC");
			}
        },
        recalculate: function() {
            //console.log("recalculate");
            if (this.getIsCompleted()) {
                return this;
            }

            var self = this,
                completed = self.completed = self.completed || false,
                totalCount = $(self.selector.container) /*.not(':hidden').not('[data-prevent-track]')*/ .length,
                incompleteCount = $(self.selector.container).not('.is-visited').length,
                completedCount = $(self.selector.container + '.is-visited').not('[data-prevent-track]').length,
                nonTrackables = $(self.selector.container + '[data-prevent-track]').length;

            //console.log("completed " + completedCount);
            //console.log("nonTrackables " + nonTrackables);
            //console.log("total " + totalCount);

            if (incompleteCount == 0 || completedCount + nonTrackables >= totalCount) {
                self.completed = 'completed';
                self.trigger('completed:reveal', self, { total: totalCount });
            } else if (incompleteCount !== totalCount) {
                self.completed = 'incomplete';
            }
			
			//console.log("fin recalculate");

            return self;
        },
        dispatch: function(e) {
            //console.log("dispatch");
            var content,
                target = e.target,
                self = this,
                $target = $(target).data('revealObject') ? $(target) : $(target).closest('[data-reveal-object]'),
                revealData = $target.data('revealData'),
                revealObj = $target.data('revealObject'),
                hideObj = $target.data('hideObject'),
                revealType = $target.data('revealType'),
				addClass = $target.data('addClass'),
				focusObj = $target.data('revealObject');
				
            //console.log("dispatch");

            if ($target.hasClass('is-disabled')) {
                console.log("is disabled");
                return;
            } //example: locker for simple senario homepage

            //console.log("add is visisted");
            //mw makes it work for a non-popup button
			if(!$(target).hasClass("is-disabled")){
            	$(target).addClass("is-visited");
			}

            self.type = "";
            e.preventDefault();
            //a flag to control the click behavior will only be enabled after last animation
			//removed because if you clicked fast enough before the animation finished, the completion would not trigger
            /*if (!self.clickable) {
                return;
            }*/

            //selecting the current target
            this.$el.removeClass('is-selected');
            //complete the target
            $target.addClass('is-selected');
			
			if(!$target.hasClass("is-disabled")){
				//console.log("add");
				$target.addClass('is-visited');
			}
			
            self.checkLockedBtns();
			
			//console.log("dispatch");
			//console.log(self);
			//console.log($target);
			
			if($target.closest(".btnGroup")){
					var btnGroup = $target.closest(".btnGroup");
					var totalBtns = btnGroup.find("[data-reveal-type]").not("[data-prevent-track]").length;
					var visitedBtns = btnGroup.find(".is-visited[data-reveal-type]").not("[data-prevent-track]").length;
					var incompleteBtns = btnGroup.find(".contentCompleteBtn[data-reveal-type]").not(".is-completed").not("[data-prevent-track]").length;
					//optional?  
					console.log("incompleteBtns "+incompleteBtns);
					console.log((visitedBtns - incompleteBtns)+"/"+totalBtns);
					
					if(visitedBtns - incompleteBtns == totalBtns){
						btnGroup.addClass("is-completed");
					}
					
				}

            (function() {
                var r = ($target.data('revealReflect'));

                r = ((r || "") + "").split(",");
                if (r.length == 0) {
                    return null;
                }

                _.each(r, function(v, k) {
                    $('[data-reveal-id="' + v + '"]').addClass('is-visited');
                });
            })();

			//console.log("revealType "+revealType);
            switch (revealType) {
                case 'popup':
                    self.clickable = false;
                    //hide all others, keep only one opens
					
					//console.log(revealObj);
					
					var sameAttr = $(revealObj).attr("data-reveal-target");
					console.log(sameAttr);
					
					$('[data-reveal-target='+sameAttr+']').hide();
					
                    //$(self.selector.popup).not(revealObj).hide();: 
                    if (hideObj) {
                        this.hide(hideObj);
                    }
                    this.show(revealObj);
                    $(window).trigger('resize');
                    break;
                case 'tooltip':
                    $(self.selector.tooltip).not(revealObj).hide();
                    this.show(revealObj);
                    $(window).trigger('resize');
                case 'dialog':
                    content = $(this.selector.dialog + ':eq(0) .modal-body'); //dialog content
                    this.appendContent(content, revealData);
                    break;
                case 'overlay':
					console.log("overlay "+revealObj);
                    self.type = "overlay";
                    content = $(this.selector.overlay + ' .js-overlay-content'); //overlay content
                    self.appendContent(content, revealData);
                    self.show(revealObj, revealType);
                    $(window).trigger('resize');
                    break;
            }
			
			if(addClass){
				if(revealData){
					//overlay
					$(revealData).addClass(addClass);
				}else{
					$(revealObj).addClass(addClass);
				}
			}
			
            self.recalculate();
        },
        show: function(el) {

            var self = this,
				courseConfig = window.bazingaApp.models.api.getCourseConfig(),
				accessibilityVersion = _.has(courseConfig,'accessibilityVersion') ? courseConfig['accessibilityVersion'] : 1;
			
            $(el).fadeIn(function() {
                setTimeout(function() {
                    self.clickable = true;
                }, 100);
				
				
				var revealId = $(el).attr('data-reveal-id'); //add this to thing that's showing, then add [data-reveal-data=#' + revealId + '] to the element you want focus after it's shown
				
				/*console.log($(el));
				console.log(el);
				console.log($(this));
				console.log("revealId "+revealId);*/
				
				//console.log($(el)); element that's showing
					if(accessibilityVersion  >= 2){
					$(el).find('[tabindex]:first').attr("tabindex",0).focus(); 
					
				//old method, makes original button focus on close
						console.log($(el).find('[tabindex]:first'));
						console.log("show trigger focus?");
                /*self.doFocus( revealId ? $('[data-reveal-data=#' + revealId + ']') : $('[data-reveal-object="#' + $(this).attr('id') + '"]:not(' + self.selector.close + ')'), false);*/
						
					}
				
                //if ($.inArray(($(self.el).data('revealType')), ["overlay"]) > -1) {
				//console.log("show");
				//console.log($(el));
				
				if (($.inArray(($(el).data('revealType')), ["overlay"]) > -1) || $.inArray(($(el).data('revealTarget')), ["overlay"]) > -1 ){
					console.log("is overlay");
                    self.applyAccessibility($(this), true); //overlay accessibilty, makes everything outside of overlay untabbable
                }

                if ($(el).find('video').length != 0) {
                    $(window).trigger('resize');
                    /*console.log("play video");*/

                    var videoContainer = $(el).find('.mejs-container');

                    videoContainer.addClass("isVisible");
                    var videoChild = $(el).find('video:visible');
                    //autoplay video if specified attribute
                    if (videoChild.attr('autoplayOnVisible') != null) {
                        videoChild[0].play();
                    }
                }
				

            });
        },
        hide: function(el) {
			console.log("hide");
            var self = this,
				courseConfig = window.bazingaApp.models.api.getCourseConfig(),
				accessibilityVersion = _.has(courseConfig,'accessibilityVersion') ? courseConfig['accessibilityVersion'] : 1;
			
			if($(el).attr("data-animation-hide") != "fade" || $(el).attr("data-animation-hide") == "instant"){
				$(el).hide();
			}
			
            $(el).fadeOut(function() {
                var revealId = $(this).attr('data-reveal-id'); //not sure
				
				//console.log("hide. dofocus");
					if(accessibilityVersion  >= 2){
				$(el).find('[tabindex]:first').attr("tabindex",0).focus(); 
				
						console.log("hide trigger focus?");
                self.doFocus( revealId ? $('[data-reveal-data=#' + revealId + ']') : $('[data-reveal-object="#' + $(this).attr('id') + '"]:not(' + self.selector.close + ')'), false);
					}
				
                if ($.inArray(($(self.el).data('revealType')), ["overlay"]) > -1 || $.inArray(($(el).data('revealTarget')), ["overlay"]) > -1) {
					console.log("close overlay");
                    self.applyAccessibility(revealId ? $('[data-reveal-data=#' + revealId + ']') : $('[data-reveal-object="#' + $(this).attr('id') + '"]:not(' + self.selector.close + ')'), false);
					
					//stop all audio
					$('audio').each(function(){
						this.pause(); // Stop playing
						if(this.currentTime){
						this.currentTime = 0; // Reset time
						}
					}); 
                }

                $(window).trigger('resize');

                //pause video if in modal window
                if ($(el).find('video').length != 0) {

                    $('video').trigger('pause');
                    var videoContainer = $(el).find('.mejs-container');

                    videoContainer.removeClass("isVisible");
                }

            });
        },
        dialog: function() {
            var self = this;
            self.doFocus($('.modal-dialog', $(this)));
            $(this.selector.dialog + ':eq(0)').on('shown.bs.modal', function() {
                self.applyAccessibility($('.modal-dialog', $(this)));
            });
        },
        appendContent: function(content, el) {
            var self = this,
                $el = $(el);

            content.closest(self.selector.overlay).attr('data-reveal-id', $(el).attr('id'));
            if ($(el, content).length == 0) {
                $el.appendTo(content);
                self.trigger("data:popup", self, { $tgt: content });
            }
            $('.js-overlay-data').hide();
            $(el).show();
        },
        doFocus: function(el, isOpen) {
			
			//console.log("DO FOCUS");
			
            var focusEl = el /*$('[class*=-focus]', el)*/,
                tabEls = $('.notOverlay,input,select,textarea,button,object,button,a,[tabindex]'), //converting to tabbable element a button input 

                self = this;
            el.removeClass('is-selected');
            //focus the target for accessibility
			
			//console.log("doFocus");
			//console.log(focusEl);
			//console.log(el);
			
			if(focusEl == undefined){
				return false;
			}
			
            if ($(window).width() > 768) {
                if (focusEl.length > 0) {
					console.log("do: focusEl focus");
                    focusEl.attr("tabindex",0).focus();
                } else {
					if (el.length > 0) {
						console.log("do: el focus");
                    el.attr("tabindex",0).focus();
					}
					//focus first children instead?
 					//el.children(":first").attr("tabindex",0).focus();
				}
            }

            //mw check if item only completes when content is complete
			//console.log("doFocus");
            //console.log(el);
            //console.log(el.data('contentComplete'));
            if (el.hasClass("contentCompleteBtn")) {
                //console.log("contentComplete");
				//console.log(el);	
				
                var contentId = $(el.data('revealData'));
				var accordionChild = "[data-toggle]";

                //console.log(contentId);
				
				//console.log(contentId.find(accordionChild).length);
				
				//console.log("contentId");
				//console.log(contentId);

				//buttons, accordion, audio, video, mc submit button
				
				var incompleteCount = contentId.find(self.selector.container).not('.is-visited').length + contentId.find(accordionChild).not('.is-visited').length+contentId.find("audio").not('.optional').not('.is-completed').length+contentId.find("video").not('.is-completed').length+contentId.find("[type='submit']").not(".is-submitted").length;
				
                /*var totalCount = contentId.find(self.selector.container).length + contentId.find(accordionChild).length + contentId.find("audio").length,
                    incompleteCount = contentId.find(self.selector.container).not('.is-visited').length + contentId.find(accordionChild).not('.is-visited').length+contentId.find("audio").not('.is-completed').length+contentId.find("[type='submit']").not(".is-submitted").length,
                    completedCount = contentId.find(self.selector.container + '.is-visited').not('[data-prevent-track]').length + contentId.find(accordionChild + '.is-visited').not('[data-prevent-track]').length + contentId.find('audio.is-completed').not('[data-prevent-track]').length,
                    nonTrackables = contentId.find(self.selector.container + '[data-prevent-track]').length + contentId.find(accordionChild + '[data-prevent-track]').length + contentId.find('audio[data-prevent-track]').length;*/

				/*console.log("check incompleted " + incompleteCount);
                console.log("check completed " + completedCount);
                console.log("check nonTrackables " + nonTrackables);
                console.log("check total " + totalCount);*/

				console.log("incompleteCount "+incompleteCount);
				
                if (incompleteCount == 0 /*|| (completedCount + nonTrackables >= totalCount && nonTrackables > 0 )*/) {
                    el.addClass("is-completed");

                    self.checkLockedBtns();
                }

            };
			
			if(el.hasClass("button--hotspot") && el.parents('.timeline-slide').length){
				//console.log("is hotspot test");
				var timelineSlide = el.closest('.timeline-slide');
				
				var slideId = timelineSlide.attr("id");
				//console.log(slideId);
				//console.log(timelineSlide.find('.button--hotspot').not('.is-visited').length);
				
				if(timelineSlide.find('.button--hotspot').not('.is-visited').length == 0){
				
					$('.contentCompleteBtn[data-reveal-object]').each(function(){
						//console.log($(this).data('revealObject'));
						if($(this).data('revealObject') == "#"+slideId){
							
							$(this).addClass("is-completed");
							self.checkLockedBtns();
						};
					});
				}
			}

        },

        checkLockedBtns: function() {
            $('.is-disabled[data-locked-until]').each(function() {
                console.log("checklocked");
               var checkCompleted = $($(this).data('lockedUntil'));

               var shouldUnlock = false;

               if(checkCompleted.hasClass("contentCompleteBtn")) {
                if(checkCompleted.hasClass("is-completed")){
                    shouldUnlock = true;
                }
               }else{
                    if(checkCompleted.hasClass("is-visited")){
                        shouldUnlock = true;
                    }
               }

               if(shouldUnlock){
                    $(this).removeClass("is-disabled").prop("disabled", false);
               }


            });
        },

        applyAccessibility: function(el, isOpen) {
			//console.log("applayAccessibility "+isOpen);
            var focusEl = $('[class*=-focus]', el),
                tabEls = $('.notOverlay,input,select,textarea,button,object,button,a,[tabindex]'), //converting to tabbable element a button input 

                self = this;
            el.removeClass('is-selected');
            //focus the target for accessibility
            if ($(window).width() > 768) {
                if (focusEl.length > 0) {
                    focusEl.focus();
                } else {
                    //el.focus();
					el.children(":first").attr("tabindex",0).focus();
                }
            }

            //since 1.0 make header and main content not arrow-able 
            if (isOpen) {
                $(".navbar").attr('tabindex', '-1').attr('aria-hidden', 'true');
                $(".main").attr('tabindex', '-1').attr('aria-hidden', 'true');
                $(".footbar").attr('tabindex', '-1').attr('aria-hidden', 'true');
            } else {
                $(".navbar").removeAttr('tabindex').removeAttr('aria-hidden');
                $(".main").removeAttr('tabindex').removeAttr('aria-hidden');
                $(".footbar").removeAttr('tabindex').removeAttr('aria-hidden');
            }

            //Added tabbable elements 
            //restrict tabindex in overlay      
            tabEls.each(function() {
                if (self.type == "overlay" && $(this).is(":visible") && $(this).closest(".overlay,.tip,body[class*=dialog-]").length == 0) {
                    var tabindex = $(this).attr('tabindex');
					//console.log($(this));
					//console.log(tabindex);
                    if (tabindex) {
                        if (isOpen) {
                            if (tabindex == 0) {
                                $(this).attr('tabindex', '-9827').attr('aria-hidden', 'true'); //if a tab index is 0 set it to a random number
                            } else if(tabindex > 0){
                                $(this).attr('tabindex', '-' + tabindex).attr('aria-hidden', 'true');
                            }

                        } else {
                            if (tabindex == "-9827") {
                                $(this).attr('tabindex', '0').removeAttr('aria-hidden');
                            } else if (tabindex == "-7561") {
                                $(this).removeAttr('tabindex').removeAttr('aria-hidden');
                            } else {
                                $(this).attr('tabindex', tabindex.substring(1)).removeAttr('aria-hidden');
                            }

                        }
                    } else {
                        //for a tags / btns etc
                        if (isOpen) {
                            $(this).attr('tabindex', '-7561').attr('aria-hidden', 'true'); //another random number because its easy and i m hungry @sundar
                        }
                    }

                }
            });
        },
        delegateCloseEvent: function() {
            var self = this;
            $('body').on('click', self.selector.close, function(e) {
                e.preventDefault();
                self.hide($($(this).data('revealObject')));
            });



        }
    });
})(window.$ || window.JQuery);

/* 

old example 

2) html structure for type: "tooltip":
popup:
<aside id="pop2" data-reveal-target="tooltip">
     ...
 <a href="#" class="tip-close" tabindex="204" data-reveal-type="pop-close" data-reveal-object="#pop7" >
     <span class="icon-close"></span>
 </a>
</aside>
button:
<button data-reveal-type="tooltip" data-reveal-object="#pop2">...</button>

3) html structure for type: "dialog": (use bootstrap dialog)
popup:
<div class="modal fade" id="popup-dialog" role="dialog" data-backdrop="static" data-keyboard="false" data-reveal-target="pop-dialog">
     <div class="modal-dialog" tabindex="300">
       <div class="modal-content">
         <div class="modal-header">
           <button type="button" class="close" data-dismiss="modal" aria-label="Close" tabindex="302"><span aria-hidden="true">&times;</span></button>
           <h4 class="modal-title"></h4>
         </div>
        <div class="modal-body" tabindex="301"></div>
      </div>
    </div>
</div>
button:  
<button data-reveal-type="dialog" data-reveal-data="#pop2" data-reveal-object="#popup-dialog" data-toggle="modal" data-target="#popup-dialog"></button>
 
 */

(function($) {
    "use strict";
	
	//checkbox manaager
    window.bazingaApp.views.checkboxManager = window.bazingaApp.views.abstractComponentView.extend({
        checkboxes: [],
        cbIdentifier: '[data-cbid]',
        showNeutralFeedback: false,
        autoComplete: false,
		handled:false,
        cbType: 'single',
		minOptions:false,
        trackable: true,
		maxOptions:0,
        partials: {
            type: 'of',
            tgt: null
        },
		selectedWrong:false,
        correct: [],
        totalWeightage: 0,
        state: "not-attempted",
        getState: function() {
            return this.state;
        },
        getIsTrackable: function() {
            return this.trackable;
        },
        initialize: function() {
            _.bindAll(this, 'load', 'randomize', 'loadCheckboxes', 'recalculate', 'show', 'hide');
        },
        selectOrder: [],
        definedOrder: [],
        feedbacks: {
            show: null,
            hide: null
        },
        animations: 'fade',
		
        recalculate: function(e) {
			
			//console.log("recalculate");
			
            if (e && e.target && ($(e.target).hasClass('is-disabled'))) {
                e.stopPropagation();
                return false;
            }	

            var self = this,
                correct = self.correct,
                neutral = self.neutral,
                allCheckboxes = self.$el.find(self.cbIdentifier),
                answers = {
                    "correct": [],
                    "wrong": []
                },
                score = 0,
                score_max = self.totalWeightage,
                allIds = [],
                i = 0,
                fb = 'naf',
				addClass = "",
				courseConfig = window.bazingaApp.models.api.getCourseConfig(),
				accessibilityVersion = _.has(courseConfig,'accessibilityVersion') ? courseConfig['accessibilityVersion'] : 1;
			
			if(self.submitButton){
			self.submitButton.addClass('is-submitted');
			}else{
				return false;
				//no submit button
			}
			
            if (self.resetButton) {
                self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
            }

            if (!self.autoComplete) {
                self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
            }

            allCheckboxes.addClass('is-disabled').off('click');

            if (self.cbType == 'order') {
				
				console.log(self);
				console.log(self.definedOrder);
				
                _.each(self.definedOrder, function(v) {
					
					console.log("v");
					console.log(v);
					
                    var ix = self.selectOrder[i++];
					if(ix != undefined){
                    allIds.push(v.id);
						
						console.log("pushed v.id "+v.id);
						
						console.log("ix "+ix);
					console.log("allIds "+allIds);
					console.log("v "+v);
					console.log("---");
					}

                    if (v.id == ix && ix != undefined) {
						console.log(ix + " correct");
                        answers.correct.push(ix);
                    } else if(ix != undefined){
						console.log(ix + " wrong");
                        answers.wrong.push(ix);
                    }
                });
            } else {
                _.each(allCheckboxes, function(cb) {
                    var $cb = $(cb),
                        id = "" + $cb.data('cbid'),
						assistText = (function(){
                            var assistText = $cb.find(".a11y-assist-text");
                            if(assistText.length > 0){
                                return assistText;     
                            }
                            $cb.append("<div class='a11y-assist-text'></div>")                            
                            assistText = $cb.find(".a11y-assist-text");
                            return assistText; 
                        }()),
                        isCorrect = (_.indexOf(correct, id) > -1),
					
                        isChecked = $cb.hasClass('is-selected'),
                        showIfCorrect = $cb.data('showIfCorrect'),
                        showIfWrong = $cb.data('showIfWrong');

                    allIds.push(id);
                    $cb.addClass(isCorrect ? 'is-correct' : 'is-wrong');
					assistText.text(isCorrect ? 'Correct answer' : 'Incorrect answer'); //Needed for IE 

                    if ((isCorrect && isChecked) || (!isCorrect && !isChecked)) {
                        answers.correct.push(id);
                        if(showIfCorrect){
                            self.show($(showIfCorrect),null,100);
                        }
                        $cb.addClass('is-answered-correct');
                        score += parseInt($(cb).data('weight') || 1);
                    } else {
                        $cb.addClass('is-answered-wrong');
                        if(showIfWrong){
                            self.show($(showIfWrong),null,100);
                        }
                        answers.wrong.push(id);
                    }
					
					if(!isCorrect && isChecked){
						self.selectedWrong = true;
					}
                });
            }

			console.log(answers.correct);
			console.log(answers.wrong);

            var ret = {
                target: self,
                answers: answers,
                allIds: allIds,
                score: score,
                score_max: score_max,
                percentage: ((score / score_max) * 100)
            };


            if (allIds.length == answers.correct.length) {
                ret.state = self.state = "passed";
            } else if(self.selectedWrong){
				
				console.log("selectedWrong");
				
				ret.state = 'failed';
			} else
                //trigger neutral
                if (self.partials.tgt) {
					console.log("*partial");
                    if (self.partials.type == 'of') {
						console.log("*of "+answers.correct.length+"/"+self.partials.tgt[0]);
						console.log(answers);
						//if you selected the same number of correct answers is the same as the number specified in data-partials (includes unselected wrong answers)
                        if (answers.correct.length >= self.partials.tgt[0]) {
                            ret.state = 'partial';
                        } else {
                            ret.state = 'failed';
                        }
                    } else if (self.partials.type == 'in') {
                        var overlap = _.intersection(self.partials.tgt, answers.correct);
						console.log("*in "+overlap.length +"/"+self.partials.tgt.length);
						console.log(overlap);
						console.log(answers.wrong.length);
						//if you selected the same ids specified in data-partials
                        if (!_.isEmpty(overlap) && (overlap.length == self.partials.tgt.length)) {
                            ret.state = 'partial';
                        } else {
                            ret.state = 'failed';
                        }
                    } else {
						console.log("*else "+ret.percentage+"/"+parseInt((self.partials.tgt[0])));
                        if (ret.percentage >= parseInt((self.partials.tgt[0] || 50))) {
                            ret.state = 'partial';
                        } else {
                            ret.state = 'failed';
                        }
                    }
                }else{
					//did not select wrong answer but still wrong
					ret.state = 'failed';
				}
            fb = '[data-caf]';
			
			var selectedCheckbox;
			
            if (self.showNeutralFeedback) {
				console.log("show neutral feedback");
                fb = '[data-naf]';
				
				for(var i = 0;i <allCheckboxes.length; i++){
					console.log(i);
					if($(allCheckboxes[i]).hasClass("is-selected")){
						selectedCheckbox = allCheckboxes[i];	
					}
				}
				
				console.log(allCheckboxes);
				
				console.log(selectedCheckbox);
				
				//look for naf on individual checkbox
				if($(selectedCheckbox).data("feedbackId") != undefined){
				if($(selectedCheckbox).data("feedbackId").length > 0){
					
					//console.log();
					
					fb = '[data-'+$(selectedCheckbox).data("feedbackId")+']';
					var $selectedCheckbox = $(selectedCheckbox);
					var fbClass = $selectedCheckbox.attr('data-add-class') || "";
					//console.log("fb");
					//console.log(fb);
					
					var $fb = $(fb);
					
					if(fbClass != ""){
						//$cb.addClass(fbClass);
						//$fb.addClass(fbClass); //mw needs testing
						$fb.parent().addClass(fbClass);
					}
					//console.log(fb);
				}
				}else{
					console.log("*neutral feedback but feedbackId not defined on the checkbox");
					//look for naf on checkbox container
					$fb = $(self.$el[0].getAttribute('data-feedback-show-selector'));
					
					console.log($fb)
				}
				
            } else {
                if (ret.state == 'passed') {
                    fb = '[data-caf]';
					addClass = $(self.$el[0].getAttribute('data-correct-class')) || "";
                } else if (ret.state == 'failed') {
                    fb = '[data-waf]';
					addClass = $(self.$el[0].getAttribute('data-incorrect-class')) || "";
                } else {
                    fb = '[data-pcaf]';
                }
            }
			
            if (self.feedbacks.show) {
				console.log("showFeedback "+fb);
				//console.log(self);
				self.feedbacks.show = $(self.$el[0].getAttribute('data-feedback-show-selector')); //.dataset.feedbackShowSelector doesn't work in ie9
				//console.log($(self.$el[0].getAttribute('data-feedback-show-selector')));
				//added to target individual feedbacks
				
                self.show(self.feedbacks.show.find(fb, null, 100));

                var showFeedback = function(callback) {
					
					console.log(self.feedbacks);
					console.log(self.feedbacks.show);
                        self.show(self.feedbacks.show, callback);
					
					
					
					var jump = $(self.$el[0].getAttribute('data-jump-to-feedback'));
					//console.log("JUMP");
					//console.log(jump.selector);
					
					var fbId;
					var $fb;
					
					if(self.feedbacks.show[0]){
						console.log(self.feedbacks);
						console.log(self.feedbacks.show[0]);
					fbId = self.feedbacks.show[0].id;
					$fb = $("#"+fbId);
					
					//console.log("add class");
					//console.log(addClass.selector);
					
					if(jump.selector == ""){
						console.log("do jump");
						$('html,body').animate({
        			scrollTop: $fb.offset().top});
					}
					
						if(addClass != ""){
							$fb.addClass(addClass.selector);
						}
					}
                    },
                    hideFeedback = function(callback) {
						//console.log("hideFeedback");
                        if (self.feedbacks.length == 0 || !_.has(self.feedbacks, "hide") || self.feedbacks.hide.length == 0) {
							//console.log("no feedbacks hide");
                            callback();
                        } else {
							//console.log("recalculate hide the feedback");
							//console.log(self.feedbacks.hide);
							self.feedbacks.hide = $(self.$el[0].getAttribute('data-feedback-hide-selector'));
							
                            self.hide(self.feedbacks.hide, callback);
						
							//self.hide(self.$el.context.attributes["data-feedback-hide-Selector"], callback);
							
                        }
                    };


                if (self.animateOrder == 'hideShow') {
					//console.log("animateOrder hideShow");
                    hideFeedback(function() {
                        showFeedback(function() {
                        	var el = self.feedbacks.show,
                        		navBar = $('.navbar');
                            self.trigger("completed:checkbox", ret);
                            //nice to have: scroll to feedback section on mobile view
							if($(window).width()<767&&el.hasClass("js-scrollTop")){
								$("html,body").animate({scrollTop:el.offset().top-navBar.outerHeight()},500,function(){
									if(accessibilityVersion >= 2){
									el.find(fb).find('[tabindex]:first').focus();
									}
								});
							}
							
							//since 1.0 add  even on desktop for accessibility
							if(accessibilityVersion  >= 2){
							el.find(fb).find('[tabindex]:first').focus();
							}
                        });
                    });
                } else {
                    showFeedback(function() {
						
                        hideFeedback(function() {
                            self.trigger("completed:checkbox", ret);
							if(accessibilityVersion  >= 2){
                            self.feedbacks.show.find(fb).find('[tabindex]:first').focus();
							}
                        });
                    });
                }
            } else {
                setTimeout(function() {
                    self.trigger("completed:checkbox", ret)
                }, 20);
                console.log("No feedbacks located. SO event was triggered");
            }

            self.completed = 'completed';
			
        },

        show: function(element, callback, delay) {
            var self = this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 300;


            if (typeof callback !== 'function') {
                callback = function() {}
            }

            switch (classOverride) {
                case "fade":
                case "fadeinout":
                    promise = element.fadeIn(delay, callback);
                    //promise = element.fadeIn(delay, callback).css("display","inline-block");
                    break;

                case "slideUp":
                case "slideUpDown":
                    promise = element.slideUp(delay, callback);
                    break;

                case "slideDown":
                case "slideDownUp":
                    promise = element.slideDown(delay, callback);
                    break;

                default:
                    promise = element.show(delay, callback);
                    break;
            }

            return promise;
        },
        hide: function(element, callback, delay) {
			
			//console.log(element);
			
            var self = this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 600;

            if (typeof callback !== 'function') {
                callback = function() {}
            }

			//console.log("hide "+classOverride+ " "+delay);
			
			//console.log(element);
			//console.log(element.data('animationHide'));

            switch (classOverride) {
                case "fade":
                case "fadeinout":
                    promise = element.fadeOut(delay, callback);
                    break;

                case "slideUp":
                case "slideDownUp":
                    promise = element.slideUp(delay, callback);
                    break;

                /*case "slideDown":
                case "slideUpDown":
                    promise = element.slideDown(delay, callback); //not working?
                    break;*/

                default:
					delay = 0;
                    promise = element.hide(delay, callback);
                    break;
            }

            return promise;
        },
        loadCheckboxes: function(reload) {
			//console.log("loadCheckboxes");
            reload = reload === false ? false : true;

            if (reload) {
                this.checkboxes = [];
            };


            var self = this,
                i = 1,
                checkboxes = this.$el.find(this.cbIdentifier),
                
                
                clickHandler = function(e) {
					//console.log("checkbox clickHandler");
                    if (e && e.target && ($(e.target).hasClass('is-disabled'))) {
                        e.stopPropagation();
                        return false;
                    }
				
                    var tgt = e.target,
                        $target = $(tgt),
                        data,
                        id,
                        totalCheckboxes = self.checkboxes.length,
                        notSelected;

                    data = $target.data();
                    id = data.cbid; 
					
					//show/hides when clicked on the checkboxes themselves

                    if (_.has(data, 'showSelector') && data.showSelector) {
                        self.show($(data.showSelector));
                    }
                    if (_.has(data, 'hideSelector') && data.hideSelector) {
						console.log("hasHIDEslector");
						console.log($(data.hideSelector));
                        self.hide($(data.hideSelector));
                    }


                    if ($target.hasClass('is-selected')) {
                        $target.removeClass('is-selected').attr("aria-checked",false);

                        //set up order
                        if (self.cbType == 'order') {
                            //remove the id from the list if it is not selected

                            var currentIx = _.indexOf(self.selectOrder, id);
                            if (currentIx > -1) {
                                //remove the current select order
                                self.selectOrder = _.reject(self.selectOrder, function(num) {
                                    return (("" + num) == ("" + id));
                                });
                                $target.find('[data-cb-selected-order]').remove();


                                //redo other select orders
                                _.each(self.selectOrder, function(so) {
                                    var soOb = $('[data-cbid="' + so + '"]').find('[data-cb-selected-order]'),
                                        selectedOrder = (soOb.data('cbSelectedOrder'));

                                    selectedOrder = parseInt(selectedOrder);
                                    if (!_.isNaN(selectedOrder) && selectedOrder > currentIx) {
                                        selectedOrder = (selectedOrder - 1);

                                        soOb.data('cbSelectedOrder', ("" + selectedOrder)).html(("" + selectedOrder));

                                    }
                                });
                            }

                        }
                    } else {
                        if (self.cbType == 'single') {
                            self.$el.find(self.cbIdentifier).removeClass('is-selected').attr("aria-checked",false);
                           
                        }
						
						console.log($('.checkbox.is-selected').length+"/"+self.maxOptions+" max");
						
						
						if (self.maxOptions > 0 && ($('.checkbox.is-selected').length == self.maxOptions)) {
                        	//reached limit of options
						}else{
							//selet checkbox
							$target.addClass('is-selected').attr("aria-checked",true);
						}

                        //set up order
                        if (self.cbType == 'order') {
                            if (_.indexOf(self.selectOrder, id) < 0) {
                                self.selectOrder.push(id);
                                $target.find('.icon-checkbox').html('<div class="cb--order" data-cb-selected-order="' + self.selectOrder.length + '">' + self.selectOrder.length + '</div>');
                            }
                        }
                    }

                    if (self.autoComplete) {
                        self.recalculate();
                    } else {
                        notSelected = self.$el.find(self.cbIdentifier).not('.is-selected').length;

                        if (self.cbType == 'order') {
							console.log("ordering checkbox");
							
							var minOptionsReached = false;
							
							if(self.minOptions){
									var numSelected = totalCheckboxes - notSelected;
									if(numSelected >= eval(self.minOptions)){
										minOptionsReached = true;
									}
							}
							
                            if (notSelected == 0 || minOptionsReached) {
                                console.log("all selected");
                                self.submitButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                            } else {
                                self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                            }

                            if (totalCheckboxes == notSelected) {
                                if (self.resetButton) {
                                    self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                                }
                            } else {
                                if (self.resetButton) {
                                    self.resetButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                                }
                            }
                        } else {
							
                            if (totalCheckboxes == notSelected) {
                                //console.log("no checkboxes selected");
                                self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                                if (self.resetButton) {
                                    self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                                }
                            } else {
                                //console.log("some checkboxes selected");
								
								if(self.minOptions){
								   //only enable submit button if enough checkboxes are selected
									var numSelected = totalCheckboxes - notSelected;
									
									var correctAnswersString = self.correct;
									
									//console.log(correctAnswersString); //undfined
									
									if(numSelected != correctAnswersString.length){
										//number selection not matching number of correct answers
										self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
										
										return false;
										
									}
								   
								   }
								
                                self.submitButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
								
                                if (self.resetButton) {
                                    self.resetButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                                }
                            }
                        }

                    }
                };


            self.selectOrder = [];

            if (checkboxes.length == 0) {
                console.error("Unable to load checkboxes. no data-cbids exists");
            }



            _.each(checkboxes, function(cb) {
				
                var $cb = $(cb),
                    id = $cb.data('cbid'),
                    showIfCorrect = $cb.data('showIfCorrect'),
                    showIfWrong = $cb.data('showIfWrong');

                //load the assist text for the checkboxes
                //$cb.find(".a11y-assist-text").html("Not Selected");

                
                if(showIfCorrect){
                    $(showIfCorrect).hide();
                }
                if(showIfWrong){
                    $(showIfWrong).hide();
                }
				
				
                $cb.on("click touchend", function(e) {
					
					/*if($(this).hasClass("is-disabled")){
						return false;
					}*/
					
					//this needs to be tested on office ipad
					self.handled = false;
					
					//console.log(e.type);
					//console.log(self.handled);
					if(e.type == "touchend"){
						e.target = (this);
						clickHandler(e);
						self.handled = true;
						return false;
					}else if(e.type == "click" && !self.handled){
						//console.log("clicked");
						e.target = (this);
						clickHandler(e);
						self.handled = true;
					}
                });
				
                if (reload) {
					if($cb.data('order') != undefined && $cb.is(":visible")){ //only add those with a data-order attribute
						
                    self.definedOrder.push({
                        id: id,
                        order: ($cb.data('order') || i++)
                    });
					}
                    self.checkboxes.push({
                        id: $(cb).data('cbid'),
                        $el: $cb,
                        weight: ($(cb).data('weight') || 1)
                    });

                }
            });

            self.definedOrder = _.sortBy(self.definedOrder, function(o) {
                return o.order;
            });
            self.totalWeightage = (_.reduce(self.checkboxes, function(memo, cb) {
                return cb.weight + memo;
            }, 0));
			
			//console.log("self.totalWeightage "+self.totalWeightage);

        },
        randomize: function() {
            var self = this;

            if (self.checkboxes.length == 0) {
                return false;
            }

            self.$el.empty();
            self.checkboxes = _.shuffle(self.checkboxes);

            _.each(self.checkboxes, function(cb) {
                self.$el.append(cb.$el);
            });

            self.loadCheckboxes(false);
        },
        load: function($el) {
            this.$el = $el;

            var data = this.$el.data(),
                self = this,
                allowPartials = false;

            this.loadCheckboxes();
			
			console.log("loadCheckboxes");

            if (!(_.has(data, 'correct'))) {
                //Always load neutral response feedback
                self.showNeutralFeedback = true;
                console.log("[Checkbox Message] no correct answers. showNeutralFeedback");
            } else {
                self.correct = ((data.correct + "") || "").split(',');
            }
			
			if (_.has(data, 'cbType')) {
				//console.log("has cbtype");
				if($.inArray(data.cbType, ['multiple', 'order']) >= -1){
                self.cbType = data.cbType;
			}
            }else{
				//console.log("no cbtype, get correct length:"+self.correct);
				
				//work out if multiple automatically
				if(self.correct.length > 1){
					//console.log("auto calculate to multiple");
					self.cbType = 'multiple';
				}
			}

            if (!_.has(data, 'submit')) {
                self.autoComplete = true;
                console.log("[Checkbox Message] No submit button mentioned. Checkbox will auto complete");
            } else {
                self.submitButton = $(data.submit);
				if ((_.has(data, 'minOptions') && (data.minOptions != "0")) || !(_.has(data, 'minOptions'))) {
                self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
				}
                self.submitButton.on("click touchend", self.recalculate);
            }

            if (_.has(data, 'reset')) {
                self.resetButton = $(data.reset);
                self.resetButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                self.resetButton.on("click touchend", function(e) {
                    if ($(e.currentTarget).hasClass('is-disabled')) {
                        return false;
                    }

                    self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                    self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);

                    self.selectOrder = [];
                    if (self.cbType == 'order') {
                        $('[data-cb-selected-order]').remove();

                    }

                    self.$el.find(self.cbIdentifier)
                        .removeClass('is-selected')
                        .removeClass('is-correct')
                        .removeClass('is-wrong');
                });

                self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
            }


            self.animateOrder = (_.has(data, 'animateOrder') && data.animateOrder == 'showHide') ? data.animateOrder : "hideShow";

            if (_.has(data, 'partialOn')) {
                allowPartials = (data.partialOn == '1');
            }

            if (_.has(data, 'animations')) {
                self.animations = data.animations;
            }
            if (_.has(data, 'animation')) {
                self.animations = data.animation;
            }
			
			if (_.has(data, 'max')) {
                self.maxOptions = data.max;
            }
			
			//console.log("max "+self.maxOptions);

            if (allowPartials && _.has(data, 'partials') && data.partials) {
                self.partials.type = data.partialType || 'of';
                self.partials.tgt = ("" + (data.partials || "")).split(',');
            }
			
			//console.log("data.randomize");
			//console.log(data.randomize);

            if (_.has(data, 'randomize') && (data.randomize != "0")) {
				//console.log("RANDOM");
                this.randomize();
            }
			
			if (_.has(data, 'minOptions') && (data.minOptions != "0")) {
				this.minOptions = true;
				if(data.minOptions !== ""){
					this.minOptions = data.minOptions;
				}
				//console.log("MINOPTIONS "+this.minOptions);
			}

            if (!_.has(data, 'feedbackShowSelector')) {
                console.log("[CHECKBOXES] NO FEEDBACK SELECTOR IN DATA TAG>. NO FEEDBACKS WILL BE SHOWN BY THE CHECKBOX");
            } else {
                self.feedbacks.show = $(data.feedbackShowSelector);
				
				//console.log("has feedbackShowSelector");
				//console.log(self.feedbacks.show);
				//overrides each other
				
                if (self.feedbacks.show.length == 0) {
                    console.log("[CHECKBOXES] FEEDBACK NOT LOCATED");
                }
				
                self.feedbacks.hide = $(data.feedbackHideSelector);
				//console.log("self.feedbacks.hide");
				//console.log(self.feedbacks.hide);
				//self.feedbacks.hide = self.$el.context.attributes["data-feedback-hide-Selector"];
				
				//console.log("self.feedbacks.hide");
				//console.log(self.$el.context.attributes);
				//console.log("self.$el.context.attributes.data-feedback-hide-selector");
				//console.log(self.$el.context.attributes["data-feedback-hide-Selector"]);

                self.hide(self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]"));
                self.hide(self.feedbacks.show);
                //self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]").hide();
                //self.feedbacks.show.hide();
            }

            if (_.has(data, 'preventTrack') && data.preventTrack) {
                self.trackable = false;
            }

			//console.log(self.feedbacks);

        }
    });

	var submitPressed = false;
	
//checkbox
    window.bazingaApp.views.checkboxView = window.bazingaApp.views.abstractComponentView.extend({
        el: '[data-checkbox]:not(.js-prevent-interaction)',
        cbEl: '.checkbox',
        feedbacks: null,
        allow: {
            randomize: true
        },
        cbList: [],
        events: {
        },
		
        initialize: function() {
            if (this.$el.length == 0) {
                this.enabled = false;
            }

            this.componentType = 'checkboxes';
            var self = this,
                //Recalculate the completion of all child components
                //If all the children are completed , the completed event is triggered and this is tracked by appView
                recalculate = function(e) {
					
					//console.log("init recalculate");
					
					//console.log(self.cbList);
					
                    var todo = 0;
                    _.each(self.trackables, function(v) {
                        if (v.getIsCompleted()) {
                            return false;
                        }

                        todo++;
                    });

                    //console.log("recalculate init todo: "+todo);
                    if (todo == 0) {
                        self.completed = 'completed';
                        //trigger event for appview
                        self.trigger('completed:checkboxes', self, e);
						//return;
                    }
					
					
                };

            this.trackables = [];


            _.each(this.$el, function(el,index) {
                var $el = $(el),
                    cbManager = new window.bazingaApp.views.checkboxManager();
				
				
                //Loop through each of the child components and make sure all the components are loaded 
                cbManager.on("completed:checkbox", function(e) {
					
                    recalculate(e);
                });
                cbManager.load($el);

                //If the child component is trackable then then track it 
                if (cbManager.getIsTrackable()) {
                    self.trackables.push(cbManager);
                }

                self.cbList.push(cbManager);
            });



        },
        setAllow: function(allow) {
            this.allow = _.extend(this.allow, allow);
            return this;
        }

    });
})(window.$ || window.JQuery);

//modified code from checkbox.js really dirty, if want to reuse, need to clean this up first, used in coaching-for-everyone module, 2-2 and 2-3

(function($) {
    "use strict";
    window.bazingaApp.views.surveyManager = window.bazingaApp.views.abstractComponentView.extend({
        checkboxes: [],
        cbIdentifier: '[data-cbid]',
        showNeutralFeedback: true,
        autoComplete: false,
        cbType: 'single',
        val:'1',
        trackable: false,
        partials: {
            type: 'of',
            tgt: null
        },
        correct: [],
        surveyData: [],
        totalWeightage: 0,
        state: "not-attempted",
        getState: function() {
            return this.state;
        },
        getIsTrackable: function() {
            return this.trackable;
        },
        initialize: function() {
            //list of all functions
            _.bindAll(this, 'load', 'randomize', 'loadCheckboxes', 'recalculate', 'show', 'hide','checkSubmitBtn');
        },
        selectOrder: [],
        definedOrder: [],
        feedbacks: {
            show: null,
            hide: null
        },
        animations: 'fade',

        //on submit
        recalculate: function(e) {
            if($(e.target).hasClass("is-disabled")){
                return false;
            }
			
			   $(".surveyCompleteHide").fadeOut(400,
			   function() {
				$(".surveyCompleteShow").fadeIn();
			  });
			
            /*console.log("on");
            console.log(e.target);
            console.log("submit recalculate");*/
			
			   	$(e.target).addClass("is-submitted");
			   
			
            if (e && e.target && ($(e.target).hasClass('is-disabled'))) {
                e.stopPropagation();
                return false;
            }

            var self = this,
                correct = self.correct,
                neutral = self.neutral,
                allCheckboxes = $(".allSurveys:visible").find(self.cbIdentifier),
                answers = {
                    "correct": [],
                    "wrong": []
                },
                score = 0,
                score_max = self.totalWeightage,
                allIds = [],
                i = 0,
                fb = 'naf';
			
			//console.log("allCheckboxes");
			//console.log(allCheckboxes);

            if (self.resetButton) {
                self.resetButton.addClass('is-disabled').attr("aria-disabled", true);
            }

            if (!self.autoComplete) {
                self.submitButton.addClass('is-disabled').attr("aria-disabled", true);
            }

            allCheckboxes.addClass('is-disabled').off('click');
			var surveyIndex = 0;
			
            if (self.cbType == 'order') {
                _.each(self.definedOrder, function(v) {
                    var ix = self.selectOrder[i++];
                    allIds.push(v.id);

                    if (v.id == ix) {

                        answers.correct.push(ix);
                    } else {
                        answers.wrong.push(ix);
                    }
                });
            } else {
                _.each(allCheckboxes, function(cb) {
                    var $cb = $(cb),
                        id = "" + $cb.data('cbid'),
                        val = "" + $cb.data('val'),
                        assistText = (function() {
                            var assistText = $cb.find(".a11y-assist-text");
                            if (assistText.length > 0) {
                                return assistText;
                            }
                            $cb.append("<div class='a11y-assist-text'></div>")
                            assistText = $cb.find(".a11y-assist-text");
                            return assistText;
                        }()),
                        isCorrect = (_.indexOf(correct, id) > -1),
                        isChecked = $cb.hasClass('is-selected'),
                        showIfCorrect = $cb.data('showIfCorrect'),
                        showIfWrong = $cb.data('showIfWrong');

                    allIds.push(id);
                    //$cb.addClass(isCorrect ? 'is-correct' : 'is-wrong');
                    //assistText.text(isCorrect ? 'Correct answer' : 'Incorrect answer'); //Needed for IE 

                    /*if ((isCorrect && isChecked) || (!isCorrect && !isChecked)) {
                        answers.correct.push(id);
                        if (showIfCorrect) {
                            self.show($(showIfCorrect), null, 100);
                        }
                        $cb.addClass('is-answered-correct');
                        score += parseInt($(cb).data('weight') || 1);
                    } else {
                        $cb.addClass('is-answered-wrong');
                        if (showIfWrong) {
                            self.show($(showIfWrong), null, 100);
                        }
                        answers.wrong.push(id);
                    }*/

                    //get the values of all the selected radio buttons and add them to the category
                    if(isChecked){
                    //console.log("val "+val);
                    //console.log("category");
                    surveyIndex = parseInt($(cb).closest(".surveyContainer").data("category"));
                    //console.log("checking "+self.surveyData[surveyIndex]);
                    if (typeof self.surveyData[surveyIndex] == 'undefined' || self.surveyData[surveyIndex] == null) {
                        self.surveyData[surveyIndex] = val+"";
                        //console.log("add to array");
                        //console.log(self.surveyData);
                    }else{
                        self.surveyData[surveyIndex] = parseInt(self.surveyData[surveyIndex]) + parseInt(val)+"";
                    }
 
                    }
                });
            
                /*console.log("category data "+surveyIndex);
                console.log(self.surveyData);*/

                //window.bazingaApp.models.api.setCourseData(self.surveyData.toString());
                //window.bazingaApp.models.api.setPageCompletion('completed'); 

				//show feedback depending on score
				var surveyScore = parseInt(self.surveyData[surveyIndex]);
				
				/*console.log("surveyScore "+surveyScore);
				console.log(self);
				console.log(self.feedbacks);*/
				
				var feedbackContainer;
				var hideSelector;
				
				$('.surveyContainer').each(function(){
					console.log($(this).attr("data-submit") +"/"+ e.target.id);
					if($(this).attr("data-submit") == "#"+e.target.id){
						console.log("match");
						feedbackContainer = $(this).attr("data-feedback-show-selector");
						hideSelector = $(this).attr("data-feedback-hide-selector");
					}
				});
				
				//console.log("feedback container " + feedbackContainer);
				
				$(hideSelector).hide();
				$(feedbackContainer).fadeIn();
				
				//console.log("surveyContainer:visible: "+$(".surveyContainer:visible").length);
				
				var numQuestions = $('.surveyContainer[data-feedback-show-selector='+feedbackContainer+']').length;
				//console.log("surveyScore/numQuestion. "+surveyScore+"/"+numQuestions);
				if(surveyScore >= numQuestions){
					//console.log("correct");
					$(feedbackContainer).find("[data-caf]").show();
				}else{
					//console.log("wrong");
					$(feedbackContainer).find("[data-waf]").show();
				}
				
            }

            var ret = {
                target: self,
                answers: answers,
                name: "ninja",
                allIds: allIds,
                score: score,
                score_max: score_max,
                percentage: ((score / score_max) * 100)
            };

			//console.log("allIds.length: "+allIds.length+". answers.correct.length: "+answers.correct.length);
			
			var surveyScore = parseInt(self.surveyData[0]);
			
			console.log("surveyScore "+surveyScore);
			
            if(surveyScore >= $(".surveyContainer").length){
                ret.state = self.state = "passed";
            } else {
                //trigger neutral
                if (self.partials.tgt) {
                    if (self.partials.type == 'of') {
                        if (answers.correct.length >= self.partials.tgt[0]) {
                            ret.state = 'partial';
                        } else {
                            ret.state = 'failed';
                        }
                    } else if (self.partials.type == 'in') {
                        var overlap = _.intersection(self.partials.tgt, answers.correct);
                        if (!_.isEmpty(overlap) && (overlap.length == self.partials.tgt.length)) {
                            ret.state = 'partial';
                        } else {
                            ret.state = 'failed';
                        }
                    } else {
                        if (ret.percentage >= parseInt((self.partials.tgt[0] || 50))) {
                            ret.state = 'partial';
                        } else {
                            ret.state = 'failed';
                        }
                    }
                } else {
                    ret.state = 'failed';
                }
            }
            fb = '[data-caf]';
            if (self.showNeutralFeedback) {
                fb = '[data-naf]';
            } else {
                if (ret.state == 'passed') {
                    fb = '[data-caf]';
                } else if (ret.state == 'failed') {
                    fb = '[data-waf]';
                } else {
                    fb = '[data-pcaf]';
                }
            }

            if (self.feedbacks.show) {
                self.show(self.feedbacks.show.find(fb, null, 100));

                var showFeedback = function(callback) {
                        self.show(self.feedbacks.show, callback);
                    },
                    hideFeedback = function(callback) {
                        if (self.feedbacks.length == 0 || !_.has(self.feedbacks, "hide") || self.feedbacks.hide.length == 0) {
                            callback();
                        } else {
                            self.hide(self.feedbacks.hide, callback);
                        }
                    };

                if (self.animateOrder == 'hideShow') {

                    hideFeedback(function() {
                        showFeedback(function() {
                            var el = self.feedbacks.show,
                                navBar = $('.navbar');
                            self.trigger("completed:checkbox", ret);
                            //nice to have: scroll to feedback section on mobile view
                            if ($(window).width() < 767 && el.hasClass("js-scrollTop")) {
                                $("html,body").animate({
                                    scrollTop: el.offset().top - navBar.outerHeight()
                                }, 500, function() {
                                    (el.find(fb).find('[tabindex]:first').focus());
                                });
                            }

                            ////@since 1.0 add focus even on desktop for accessibility
                            (el.find(fb).find('[tabindex]:first').focus());

                        });
                    });
                } else {
                    showFeedback(function() {
                        hideFeedback(function() {
                            //self.trigger("completed:survey", ret);
                            (self.feedbacks.show.find(fb).find('[tabindex]:first').focus());
                        });
                    });
                }
            } else {
                setTimeout(function() {
                    self.trigger("completed:survey", ret)
                }, 20);
                console.warn("No feedbacks located. SO event was triggered");
            }
			
			var numCompletedSubmitBtns = 0;
			
			$('.allSurveys').each(function(){
				console.log("*");
					var submitId = $(this).find(".surveyContainer").attr("data-submit");
					if($(submitId).hasClass("is-submitted")){
						numCompletedSubmitBtns = numCompletedSubmitBtns +1;
					}
				});
			console.log( numCompletedSubmitBtns + "/" + $(".allSurveys").length);
			if($(".allSurveys").length == numCompletedSubmitBtns){
				self.trigger("completed:survey", ret);
			}
            self.completed = 'completed';
        },

        show: function(element, callback, delay) {
            var self = this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 300;


            if (typeof callback !== 'function') {
                callback = function() {}
            }

            switch (classOverride) {
                case "fade":
                case "fadeinout":
                    promise = element.fadeIn(delay, callback);
                    //promise = element.fadeIn(delay, callback).css("display","inline-block");
                    break;

                case "slideUp":
                case "slideUpDown":
                    promise = element.slideUp(delay, callback);
                    break;

                case "slideDown":
                case "slideDownUp":
                    promise = element.slideDown(delay, callback);
                    break;

                default:
                    promise = element.show(delay, callback);
                    break;
            }

            return promise;
        },
        hide: function(element, callback, delay) {
            var self = this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 600;

            if (typeof callback !== 'function') {
                callback = function() {}
            }


            switch (classOverride) {
                case "fade":
                case "fadeinout":
                    promise = element.fadeOut(delay, callback);
                    break;

                case "slideUp":
                case "slideDownUp":
                    promise = element.slideUp(delay, callback);
                    break;

                case "slideDown":
                case "slideUpDown":
                    promise = element.slideDown(delay, callback);
                    break;

                default:
                    promise = element.hide(delay, callback);
                    break;
            }

            return promise;
        },

        checkSubmitBtn: function(){
            var self = this;
            var totalNumSurveys = $('.surveyContainer:visible').length;
            var totalNumSurveysFilled = $('.surveyFilled:visible').length;
            //console.log("check submit "+totalNumSurveysFilled + " / "+totalNumSurveys);

            if(totalNumSurveys == totalNumSurveysFilled){
				//console.log("enable submit");
               self.submitButton.removeClass('is-disabled').attr("aria-disabled",false);
            }else{
				//console.log("disable submit");
               self.submitButton.addClass('is-disabled').attr("aria-disabled",true);
            }

        },

        // on checkbox click, enable submit buttton
        loadCheckboxes: function(reload) {
            reload = reload === false ? false : true;

            if (reload) {
                this.checkboxes = [];
            };


            var self = this,
                i = 1,
                checkboxes = this.$el.find(this.cbIdentifier),


                clickHandler = function(e) {
                    if (e && e.target && ($(e.target).hasClass('is-disabled'))) {
                        e.stopPropagation();
                        return false;
                    }

                    var tgt = e.target,
                        $target = $(tgt),
                        data,
                        id,
                        totalCheckboxes = self.checkboxes.length,
                        notSelected;

                    data = $target.data();
                    id = data.cbid;

                    if (_.has(data, 'showSelector') && data.showSelector) {
                        self.show($(data.showSelector));
                    }
                    if (_.has(data, 'hideSelector') && data.hideSelector) {
                        self.hide($(data.hideSelector));
                    }


                    if ($target.hasClass('is-selected')) {
                        $target.removeClass('is-selected').attr("aria-checked", false);



                        //set up order
                        if (self.cbType == 'order') {
                            //remove the id from the list if it is not selected

                            /*var currentIx = _.indexOf(self.selectOrder, id);
                            if (currentIx > -1) {
                                //remove the current select order
                                self.selectOrder = _.reject(self.selectOrder, function(num) {
                                    return (("" + num) == ("" + id));
                                });
                                $target.find('[data-cb-selected-order]').remove();


                                //redo other select orders
                                _.each(self.selectOrder, function(so) {
                                    var soOb = $('[data-cbid="' + so + '"]').find('[data-cb-selected-order]'),
                                        selectedOrder = (soOb.data('cbSelectedOrder'));

                                    selectedOrder = parseInt(selectedOrder);
                                    if (!_.isNaN(selectedOrder) && selectedOrder > currentIx) {
                                        selectedOrder = (selectedOrder - 1);

                                        soOb
                                            .data('cbSelectedOrder', ("" + selectedOrder))
                                            .html(("" + selectedOrder));

                                    }
                                });
                            }*/

                        }
                    } else {
                        if (self.cbType == 'single') {
                            self.$el.find(self.cbIdentifier).removeClass('is-selected').attr("aria-checked", false);
                        }
                        $target.addClass('is-selected').attr("aria-checked", true);


                        //set up order
                        /*if (self.cbType == 'order') {
                            if (_.indexOf(self.selectOrder, id) < 0) {
                                self.selectOrder.push(id);
                                $target.find('.icon-checkbox').html('<div class="cb--order" data-cb-selected-order="' + self.selectOrder.length + '">' + self.selectOrder.length + '</div>');
                            }
                        }*/
                    }

                    if (self.autoComplete) {
                        //self.recalculate();
                    } else {
                        notSelected = self.$el.find(self.cbIdentifier).not('.is-selected').length;
						console.log(self.$el.find(self.cbIdentifier));

                        //console.log("totalCheckboxes: " + totalCheckboxes);
                        //console.log("notSelected: " + notSelected);

                        if (self.cbType == 'order') {
                            /*if (notSelected == 0) {
                                console.log("nothing selected");
                                self.submitButton.removeClass('is-disabled').attr("aria-disabled",false);
                            } else {
                                self.submitButton.addClass('is-disabled').attr("aria-disabled",true);
                            }

                            if (totalCheckboxes == notSelected) {
                                if (self.resetButton) {
                                    self.resetButton.addClass('is-disabled').attr("aria-disabled",true);
                                }
                            } else {
                                if (self.resetButton) {
                                    self.resetButton.removeClass('is-disabled').attr("aria-disabled",false);
                                }
                            }*/
                        } else {
                            if (totalCheckboxes == notSelected) {
                                //no checkboxes selected in the survey that this button was pressed
                                console.log("totalCheckboxes == notSelected, nothing selected");

                                self.$el.removeClass("surveyFilled");
                                //self.submitButton.addClass('is-disabled').attr("aria-disabled",true);

                                /*if (self.resetButton) {
                                    self.resetButton.addClass('is-disabled').attr("aria-disabled",true);
                                }*/
                            } else {
                                //some checkboxes are selected
                                //console.log("some selected");

                                self.$el.addClass("surveyFilled");

                                //self.submitButton.removeClass('is-disabled').attr("aria-disabled",false);

                                /*if (self.resetButton) {
                                    self.resetButton.removeClass('is-disabled').attr("aria-disabled",false);
                                }*/
                            }
                        }

                    }

                    self.checkSubmitBtn();

                };


            self.selectOrder = [];

            if (checkboxes.length == 0) {
                console.error("Unable to load checkboxes. no data-cbids exists");
            }

            _.each(checkboxes, function(cb) {
                var $cb = $(cb),
                    id = $cb.data('cbid'),
                    showIfCorrect = $cb.data('showIfCorrect'),
                    showIfWrong = $cb.data('showIfWrong');

                //load the assist text for the checkboxes
                //$cb.find(".a11y-assist-text").html("Not Selected");


                /*if (showIfCorrect) {
                    $(showIfCorrect).hide();
                }
                if (showIfWrong) {
                    $(showIfWrong).hide();
                }*/

                $cb.on("click", function(e) {
                    e.target = (this);
                    clickHandler(e);
                });

                if (reload) {
                    self.definedOrder.push({
                        id: id,
                        order: ($cb.data('order') || i++)
                    });
                    self.checkboxes.push({
                        id: $(cb).data('cbid'),
                        $el: $cb,
                        weight: ($(cb).data('weight') || 1)
                    });

                }
            });

            self.definedOrder = _.sortBy(self.definedOrder, function(o) {
                return o.order;
            });
            self.totalWeightage = (_.reduce(self.checkboxes, function(memo, cb) {
                return cb.weight + memo;
            }, 0));

        },

        randomize: function() {
            var self = this;

            if (self.checkboxes.length == 0) {
                return false;
            }

            self.$el.empty();
            self.checkboxes = _.shuffle(self.checkboxes);

            _.each(self.checkboxes, function(cb) {
                self.$el.append(cb.$el);
            });

            self.loadCheckboxes(false);
        },

        //edit stuff here
        //initializing function for each survey component on page
        load: function($el) {
            this.$el = $el;

            var data = this.$el.data(),
                self = this,
                allowPartials = false;

            this.loadCheckboxes();

            if (_.has(data, 'cbType') && ['multiple', 'order'].indexOf(data.cbType) >= -1) {
                self.cbType = data.cbType;
            }

            /*if(_.has(data, 'category')){
                self.category = data.category;
                if($.inArray(self.category, self.categories) == -1){
                    //add category to array if doesn't exist
                    self.categories.push(self.category);
                }
            }*/

            console.log(self.categories);

            if (!(_.has(data, 'correct'))) {
                //Always load neutral response feedback
                self.showNeutralFeedback = true;
                console.log("[Checkbox Message] Checkboxes initialized to show neutral feedback always");
            } else {
                self.correct = ((data.correct + "") || "").split(',');
            }

            //submit button
            if (!_.has(data, 'submit')) {
                self.autoComplete = true;
                console.log("[Checkbox Message] No submit button mentioned. Checkbox will auto complete");
            } else {
                self.submitButton = $(data.submit);
                self.submitButton.addClass('is-disabled').attr("aria-disabled", true);
                console.log("submit");
				console.log(self.submitButton);
                self.submitButton.on("click", self.recalculate);
            }

            /*if (_.has(data, 'reset')) {
                self.resetButton = $(data.reset);
                self.resetButton.removeClass('is-disabled').attr("aria-disabled", false);
                self.resetButton.on("click", function(e) {
                    if ($(e.currentTarget).hasClass('is-disabled')) {
                        return false;
                    }

                    self.submitButton.addClass('is-disabled').attr("aria-disabled", true);
                    self.resetButton.addClass('is-disabled').attr("aria-disabled", true);

                    self.selectOrder = [];
                    if (self.cbType == 'order') {
                        $('[data-cb-selected-order]').remove();

                    }

                    self.$el.find(self.cbIdentifier)
                        .removeClass('is-selected')
                        .removeClass('is-correct')
                        .removeClass('is-wrong');
                });

                self.resetButton.addClass('is-disabled').attr("aria-disabled", true);
            }*/


            self.animateOrder = (_.has(data, 'animateOrder') && data.animateOrder == 'showHide') ? data.animateOrder : "hideShow";

            if (_.has(data, 'partialOn')) {
                allowPartials = (data.partialOn == '1');
            }

            if (_.has(data, 'animations')) {
                self.animations = data.animations;
            }
            if (_.has(data, 'animation')) {
                self.animations = data.animation;
            }

            if (allowPartials && _.has(data, 'partials') && data.partials) {
                self.partials.type = data.partialType || 'of';
                self.partials.tgt = ("" + (data.partials || "")).split(',');
            }

            if (_.has(data, 'randomize') && data.randomize) {
                this.randomize();
            }


            if (!_.has(data, 'feedbackShowSelector')) {
                console.warn("[CHECKBOXES] NO FEEDBACK SELECTOR IN DATA TAG>. NO FEEDBACKS WILL BE SHOWN BY THE CHECKBOX");
            } else {
                self.feedbacks.show = $(data.feedbackShowSelector);
                if (self.feedbacks.show.length == 0) {
                    console.warn("[CHECKBOXES] FEEDBACK NOT LOCATED");
                }
                self.feedbacks.hide = $(data.feedbackHideSelector);

                self.hide(self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]"));
                self.hide(self.feedbacks.show);
                //self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]").hide();
                //self.feedbacks.show.hide();
            }

            if (_.has(data, 'preventTrack') && data.preventTrack) {
                self.trackable = false;
            }


        }
    });


    window.bazingaApp.views.surveyView = window.bazingaApp.views.abstractComponentView.extend({
        el: '[data-survey]:not(.js-prevent-interaction)',
        cbEl: '.checkbox',
        feedbacks: null,
        allow: {
            randomize: false
        },
        surveyList: [],
        events: {

        },
        //start - clean up any checkbox stuff
        initialize: function() {
            //console.log("init function SURVEY");
            if (this.$el.length == 0) {
                this.enabled = false;
            }

            this.componentType = 'surveys';
            var self = this,
                recalculate = function(e) {
                    console.log(" init recalculate");
                    var todo = 0;
                    _.each(self.trackables, function(v) {
                        console.log("v");
                        console.log(v);
                        if (v.getIsCompleted()) {
                            console.log("is completed");
                            return false;
                        }

                        todo++;
                    });

                    console.log("todo "+todo);

                    //need to trugger this
                    if (todo == 0) {
                        self.completed = 'completed';
                        //trigger event for appview
                        //console.log(e);

                        self.trigger('completed:surveys', self, e, e.ret);
                    }
                };

            this.trackables = [];


            _.each(this.$el, function(el) {
                var $el = $(el),
                    surveyManager = new window.bazingaApp.views.surveyManager();

                surveyManager.on("completed:survey", function(e) {
                    //console.log("survey manager");
                    recalculate(e);
                });

                surveyManager.load($el);

                if (surveyManager.getIsTrackable()) {
                    self.trackables.push(surveyManager);
                }

                self.surveyList.push(surveyManager);

            });

            //randomize survey questions
			
			//console.log($(".allSurveys").attr("data-randomize"));
			
			if($(".allSurveys").attr("data-randomize")!= undefined){
				//console.log("has randomize");
            var cards = $(".surveyContainer");
			for(var i = 0; i < cards.length; i++){
				var target = Math.floor(Math.random() * cards.length -1) + 1;
				var target2 = Math.floor(Math.random() * cards.length -1) +1;
				cards.eq(target).before(cards.eq(target2));
			}
			}else{
				//console.log("no randomize");
			}

        },
        setAllow: function(allow) {
            this.allow = _.extend(this.allow, allow);
            return this;
        }

    });
})(window.$ || window.JQuery);

(function ($) {
    "use strict";

    /*
     *	display tick for accordion
     * 	
     * 	Mandatory Attributes:
     * 	data-accordion-type="tick" (the address the tick element by backbone, bind view on it)
     * 
     * 	useage:
     * 
     * <a class="row" data-accordion-type="tick">
     *     <span class="col-xs-10">...</span>
     *     <span class="col-xs-2 u-text-right">
     *       <span class="icon-tick"></span> //add class "hidden" in here to set default visibility if necessary
     *     </span>
     * </a>
     *
     */
    window.bazingaApp.views.tickView = window.bazingaApp.views.abstractComponentView.extend({
        el: '[data-accordion-type="tick"]:not(.js-prevent-interaction)',
        events: {
            "click": "show"
        },
        selector: {
        	container: '[data-accordion-type="tick"]'
        },

        initialize: function () {
            _.bindAll(this, 'show','recalculate');
            if(this.$el.length == 0){this.enabled = false;}

            this.componentType='accordionTick';

            $('#accordion').on('shown.bs.collapse',function(obj){
                if($(obj.target).is(':visible') && !$('#accordion').hasClass("noScroll")){
					console.log("scroll to tab");
                    $("html,body").animate({scrollTop:$(obj.target).siblings('.panel-heading').offset().top-$('.navbar').outerHeight()},500,"swing");
                }
            });

            this.recalculate();
        },
        recalculate: function () {
            if(this.getIsCompleted()) return this;

            var self = this,
                completed = self.completed = self.completed || false,
                totalCount = $(self.selector.container).length,
                incompleteCount = $(self.selector.container).not(".is-visited").length;

			//console.log(self);
			//console.log(totalCount);
			//console.log(incompleteCount);
			
            if( incompleteCount == 0){
                self.completed = 'completed';
                self.trigger('completed:tick',self);
				$(self.selector.container).parent().parent().addClass("is-completed");
            }
            else if(incompleteCount !== totalCount){
                self.completed = 'incomplete';
            }

            return self;
        },
        show: function(e) {
        	var target = e.target,
        		self = this,
                $target = $(target).data('accordionType')?$(target):$(target).closest(self.selector.container);
            
            e.preventDefault();
            //selecting the current target
            $(self.selector.container).removeClass('is-selected');
            //complete the target
            $target.addClass('is-selected').addClass('is-visited');
           
//           $('.icon-tick',$target).removeClass('hidden');
           $('.panel-heading .icon-tick',$target).show();
           self.recalculate();
			
			//console.log($target);
			var accordionContainer = $(target).parent().parent();
			//console.log(accordionContainer.find(".panel-heading").not(".is-visited").length);
			
			if(accordionContainer.find(".panel-heading").not(".is-visited").length == 0){
				console.log("an accordion is completed");
				accordionContainer.addClass("is-completed");
			}
			
        }
    });
})(window.$ || window.JQuery);
(function($) {
    "use strict";

    /**
     * todo: convert to a template . So that the preloader gets compiled
     * @type {*}
     */

     //audio
    window.bazingaApp.views.audioView = window.bazingaApp.views.abstractComponentView.extend({
        el: $("audio:not(.js-prevent-interaction)"),

        initialize: function() {
            this.componentType = 'audio';
        },
        load: function() {
            var deferred = $.Deferred(),
                transcript = $(".js-transcript"),
				transcriptText = $(".transcript"),
                self = this,
                type = 'onStart',
                data,
                onComplete = function(mediaObj) {
					console.log("audio onComplete");
					//console.log(self.getIsCompleted());
                    if (!self.getIsCompleted()) {
					
						//console.log("media index: ");
						//console.log(mediaObj);
						//console.log(mediaObj.target.id);
						//console.log(this.$el.data());
						if(mediaObj != undefined){
							$("#"+mediaObj.target.id).addClass("is-completed");
							if($("#"+mediaObj.target.id).closest(".mediaContainer")){
								$("#"+mediaObj.target.id).closest(".mediaContainer").addClass("is-completed");
							}
						}
						
                        deferred.resolve();
						if($("audio").length == $("audio.is-completed").length ){
                        self.completed = "completed";
                        self.trigger('completed:audio', self);
						}
                    }
					
                },
				onStart = function(){
						$(".hideOnAudioStart").hide();
				};
			
			//console.log("ytest");
			//console.log(this.$el);

            if (this.$el.length == 0 || typeof this.$el.mediaelementplayer !== 'function') {
                this.enabled = false;
                setTimeout(function() {
                    deferred.fail();
                }, 200);
            } else {
				
                data = this.$el.data();
                data.features = data.features ? (data.features.split(',')) : ['playpause', 'progress', 'volume'];
                if (data.mediaType) { type = data.mediaType; }

                _.defaults(data, {
                    success: function(media, node, player) {
                        // do something when audio starts
                        // add event listener
						
                        if (type == 'onFinish') {
                            media.addEventListener('ended', onComplete);
                        } else {
                            media.addEventListener('playing', onComplete);
                        }
						
						media.addEventListener('play', onStart);

                    }
                });

                self.player = this.$el.mediaelementplayer(data);
				
				/*if(self.player.attr('data-transcript-btn')){
						transcript = $(self.player.attr('data-transcript-btn'));
					}
				
				console.log("transcriptBtn");
				console.log(transcript);*/

                //since 1.0 optional audio
                if (self.player.hasClass("optional")) {
                    //onComplete(this.index());
					//console.log("is optional audio");
					self.completed = "completed";
                        self.trigger('completed:audio', self);
					
					//if has optional, disable tracking of audio 
					this.enabled = false;
                setTimeout(function() {
                    deferred.fail();
                }, 200);
					
                }

				//console.log("self player");
				//console.log(self.player);
				
                //has image slide show with audio
                if (self.player.data("slideshow") == "1") {
					
					var fadeTime = parseInt(self.player.data("fade-time")) || 400;
					
					console.log("fadeTime "+fadeTime);
					
					//need to target current audio
					
					/*console.log("self.player");
					console.log(self.player);
					console.log(this);
                    console.log(self.player.index());*/
					
					var playerIndex = self.player.index();
					var oniPad = false;
					if(playerIndex <0){
						/*console.log("ipad playerindex: "+playerIndex);
						console.log(self);
						console.log(self.player);*/
						playerIndex = 0; // shows as -1 on ipad	?
						oniPad = true;
					}
					
                    var slideshowInterval = setInterval(
						
                        function() {
						
							var currentTime;
							//console.log("slideshowInterval");
							
							//get current playing audio
							for(var i=0;i<self.player.length;i++){	
								//console.log("check1 "+i);
								
								/*var ipadAudio = document.getElementsByTagName('audio')[self.player.length-1];
								currentTime = ipadAudio.currentTime;
								console.log("ipad currentTime " + i + " "+currentTime);*/

                                var notPaused = !self.player[i].paused;

                                if(oniPad){
                                notPaused = !document.getElementById(self.player[i].id).paused;
                            }
								
						if(notPaused){
							playerIndex = i;
							
							currentTime = self.player[i].currentTime;
							
							
							//console.log("1playing player index: "+i +" "+currentTime);
							
							if(currentTime == undefined || oniPad){
								//ie 8
								currentTime = self.player[i].player.media.currentTime;

                                if(oniPad){
                                currentTime = document.getElementById(self.player[i].id).currentTime;
                            }

								//ipad - wasn't commented out before
								//var ipadAudio = document.getElementsByTagName('audio')[self.player.length-1];
								//currentTime = ipadAudio.currentTime;
								//console.log("ipad currentTime "+currentTime);
							}
						}
					}
							//mw replace with this for ipad
							/*$( "audio" ).each(function( index ) {
  								
							});*/
							
							//console.log("--");
							
							for(var i=0;i<self.player.length;i++){	
								//console.log("check2 "+i + " "+self.player[i].paused);
								if(!self.player[i].paused){
								//var ipadAudio = document.getElementsByTagName('audio')[self.player.length-1];
								//currentTime = ipadAudio.currentTime;
								//console.log("ipad currentTime "+currentTime);
								
							playerIndex = i;
							
							currentTime = self.player[i].currentTime;
							//console.log("2playing player index: "+i +" "+currentTime);
							
							if(currentTime == undefined || oniPad){
								//ie 8
								currentTime = self.player[i].player.media.currentTime;

								//ipad
								//var ipadAudio = document.getElementsByTagName('audio')[self.player.length-1];
								//currentTime = ipadAudio.currentTime;
								//console.log("ipad currentTime "+currentTime);
							}
						}
					}
							
						/*console.log("-----------------");
                    	console.log(self);
                    	console.log(self.player);
                        console.log("index: ");
						console.log(self.player[playerIndex]);
                        console.log("id: "+self.player[playerIndex].id);*/
							
							//if ipad fix
							if(oniPad){
								currentTime = document.getElementById(self.player[playerIndex].id).currentTime;
							}
							
                        //console.log("time:");
                        //console.log(currentTime);
							//console.log(document.getElementById(self.player[playerIndex].id).currentTime);
							//console.log(self.player[playerIndex].paused);

                        //resize slideshow

                        //if($(".imgSlideshow").hasClass("height100")){
                          //  console.log("has class");
                            $(".height100").height($("html").height());
                        //}

                        if (currentTime != 0 && currentTime != undefined) {
                            var imgFound = false;
                            $("div[data-audio='" + self.player[playerIndex].id + "'] .imgSlide").each(function(index) {
                                var time = $(this).data("time");
                                //console.log(playerIndex +" "+currentTime);
								
								if(index == ($("div[data-audio='" + self.player[playerIndex].id + "'] .imgSlide").length -1) ){
									//last one
									
									//console.log("last - " +time+"/"+currentTime);
									
									if(time <= currentTime){
									//console.log("last fade in");
										imgFound = true;
										$(this).fadeIn(fadeTime);
									}else{
										//console.log("last fade out");
										$(this).fadeOut(fadeTime);
									}
								}
								if (time > currentTime) {
                                    //console.log("imgFound "+imgFound);
                                    if (!imgFound) {
                                        imgFound = true;
                                        $(this).prev().fadeIn(fadeTime);
                                        //console.log("prev fade in");
                                    } else {
                                        $(this).prev().fadeOut(fadeTime);
                                       //console.log("prev fade out");
                                    }
                                }
                            });
                        }
							
							
                    }

                        , 500);
                }
				
				//end slideshow interval

                // Transcript Button
                if ($(transcript).length) {
					
					//console.log("transcriptText");
					//console.log(transcriptText);
					
                    transcript.on("click", function(event) {
						//console.log("audio btn pressed");
						
						//console.log($(this));
						
						if($(this).attr('data-transcript')){
							transcriptText = $($(this).attr('data-transcript'));
						}
						
						console.log(transcriptText);
						
						event.stopImmediatePropagation();
                        onComplete(this.index);
                        if ($(this).hasClass("is-enabled")) {
                            $(this).removeClass("is-enabled");
							//transcript.removeClass("is-enabled");
                            //$(".transcript").slideUp();
							transcriptText.slideUp();
                        } else {
                            $(this).addClass("is-enabled");
							//transcript.addClass("is-enabled");
                            //$(".transcript").slideDown();
							transcriptText.slideDown();
                            $(".transcript-focus").attr("tabindex", 0).focus();
                        }
						
						
                    })
                }
				
            }

            $(".flashContainer").mousedown(function() {
                //console.log("flash clicked");
                    window.bazingaApp.models.navigation.setPageCompletion('completed');
                    $('[data-enable-on-complete]').removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
        });

            return deferred.promise();
        },

        play: function() {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.play();
                //console.log("playyyyyyyyyyyyy audio");
            }
        },
        pause: function() {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.player.pause();
            }
        },
        resetSource: function(src) {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.pause();
                player.setSrc(src);
                player.play();
            }
        },
        enable: function() {
            this.$el.show();
            return this;
        },
        disable: function() {
            this.$el.hide();
            return this;
        }

    });

    //video

    window.bazingaApp.views.videoView = window.bazingaApp.views.abstractComponentView.extend({
        el: $("video:not(.js-prevent-interaction)"),
        initialize: function() {
            this.componentType = 'video';
        },
        load: function() {
            var deferred = $.Deferred(),
                transcript = $(".js-transcript"),
				transcriptText = $(".transcript"),
                data,
                self = this,
                type = 'onStart',
                data,
                onComplete = function(mediaObj) {
                    if (!self.getIsCompleted()) {
						
						if(mediaObj != undefined){
							//console.log("id: ");
							//console.log($("#"+mediaObj.target.id));
						$("#"+mediaObj.target.id).addClass("is-completed");
							
							if($("#"+mediaObj.target.id).closest(".mediaContainer")){
								$("#"+mediaObj.target.id).closest(".mediaContainer").addClass("is-completed");
							}
							
						}
						
                        deferred.resolve(); 

                        if($("video").length == $("video.is-completed").length ){
                        self.completed = "completed";
                        self.trigger('completed:video', self);
                        }
                    }
                },onStart = function(){
						$(".hideOnVideoStart").hide();
				};

            if (this.$el.length == 0 || typeof this.$el.mediaelementplayer !== 'function') {
                this.enabled = false;
                setTimeout(function() { deferred.fail(); }, 200);
            } else {
                data = this.$el.data();
                data.features = data.features ? (data.features.split(',')) : ['playpause', 'progress', 'fullscreen'];
                type = data.mediaType || 'onStart';
				
                _.defaults(data, {
                    success: function(media, node, player) {
                        // do something when audio starts
                        // add event listener
                        if (type == 'onFinish') {
                            media.addEventListener('ended', onComplete);

                        } else {
                            media.addEventListener('playing', onComplete);
                        }
						
						media.addEventListener('play', onStart);

                    }
                });
                self.player = this.$el.mediaelementplayer(data);
				
                //console.log(self.player);
                // Transcript Button
                if ($(transcript).length) {
					
					if($(transcript).attr('data-transcript')){
						transcriptText = $($(transcript).attr('data-transcript'));
					}
					
                    transcript.on("click", function(event) {
						//console.log("video btn pressed");
						event.stopImmediatePropagation();
                        onComplete(this.index);
                        if (transcript.hasClass("is-enabled")) {
                            transcript.removeClass("is-enabled");
                            //$(".transcript").slideUp();
							transcriptText.slideUp();
                        } else {
                            transcript.addClass("is-enabled");
                            //$(".transcript").slideDown();
							transcriptText.slideDown();
                        }
						
                    })
                }
            }
			
			if(self.player){
			if (self.player.hasClass("optional")) {
                    //onComplete(this.index());
					//console.log("is optional audio");
					self.completed = "completed";
                        self.trigger('completed:completed', self);
					
					//if has optional, disable tracking of audio 
					this.enabled = false;
                setTimeout(function() {
                    deferred.fail();
                }, 200);
					
                }
			}

            $(".flashContainer").mousedown(function() {
               // console.log("flash clicked");
                    window.bazingaApp.models.navigation.setPageCompletion('completed');
                    $('[data-enable-on-complete]').removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
        });


            return deferred.promise();
        },
        play: function() {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.play();
				
				//console.log("playyyyyyyyyyyyy video");
            }
        },
        pause: function() {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.player.pause();
            }
        },
        resetSource: function(src) {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.pause();
                player.setSrc(src);
                player.play();
            }
        },
        enable: function() {
            this.$el.show();
            return this;
        },
        disable: function() {
            this.$el.hide();
            return this;
        }

    });
})(window.$ || window.JQuery);

(function ($) {
    "use strict";
    window.bazingaApp.views.fillupManager = window.bazingaApp.views.abstractComponentView.extend({
        fillups : [],
        fuIdentifier : '[data-fu-id]',


        showNeutralFeedback : false,
        autoComplete : false,
        fuType : 'single',
        trackable : true,
        partials : {
            type :'of',
            tgt  : null
        },
        correct : [],
        totalWeightage : 0,
        state : "not-attempted",
        getState : function(){return this.state;},
        getIsTrackable : function(){return this.trackable ;},
        initialize : function(){
            _.bindAll(this,'load','randomize','loadfillups','recalculate','show','hide');
        },
        selectOrder : [],
        definedOrder : [],
        feedbacks : {show:null,hide:null},
        animations : 'fade',

        recalculate : function(e){

            if(e && e.currentTarget && ($(e.currentTarget).hasClass('is-disabled'))){
                e.stopPropagation();
                return false;
            }

            $(e.currentTarget).addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);

            var self=this,
                allFillUps = self.fillups,
                answers = {"correct" : [], "wrong" : [],"neutral":[],"partial":[]},
                score= 0,
                score_max = self.totalWeightage,
                allIds=[],
                i= 0,
                fb = 'naf';

			self.submitButton.addClass('is-submitted');

            //console.log("recalculate a");
            //console.log(self.fuType); //when is fillin

            if(self.resetButton){self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);}


            _.each(allFillUps,function(fu){
                var $el = fu.$el,
                    selected = $el.val(),
                    correct,
                    allCorrect=$el.find('[data-correct]'),
                    correctValue=[],
                    id = $el.data('fuId'),
                    intersection;

                $el.addClass('is-disabled').attr('disabled','true').attr("aria-disabled",'true').attr("disabled","true");

                if(allCorrect.length == 0){
                    $el.addClass('is-neutral');
                    answers.neutral.push({id:id,$el:$el});
                    //Always a neutral feedback
                    return true;
                }

                _.each(allCorrect, function(k){
                    correctValue.push($(k).val());
                });

                if(typeof selected == 'string'){selected = [selected];}

                intersection= _.intersection(selected,correctValue);

                if(intersection.length == correctValue.length){
                    //correct
                    answers.correct.push({id:id,$el:$el});
                    $el.addClass('is-correct');
                    score += parseInt( $(fu).data('weight') || 1);
                }
                else if(intersection.length > 0){
                    //partially right
                    answers.partial.push({id:id,$el:$el});
                    $el.addClass('is-partial');
                    score += (parseInt( $(fu).data('weight') || 1))*0.5;
                }
                else{
                    //wrong
                    answers.wrong.push({id:id,$el:$el});
                    $el.addClass('is-wrong');
                }

                allIds.push(id);
            });

            var ret = {
                target:self,
                answers:answers,
                allIds : allIds,
                score:score,
                score_max:score_max,
                percentage : ((score/score_max)*100)
            };


            ret.state="passed";

			//fill in
			if(self.fuType == "fillin"){
				
				console.log("is fill in recalculate");
				
				_.each(allFillUps,function(fu){
						  
					console.log("---");
					//console.log(fu);
						//var textbox = fu.$el[0];
						var fuId = fu.$el[0].attributes["data-fu-id"].nodeValue;
						var correctAnswer = fu.$el[0].dataset.correct;
						var range = fu.$el[0].dataset.range;
					
					var rangeCorrect = true;
					var correctAnswerCorrect = true;
					
						//console.log($(fu).val());
					//console.log("fuId "+fuId);
					//console.log('correct: '+ correctAnswer);
					
					var $element = $("[data-fu-id="+fuId+"]");
					//console.log($element);
					//console.log($element.val());
					
					if(range && range.indexOf(",") >= 0){
						//range answer
						var ranges = range.split(",", 2);
						
						console.log("check range "+$element.val()+" between "+ranges[0]+" & "+ranges[1]);
						
						if($element.val() >= ranges[0] && $element.val() <= ranges[1]){
							//within randge, correct
							console.log("range yes");
						}else{
							rangeCorrect = false;
							console.log("range no");
						}

					}else{
						rangeCorrect = false;
					}
					
					if(correctAnswer.indexOf(",") >= 2){
						//check alternate answers
								var answers = correctAnswer.split(",");
								var altAnswers = answers.splice(0,2);
							
							var matchFound = false;
						
							for (var i=0; i<altAnswers.length;i++){
								console.log("compared input "+$element.val()+" to "+altAnswers[i]);
								if($element.val() == altAnswers[i]){
									//ret.state="passed";
									console.log("matches");
									matchFound = true;
								}else{
									console.log("no match");
								}
							}
						
							if(!matchFound){
									correctAnswerCorrect = false;
							}
						
						}else{
						///1 definite answer
						if($element.val() != correctAnswer){
							correctAnswerCorrect = false;
							console.log("compared "+$element.val()+" to "+correctAnswer+" failed");
						}
					}
					
					if(rangeCorrect == false && correctAnswerCorrect == false){
						ret.state = "failed";
						console.log("both failed");
					}
					
				});
				
				
				
			}else{
				
				//drop down
			
            if(allIds.length == answers.correct.length){
                ret.state = self.state = "passed";
            }
				else{
					//console.log(self.partials);
					//trigger neutral
					if(self.partials.tgt){
						if(self.partials.type == 'of'){
							if(answers.correct.length >= self.partials.tgt[0]){
								ret.state = 'partial';
							}
							else{
								ret.state = 'failed';
							}
						}
						else if(self.partials.type == 'in'){
							
							console.log("in. partials.tgt:");
							console.log(self.partials.tgt);
							
							var correctIds = [];
							
							var arrayLength = answers.correct.length;
							for (var i = 0; i < answers.correct.length; i++) {
								//console.log(i);
								//console.log(answers.correct[i]);
								//console.log(answers.correct[i].id);
								correctIds.push(answers.correct[i].id.toString());
								//Do something
							}
							
							console.log("correctIds:");
							console.log(correctIds);
							
							var overlap = _.intersection(self.partials.tgt,correctIds/*answers.correct*/);
							
							console.log("overlap");
							console.log(overlap);
							
							
							
							console.log(overlap.length +"/" +self.partials.tgt.length);
							
							if(!_.isEmpty(overlap) && (overlap.length == self.partials.tgt.length )){
								ret.state = 'partial';
							}
							else{
								ret.state = 'failed';
							}
						}
						else{
							if(ret.percentage >= parseInt((self.partials.tgt[0] || 50))){
								ret.state = 'partial';
							}
							else{
								ret.state = 'failed';
							}
						}
					}
					else{
						ret.state = 'failed';
					}
				}
			}
			
            fb = '[data-caf]';
            if(self.showNeutralFeedback){
                fb='[data-naf]';
            }
            else {
                if(ret.state=='passed'){
                    fb='[data-caf]';
                }
                else if(ret.state=='failed'){
                    fb='[data-waf]';
                }
                else{
                    fb='[data-pcaf]';
                }
            }
			
			console.log("ret state: "+ret.state );
			
			console.log(fb);

            if(self.feedbacks.show){
				console.log("feedback :");
				
				self.feedbacks.show = $(self.$el[0].getAttribute('data-feedback-show-selector'));
				
				console.log(self.feedbacks);
				
                self.show(self.feedbacks.show.find(fb,null,100));

                var showFeedback = function(callback){
                        self.show(self.feedbacks.show,callback);
                    },
                    hideFeedback = function(callback){

                        //console.log("hideFeedback "+self.feedbacks);
                        //console.log("hideFeedback length "+self.feedbacks.length);

                        if (self.feedbacks.length == 0 || !_.has(self.feedbacks, "hide") || self.feedbacks.hide.length == 0) {
                            //console.log("do not hide feedback");
							callback();
							
                        }
                        else{
							//console.log("hide feedback");
							//console.log(self.feedbacks.hide);
                            
							self.feedbacks.hide = $(self.$el[0].getAttribute('data-feedback-hide-selector'));
							
							self.hide(self.feedbacks.hide,callback);
                        }
                    };


                if(self.animateOrder =='hideShow'){

                    hideFeedback(function(){
                        showFeedback(function(){
                            $(".tip").addClass('hidden');
                            self.trigger("completed:fillup",ret);
                        });
                    });
                }
                else{
                    showFeedback(function(){
                        $(".tip").addClass('hidden');
                        hideFeedback(function(){
                            self.trigger("completed:fillup",ret);
                        });
                    });
                }
				
				/*var el = self.feedbacks.show;
				console.log(self);
				console.log(self.feedbacks);
				console.log(self.feedbacks.show);
				console.log(self.feedbacks.show.selector);*/
				
				setTimeout(function() {
					//console.log("do focus");
					//console.log($(self.feedbacks.show.selector));
				$(self.feedbacks.show.selector).find('[tabindex]:visible:first').focus();
				},1000);
				
            }
            else{
                setTimeout(function(){self.trigger("completed:fillup",ret)},20);
                console.log("No feedbacks located. SO event was triggered");
            }

            console.log(ret);
            self.completed = 'completed';
      },

        show : function(element,callback,delay){
            var self=this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 300;


            if(typeof callback !== 'function'){
                callback =function(){}
            }

            switch (classOverride){
                case "fade":
                case "fadeinout":
                    promise = element.fadeIn(delay,callback);
                    break;

                case "slideUp":
                case "slideUpDown":
                    promise = element.slideUp(delay,callback);
                    break;

                case "slideDown":
                case "slideDownUp":
                    promise = element.slideDown(delay,callback);
                    break;

                default:
                    promise = element.show(delay,callback);
                    break;
            }

            return promise;
        },
        hide : function(element,callback,delay){
            var self=this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 600;

            if(typeof callback !== 'function'){
                callback =function(){}
            }


            switch (classOverride){
                case "fade":
                case "fadeinout":
                    promise = element.fadeOut(delay,callback);
                    break;

                case "slideUp":
                case "slideDownUp":
                    promise = element.slideUp(delay,callback);
                    break;

                case "slideDown":
                case "slideUpDown":
                    promise = element.slideDown(delay,callback);
                    break;

                default:
                    promise = element.hide(delay,callback);
                    break;
            }

            return promise;
        },
        loadfillups : function(reload){
            reload = reload===false ? false : true;
            if(reload){this.fillups = [];};

            var self=this,
                i= 1,
                fillups = this.$el.find(this.fuIdentifier);

            if(fillups.length == 0){
                console.error("Unable to load fillups. no data-fu ids exists");
            }

            _.each(fillups, function (fu) {
                var $fu = $(fu),
                    id = $fu.data('fuId'),
                    type = $fu.data('dropDown') || 'selectpicker';


                if (reload) {
                    self.definedOrder.push({id: id, order: ($fu.data('order') || i++)});
                    self.fillups.push({
                        id: id,
                        $el: $fu,
                        weight: ($fu.data('weight') || 1)
                    });

                    if(type == 'selectpicker'){
                        $fu.selectpicker();
                    }
                }
				
				
            });

            self.definedOrder = _.sortBy(self.definedOrder, function(o){return o.order;});
            self.totalWeightage = (_.reduce(self.fillups,function(memo,fu){return fu.weight+memo;},0));
        },
        randomize: function(){
			console.log("randomise fillup")
            var self=this,
                randomizeOptions  = function($el){
                    if(!$el || $el.length == 0){return false;}


                    _.each($el,function(elem){
                        var $elem = $(elem),
                            options = $elem.find('option');

                        $elem.empty();
                        options = _.shuffle(options);

                        _.each(options,function(op){
                            $elem.append($(op));
                        });
                    });

                    return $el;
                };  

            if(self.fillups.length == 0){return false;}

            _.each(self.fillups,function(fillup){
                var hasOptGroup = fillup.$el.find('optgroup').length;

                if(hasOptGroup){
                    randomizeOptions(fillup.$el.find('optgroup'));
                }
                else{
                    randomizeOptions(fillup.$el);
                }
            });
            self.loadfillups(false);
        },
        load : function($el){
            this.$el = $el;

            var data = this.$el.data(),
                self=this,
                allowPartials = false;

            this.loadfillups();

            //don't know what this is
            if(_.has(data,'fillUpType') && $.inArray(data.fillUpType, ['multiple']) >= -1){
                self.fuType= /*data.fuType*/ data.fillUpType;
            }

            //console.log(data);
            //console.log(self.fuType);
			
            //todo Correct has to be loaded for each fill up

            if(!_.has(data,'submit')){
                console.error("[fillup Message] No submit button mentioned. A submit button is necessary for evaluation.");
            }
            else{
                self.submitButton = $(data.submit);
                self.submitButton.on("click",self.recalculate);
			
				if(_.has(data,'startDisabled')){
					self.submitButton.addClass("is-disabled").attr("aria-disabled",true).attr("disabled",true); 
					
					$(".fillup-select").change(function(){
						var enableSubmit = true;
						//console.log($(this).val());
						var fuId = $(this).data("fuId");
						
						console.log(fuId);
						
						$('.fillup-select[data-fu-id='+fuId+']').each(function(i, obj) {
							console.log(obj);
							console.log($(this).val());
    						if($(this).val() == 0){
								enableSubmit = false;
							}
						});
						
						//console.log("CHECK");
						var submitId = $(this).parents("[data-fillup]").data("submit");
						self.submitButton = $(submitId);
						//console.log(self.submitButton);
						
						if(enableSubmit== true){
							self.submitButton.removeClass("is-disabled").attr("aria-disabled",false).attr("disabled",false); 
						}else{
							self.submitButton.addClass("is-disabled").attr("aria-disabled",true).attr("disabled",true); 
						}
						
				});
					
				}
				
            }
			
            if(_.has(data,'reset')){
                self.resetButton = $(data.reset);
                self.resetButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                self.resetButton.on("click",function(){
                    self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                });
            }


            self.animateOrder = (_.has(data,'animateOrder')  && data.animateOrder == 'showHide') ? data.animateOrder : "hideShow";


            if(_.has(data,'animations')){
                self.animations = data.animations;
            }
            if(_.has(data,'animation')){
                self.animations = data.animation;
            }

            //Partial set up
            if(_.has(data,'partialOn')){
                allowPartials = (data.partialOn == '1');
            }
            if(allowPartials && _.has(data,'partials') && data.partials){
                self.partials.type = data.partialType || 'of';
                self.partials.tgt = (""+(data.partials || "")).split(',');
            }
			
			//console.log("PARTIALS");
			//console.log(allowPartials);
			//console.log(self.partials.tgt);
			
            if(_.has(data,'randomize') ||  _.has(data.randomize !== '0') ){
                this.randomize();
            }

            if(!_.has(data,'feedbackShowSelector')){
                console.log("[fillups] NO FEEDBACK SELECTOR IN DATA TAG>. NO FEEDBACKS WILL BE SHOWN BY THE fillup");
            } else{
                self.feedbacks.show = $(data.feedbackShowSelector);
                if(self.feedbacks.show.length == 0){
                    console.log("[fillups] FEEDBACK NOT LOCATED");
                }
                self.feedbacks.hide = $(data.feedbackHideSelector);
				
                self.hide(self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]"));
                //console.log("self.feedbacks.show.find?");
				//console.log(self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]"));
                self.hide(self.feedbacks.show);
                self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]").hide();
                self.feedbacks.show.hide();
            }

            if(_.has(data,'preventTrack') && data.preventTrack){
                self.trackable = false;
                self.completed = 'completed';
                self.trigger("completed:fillup",self)
            }
        }
    });


    window.bazingaApp.views.fillupView = window.bazingaApp.views.abstractComponentView.extend({
        el: '[data-fillup]:not(.js-prevent-interaction)',
        fuEl : '.fillup',
        feedbacks : null,
        allow : {
            randomize : true
        },
        fuList : [],
        events: {

        },
        initialize: function () {
            if(this.$el.length == 0){this.enabled = false;}

            this.componentType='fillups';
            var self=this,
                recalculate = function(e){
                    var todo  = 0;
                    _.each(self.trackables, function(v){
                        if(v.getIsCompleted()){return false;}
                        todo++;
                    });

                    if(todo ==0){
                        self.completed = 'completed';
                        //trigger event for appview
                        self.trigger(('completed:'+self.componentType) ,self,e);
                    }
                };

            this.trackables = [];


            _.each(this.$el, function(el){
                var $el = $(el),
                    fuManager = new window.bazingaApp.views.fillupManager();

                fuManager.on("completed:fillup",function(e){recalculate(e);});
                fuManager.load($el);

                if(fuManager.getIsTrackable()){self.trackables.push(fuManager);}
                self.fuList.push(fuManager);
            });
			
        },
        setAllow : function ( allow){
            this.allow = _.extend(this.allow,allow);
            return this;
        }

    });
})(window.$ || window.JQuery);
(function($) {
    "use strict";

    window.bazingaApp.views.carouselView = window.bazingaApp.views.abstractComponentView.extend({
        el: '[data-ride="carousel"]:not(.js-prevent-interaction)',
        events: {},
        clickable: true,
        selector: {},
        load: function() {
            var loadedFirstTime = false;
            var self = this,
                getItemIndex = function(item) {
                    self.$items = item.parent().children('.item')
                    return self.$items.index(item)
                },
                isComplete = function($tgt) {
					
					var $tgt = $($tgt);
					
					console.log("iscomplete?");
					console.log($tgt);
					
                    var $active = $tgt.find('.item.active'),
                        ix = getItemIndex($active),
                        focussible;
                    //since 1.0
                    if ($tgt.data('accessible') == true) {
                        //version 1.2.0 +p
                        console.log("Custom module carousel");
						
						
						console.log($active);
						//console.log(ix +" / "+(self.$items.length - 1));
                        //This is an accessible carousel for CUstom modules, only difference is hitting prev/next does a focus on the contentsc
                        if (ix == 0) {
                           //self.$el.find('.prevContainer').css('display','none');
							$tgt.find('.prevContainer').addClass('is-disabled');
							$tgt.find('.prevContainer a').removeAttr('data-slide');
                        } else {
                            //self.$el.find('.prevContainer').css('display','block');
							$tgt.find('.prevContainer').removeClass('is-disabled').prop("disabled", false);
							$tgt.find('.prevContainer a').attr('data-slide','prev');
                        }

						//get num of slides for this carousel
						
						var numSlides = $($tgt).find(".item").length;
						console.log(ix +"/"+numSlides);
						
                        if (ix == numSlides-1) { //(self.$items.length - 1)
                            //complete carousel
							
							$tgt.addClass("is-completed");
							
							
							if($('[data-ride="carousel"]:not(.js-prevent-interaction)').length == $('[data-ride="carousel"]:not(.js-prevent-interaction).is-completed').length){
								//all carousels complete
                            self.completed = "completed";
                            self.trigger('completed:carousel', self);
							}
							//change to class so can edit in css
							//self.$el.find('.nextContainer').css('display','none');
							$tgt.find('.nextContainer').addClass('is-disabled');
							$tgt.find('.nextContainer a').removeAttr('data-slide');
                        } else {
							//self.$el.find('.nextContainer').css('display','block');
							$tgt.find('.nextContainer').removeClass('is-disabled');
							$tgt.find('.nextContainer a').attr('data-slide','next');
                        }

                        focussible = $active.find('.js-carousel-focus');

                        //don't
                        if (loadedFirstTime) {
                            if (focussible.length > 0) {
                                $(focussible[0]).attr("tabindex", 0);
                                focussible[0].focus();
                            }
                        }
                        if (!loadedFirstTime) {
                            loadedFirstTime = true;
                        }
                    } else {
                        //AEC modules
						console.log("AEC carousel");
						
                        if (ix == 0) {
                            self.$el.find('[data-slide="prev"]').hide();
                            self.$el.find('[data-slide="next"]').focus();
                        } else {
                            self.$el.find('[data-slide="prev"]').show();
                        }

                        if (ix == (self.$items.length - 1)) {
                            self.completed = "completed";
                            self.trigger('completed:carousel', self);
                            if (self.isWrap) {
                                self.$el.find('[data-slide="next"]').hide();
                                self.$el.find('[data-slide="prev"]').focus();
                            }
                        } else {
                            if (self.isWrap) {
                                self.$el.find('[data-slide="next"]').show();
                            }
                        }
                    }


                };


            this.componentType = 'carousal';
            if (this.$el.length == 0) {
                this.enabled = false;
                this.completed = 'completed';
            } else {
                this.completed = "incomplete";
            }

            self.isWrap = this.$el.data('wrap');

            _.each(this.$el, function(e) {
                isComplete($(e));
            });



            this.$el.on('slid.bs.carousel', function(obj) {
				
				//console.log($(this).attr("data-interval"));
				
				if($(this).attr("data-interval") == false || $(this).attr("data-interval") == "false"){
					//console.log("scroll because data-interval is"+$(this).attr("data-interval"));
                	$("html,body").animate({scrollTop:$(obj.target).offset().top/*-$('.navbar').outerHeight()*/},500,"swing");
					isComplete(this);
				}
                
            });


            this.recalculate();
        },
        recalculate: function() {}
    });
})(window.$ || window.JQuery);

(function($){
    "use strict";

    window.bazingaApp.models.API = Backbone.Model.extend({
        'load': function(courseConfig){
			if (window.console) {
			console.log("api load start");
			}
            var self=this,
                deferred = $.Deferred();
			//console.log(self.courseConfig);
			//console.log(window.bazingaCourseConfig);
			
			self.courseConfig = window.bazingaCourseConfig;
			
			try{ self.courseConfig = offlineConfig; }
				catch(err) {
					if (window.console) {
					console.log("api. no offlineConfig");
					}
				}

            window.bazingaApp.models.scorm12 = self.scorm12 = new  window.bazingaApp.models.scormDataModel();
            self.scormAPI =  window.bazingaApp.models.scorm12.get('API');

            window.bazingaApp.models.data= this.data = new window.bazingaApp.models.dataModel();
            this.data.setAPI(self.scormAPI);
            self.trigger("initialize:dataModel",self);

            this.data
                .fetch()
                .always(function(dataModelContext){
				
                    if(window.bazingaApp.models.data.getLessonStatus()){
                        //Lets start the course
                        window.bazingaApp.models.data.setLessonStatus('incomplete');
                    }
				
				function getCookie(cname) {
					var name = cname + "=";
					var ca = document.cookie.split(';');
					for(var i = 0; i < ca.length; i++) {
						var c = ca[i];
						while (c.charAt(0) == ' ') {
							c = c.substring(1);
						}
						if (c.indexOf(name) == 0) {
							return c.substring(name.length, c.length);
						}
					}
					return "";
				}
				
                    // initialize
				if(getCookie("finishLoad") == "yes"){
                    self.scormAPI.LMSCommit("");
				}
					
                    self.trigger(" ",self);
                    //load the navigation/
                    window.bazingaApp.models.navigation = self.navigation = new window.bazingaApp.models.navigationModel();
					//console.log("load navigation");

                    window.bazingaApp.models.navigation.once('initialize:handshake', function () {
						//console.log("initialize:handshake1");
                        self.trigger('initialize:handshake',self);
						//console.log("initialize:handshake2");
                    });
                    window.bazingaApp.models.navigation.once('initialize:suspendData', function () {
						//console.log("initialize:suspendData");
                        self.trigger('initialize:suspendData',self);
                    });
                    window.bazingaApp.models.navigation.once('initialize:page', function () {
                        self.trigger('initialize:page',self);
                    });
				
					/*if(offlineNav != undefined){
							self.courseConfig = offlineConfig;
					}*/
				
				try{ self.courseConfig = offlineConfig; }
				catch(err) {
					if (window.console) {
					console.log("api2. no offlineconfig")
					}
				}
				
					//console.log(self.courseConfig);
					var navContent = self.courseConfig.navigation.src;
				
				//console.log("navContent is"); console.log(navContent);
				
                    window.bazingaApp.models.navigation
                        .setDataModel(dataModelContext)
                        .setCourseConfig(courseConfig)
                        .load(navContent)
                        .always(function(navModelContext){
                            self.trigger("initialize:navigation",self);
                            //initializing nav api
                            deferred.resolve(self);
                        });
				
				//console.log("TESTTTTTTTTTTTT");
				//console.log(courseConfig);
				//console.log(self.courseConfig);
				
                });
			//console.log("api load finish");
            return deferred.promise();
        },
		
		//apis
		
		//course api ------------------------------------------------
		getCourseCompletion : function(){return window.bazingaApp.models.navigation.getCourseCompletion();},
        setCourseStatus :  function(status){return window.bazingaApp.models.navigation.setCourseStatus(status);},
		setCourseScore :  function(score){return window.bazingaApp.models.navigation.setCourseScore(score);},
		setLessonLocation : function(id){window.bazingaApp.models.navigation.setCurrentScreen(id);
			return window.bazingaApp.models.data.setLessonLocation(id);},
		getLessonLocation : function(){return window.bazingaApp.models.data.getLessonLocation();},
		getOfflineId : function(){return window.bazingaApp.models.navigation.getOfflineId();},
		//gets the title from the config and removes symbols and spaces so it's a string that can be added to suspend data
		setOfflineId : function(oi){return window.bazingaApp.models.navigation.setOfflineId(oi);}, 
 
		//course scoring api------------------------------------------------
        setSecondaryScore : function(score){return window.bazingaApp.models.navigation.setSecondaryScore(score);},
        getSecondaryScore : function(score){return window.bazingaApp.models.navigation.getSecondaryScore();},
        setTertiaryScore : function(score){return window.bazingaApp.models.navigation.setTertiaryScore(score);},
        getTertiaryScore : function(score){return window.bazingaApp.models.navigation.getTertiaryScore();},
        setCourseData : function(data){return window.bazingaApp.models.navigation.setCourseData(data);},
        getCourseData : function(){return window.bazingaApp.models.navigation.getCourseData();},
        setCurrentPool : function(poolId){return window.bazingaApp.models.navigation.setCurrentPool(poolId);},
        getCurrentPool : function(){return window.bazingaApp.models.navigation.getCurrentPool();},
        getCourseConfig : function(){return this.courseConfig;}, //gets course config data from config.json eg: var.last_updated
		
		//page api ------------------------------------------------
        setPageScore :  function(score,id){return window.bazingaApp.models.navigation.setPageScore(score,id);},
        getPageScore :  function(optionalId){return window.bazingaApp.models.navigation.getPageScore(optionalId);},
        setPageCompletion : function(completion,optionalId){window.bazingaApp.models.navigation.setPageCompletion(completion,optionalId); return self;},
		getPageCompletion : function(id){return window.bazingaApp.models.navigation.getPageCompletion(id);}, //returns eg: c or undefined
        reattemptScreen : function(optionalScreen,role){return window.bazingaApp.models.navigation.reattemptScreen(optionalScreen,role);}, //trigger reset on pages specified in the nav
        
        setPageData : function(data,optionalId){window.bazingaApp.models.navigation.setPageData(data,optionalId); return self;},
        getPageData : function(id){return window.bazingaApp.models.navigation.getPageData(id);},
		
        getNavForScreen :function(optionalId){return window.bazingaApp.models.navigation.getNavForScreen(optionalId);}, //gets info from nav.js can get resource/track completion,data,title and visibility og breadcrumbs/menu etc
		
        getPageCount : function(optionalId){return window.bazingaApp.models.navigation.getPageCount(optionalId);},
		
        getLockables : function(){return window.bazingaApp.models.navigation.getLockables();},
		getProgress : function(){return window.bazingaApp.models.navigation.getProgress();},
        getAllPages : function(){return window.bazingaApp.models.navigation.getAllPages();},
		getAllTrackablePages : function(){return window.bazingaApp.models.navigation.getAllTrackablePages();}, //gets an array of all pages with completion: true, use .length to get total number
		
		getAllTopicPages : function(optionalGroupId){return window.bazingaApp.models.navigation.getAllTopicPages(optionalGroupId);}, 
		//gets an array of all pages from the group/topic or group that current page belongs to if no id specified
		getAllTopicPagesNum : function(optionalGroupId){return window.bazingaApp.models.navigation.getAllTopicPagesNum(optionalGroupId);}, //gets length of  getAllTopicPages
		getAllCompletedTopicPagesNum : function(optionalGroupId){return window.bazingaApp.models.navigation.getAllCompletedTopicPagesNum(optionalGroupId);},
        
        getPreviousScreen : function(){return window.bazingaApp.models.navigation.getPreviousScreen();}, //get the last screen you were on
        getDecision : function(decisionPoint,role,id){return window.bazingaApp.models.navigation.getDecision(decisionPoint,role,id);}, 
		//gets next or back pages and any custom int/string you want stored for a page
        
        getSuspendData : function(){return window.bazingaApp.models.navigation.getSuspendData();}, //can access pages' data with var.[11] <- page id
        setPrimaryScore : function(score){return window.bazingaApp.models.navigation.setPrimaryScore(score);},
        getPrimaryScore : function(score){return window.bazingaApp.models.navigation.getPrimaryScore();},
		
		//resetModule: function(){return window.bazingaApp.models.navigation.resetModule();}, //resets all progress
		
		//custom parameters
		setParam : function(ix,param){return window.bazingaApp.models.navigation.setParam(ix,param);},
        getParam : function(ix){return window.bazingaApp.models.navigation.getParam(ix);},
        setParam1 : function(param){return window.bazingaApp.models.navigation.setParam1(param);},
        getParam1: function(){return window.bazingaApp.models.navigation.getParam1();},
        setParam2 : function(param){return window.bazingaApp.models.navigation.setParam2(param);},
        getParam2 : function(){return window.bazingaApp.models.navigation.getParam2();},
        setParam3 : function(param){return window.bazingaApp.models.navigation.setParam3(param);},
        getParam3 : function(){return window.bazingaApp.models.navigation.getParam3();},
        setParam4 : function(param){return window.bazingaApp.models.navigation.setParam4(param);},
        getParam4 : function(){return window.bazingaApp.models.navigation.getParam4();},
		setLang : function(lang){return window.bazingaApp.models.navigation.setLang(lang);},
        getLang : function(){return window.bazingaApp.models.navigation.getLang();},
        setQuizAttempts : function(qa){return window.bazingaApp.models.navigation.setQuizAttempts(qa);},
        getQuizAttempts : function(){return window.bazingaApp.models.navigation.getQuizAttempts();},
		setPageInfo : function(key,value){window.bazingaApp.models.navigation.setInfo(key,value); /*return self;*/}, //make a custom param
		getInfo : function(key){return window.bazingaApp.models.navigation.getInfo(key);},
		
		//optional. depends if lms supports it
		setComments : function(comment){return window.bazingaApp.models.navigation.setComments(comment);}, 
		//non mandatory field in lms. another 4,096 character string like suspend data
		getComments : function(){return window.bazingaApp.models.navigation.getComments();},
		setInteractionStudentResponse: function(num,data){return window.bazingaApp.models.navigation.setInteractionStudentResponse(num,data);},
		setInteractionId: function(num,id){return window.bazingaApp.models.navigation.setInteractionId(num,id);},
		setSpeed : function(speed){return window.bazingaApp.models.navigation.setSpeed(speed);},
		
        getData : function(){return this.data;}, // gets course info eg: var._previousAttributes.role
		
		//not sure of usefullness
		getScorm12DataModel : function(){return this.scorm12;},
        getScormAPI : function(){return this.scormAPI;}, //eg. var.attributes["cmi.suspend_data"]); cmi.core.lesson_location not working for some reason though
        getIsDialog : function(){return window.bazingaApp.models.navigation.getIsDialog();}, //returns true/false if page is dialog or not
        getRole : function(){return window.bazingaApp.models.navigation.getRole();}, //roles not implemented
		setCourseScoreFrom :  function(score){return window.bazingaApp.models.navigation.setCourseScoreFrom(score);}, 
		//if multiple scores, can put,'secondary' or 'tertiary'. default is 'primary'.
        getNavigation : function(){return this.navigation;}, //not sure, returns lots of things including a bunch of api functions
		getCrumbs : function(){return window.bazingaApp.models.navigation.getCrumbs();}, 
		//if dialog returns it's title, if page does return all pages from this group and other things
        getNav : function(){return window.bazingaApp.models.navigation.getNav();}, //return all the groups and the ids of it's children
		getNavForDialog :function(id){return window.bazingaApp.models.navigation.getNavForDialog(id);},
		//put id of dialog like dcom, gets nav info from the config
        getNavForScreenByRole :function(role,id){return window.bazingaApp.models.navigation.getNavForScreenByRole(role,id);},
		getPageDataForPage : function(){return window.bazingaApp.models.navigation.getPageDataForPage();}, //not needed, use getNavForScreen. gets all info about page from config. eg: .attributes.parent
		getConfigForScreen :function(){return window.bazingaApp.models.navigation.getConfigForScreen();}, //not needed, use getNavForScreen. shorter method than getPageDataForPage, eg: var.completion
		setMultiple :  function(values){return window.bazingaApp.models.navigation.setMultiple(values);}, //see no use for this when making modules, used in the framework though
		
		//use getCookie sparingly, most useful for detecting when data is done saving to the lms by changing the cookie 'finishSaving' from it's default of 'yes'
		getCookie :function(cname){ 
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for(var i = 0; i < ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0) == ' ') {
					c = c.substring(1);
				}
				if (c.indexOf(name) == 0) {
					return c.substring(name.length, c.length);
				}
			}
			return "";
		},
		
		//write only
		//getStudentResponse: function(id,data){return window.bazingaApp.models.navigation.getStudentResponse(id);},

        shutDown : function(){
            var self=this;
            window.bazingaApp.models.scorm12.switchTimers();

            window.bazingaApp.models.data.commit("");
            window.bazingaApp.models.scorm12
                .finishSCO()
                .always(function(){
                    //Navigate to exit page
					if(self.courseConfig.finishPage != undefined){
                    window.location.replace(self.courseConfig.finishPage);
					}
					//close parent for popup
				
				/*console.log("close parent for popup");
				
				setTimeout(function() {
					window.opener = top;
					window.opener.close();
    			}, 2000);*/
				
                });
        }

    });

})(window.$||window.JQuery);
(function() {
        window.bazingaApp.views.launcherView = Backbone.View.extend({
                el: $('#js-app'),
                events: {},
                /**
                 * Load the application
                 */
                load: function() {
					
					//console.log("framework launcher load");
					
					function get_browser() {
                                var ua = navigator.userAgent,
                                    tem, M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
                                if (/trident/i.test(M[1])) {
                                    tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                                    return { name: 'IE', version: (tem[1] || '') };
                                }
                                if (M[1] === 'Chrome') {
                                    tem = ua.match(/\bOPR\/(\d+)/)
                                    if (tem != null) {
                                        return { name: 'Opera', version: tem[1] };
                                    }
                                }
                                M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
                                if ((tem = ua.match(/version\/(\d+)/i)) != null) { M.splice(1, 1, tem[1]); }
                                return {
                                    name: M[0],
                                    version: M[1]
                                };
                            }
					
					var browser = get_browser();
					
					//console.log(browser);
					
					 // IE9 console fix
					if(Number(browser.version) == 9){
						if(!window.console) {
							if (!window.console) window.console = {};
								if (!window.console.log) window.console.log = function () { };
						}
					}
				
					if (window.console) {
                    console.log("start launcherView");
					}
					
                    //self.backstretch = new window.bazingaApp.views.backstretchView();
                    self.preloader = new window.bazingaApp.views.preloaderView();
                    self.preloader.setLabel('Loading..').setPercentage(0);
                    self.popup = null;

					if (window.console) {
                    console.log(location.protocol + "//" + location.host);
					}
					 
					//get course config
                    $.getJSON("../config/config.json", function(courseConfig) {
							
                            courseConfig = _.defaults(courseConfig, {
                                "launchPage": "pages/splash.html",
                                "popup": false,
								"offline":false,
                                "popupWidth":"1012",
                                "popupHeight":"688",
								"offlineId":""
                            });
                            self.courseConfig = courseConfig;
						
						//offline id
						var offlineId = self.courseConfig.title.replace(/[^\w\s]|_/g, "");
						offlineId = offlineId.split(' ').join('');
						window.localStorage.setItem("offlineId", offlineId );
						console.log("set offlineId: "+offlineId);
						
                            }).error(function(){
						
												try {
							console.log("offline. use courseconfig.js");
												courseConfig = offlineConfig;
						}
						catch(err) {
							console.log("courseconfig.js DOES NOT EXIST (or no js reference in html)");
						}
						  
						
					}).complete(function(){
						
							if (window.console) {
                            console.log("Launcher loading");
                            console.log("Settting local storage");
							}
							
                            //check if ie7 or less
                            
                            var oldBrowser = false;

                            if (browser.name == "MSIE" && Number(browser.version) < 8) {
                                oldBrowser = true;
                            }

                            if (self.courseConfig.popup) {
                                self.preloader
                                    .incrementTo(100, 10)
                                    .always(function() {
                                            var props = "width="+self.courseConfig.popupWidth+",height="+self.courseConfig.popupHeight+",resizable=no,status=no,toolbar=no,menubar=no,location=no",
                                                check;

                                            self.popup = window.open(self.courseConfig.launchPage, "", props);


                                            check = function() {
                                                setTimeout(function() {
                                                        if (self.popup && !self.popup.closed) {
                                                            check();
                                                        } else {
                                                            if (!oldBrowser) {
                                                                
                                                                    //window.location.replace(courseConfig.finishPage || 'finish.html'); //jumps to complete even if popup blocked
                                                                }
                                                            }
                                                        } ,
                                                        1000);
                                                };

												window.localStorage.setItem("firstLaunch", true);
                                                //if (window.focus) { self.popup.focus() } //breaks on ie9?
                                                check();
                                            });
                                    }
                                else {
                                    if (!oldBrowser) {
                                        console.log("compatible browser - firstLaunch");
                                        window.location.replace((courseConfig.launchPage || 'splash.html'));
                                        window.localStorage.setItem("firstLaunch", true);
                                    }
                                }
							console.log("complete");
					});
					
					
					
                    }
                });
        }());

(function() {
    window.bazingaApp.views.appView = Backbone.View.extend({
        el: $('#js-app'),
        events: {
            "click [data-decision]": "gotoDecisionPoint",
            "click [data-goto]": "gotoDecisionById",
            "click [data-trigger]": "triggerData",
            "click [data-reattempt]": "reattempt",

            "touchend [data-decision]": "gotoDecisionPoint",
            "touchend [data-goto]": "gotoDecisionById",
            "touchend [data-trigger]": "triggerData",
            "touchend [data-reattempt]": "reattempt",
            "keydown": "keydown"
        },
        menu: {
            $el: $('#js-dropdown'),
            tabIndex: 4
        },

        initializeEvents: function($el) {
            var self = this;
            $el.find('[data-decision]').off("click touchend").on("click touchend", self.gotoDecisionPoint);
            $el.find('[data-goto]').off("click touchend").on("click touchend", self.gotoDecisionById);
            $el.find('[data-trigger]').off("click touchend").on("click touchend", self.triggerData);
        },

        reloadParentEvents: function() {
            //hack. this had to happen because the popup triggers were switching events off
            $('[data-goto]').on("click touchend", self.gotoDecisionById);
            $('[data-decision]').on("click touchend", self.gotoDecisionPoint);
            $('[data-trigger]').on("click touchend", self.triggerData);
        },
        /**
         * List of all interactions on screen
         * When there are interactions like checkboxes, they are automatically recognized.
         * Unless a force_screen_on_complete is true, you have to complete all interactions on screen before the screen completes
         */
        interactions: [],
        initialize: function() {
            var self = this;

            _.bindAll(this, 'goNext', 'gotoDecisionPoint', 'gotoDecisionById', 'triggerData', 'goto',
                'goBack', 'getBreadCrumbs', 'initializePageComponents', 'populateMenu', 'initializeAccessibility',
                'initializeMenu', 'onReSize', 'onLoad', 'onPageLoad', 'setTargets', 'initializeEvents', 'reloadParentEvents', 'keydown');


            this.on("completed:page", function(e) {
                //console.log("data-enable-on-complete " + $('[data-enable-on-complete]').length);
                
				
				var checkSaved = setInterval(function(){
					//console.log(window.bazingaApp.models.api.getPageCompletion());
				if(window.bazingaApp.models.api.getPageCompletion() == "c"){
                $('[data-enable-on-complete]').removeClass('is-disabled').attr("aria-disabled", false).attr("disabled",false);
						clearInterval(checkSaved);
				}
					}, 400);
				
            });
			
            this.initializePageComponents();
            this.initializeChild();

            /*$(window).on('beforeunload', function() {
                console.log("f:onbeforeunload");
                //self.exitcourse(); // mw why is this here? on page load, course exits sometimes
                });*/

            //Do not have a initialize function within your application.
            //Use Initialize child instead
        },


        /**
         * This function needs to be called for the screen to start initializing. THis allows all initializations to run before the init is called.
		 
         * Load the application
         */
        load: function() {
			
			//ie9 console not open hack
			if (!window.console) window.console = {};
			if (!window.console.log) window.console.log = function () { };
			
			if (window.console) {
            console.log("start loading application view");
			}
			
			//non commit cookie
			document.cookie = "finishLoad=no";
			
			var self = this;
            //self.backstretch = new window.bazingaApp.views.backstretchView();
            window.bazingaApp.preloader = self.preloader = new window.bazingaApp.views.preloaderView();

            window.bazingaApp.models.api = self.api = new window.bazingaApp.models.API();
			//console.log("set to 0");
            self.preloader.setLabel('Loading').setPercentage(0);
			
			console.log(window.bazingaApp.models.api.courseConfig);
			//console.log(window.bazingaApp.models.api.cid);
			//console.log(self.bazingaCourseConfig.navigation.src);
			
			//console.log(self);
			//console.log(self.cid);
			//console.log(self.keys("courseConfig"));
			
            $.getJSON("../config/config.json", function(courseConfig) {
				
                //course config is now set up
				window.bazingaCourseConfig = self.courseConfig = courseConfig;
				console.log("JSON");
				console.log(courseConfig);
					
            }).error(function(courseConfig){
				
				if(offlineConfig != undefined){
					console.log("no json. use offlineConfig");
				window.bazingaCourseConfig = offlineConfig;
				self.courseConfig = offlineConfig;
				courseConfig = offlineConfig;
					console.log(courseConfig);
				}else{
					console.log("error: no offlineConfig");
				}
					
			}).complete(function(courseConfig){
				
				//console.log(window.bazingaCourseConfig);
				
				//console.log("complete-");
				//console.log(courseConfig);
				
                window.bazingaApp.models.api.once('initialize:dataModel', function() {
					//console.log("datamodel done. go to 10-----------------------------");
                    self.preloader.incrementTo(10);
                });
                window.bazingaApp.models.api.once('initialize:api', function() {
					//console.log("api done. go to 20-----------------------------------");
                    //doesn't actually trigger
					self.preloader.incrementTo(20);
                });
                window.bazingaApp.models.api.once('initialize:handshake', function() {
					//console.log("handshake done. go to 30------------------------------");
                    self.preloader.incrementTo(30);
                });
                window.bazingaApp.models.api.once('initialize:suspendData', function() {
                    self.preloader.incrementTo(40);
                });
                window.bazingaApp.models.api.once('initialize:page', function() {
                    self.preloader.incrementTo(50);
                });

                //The api loads the following
                //courseConfig
                //Nav file
                //Set up bread crumbs
                //Populates and renders menu
                //initializeAccessibility
                //Calls loaded

                window.bazingaApp.models.api
                    .load(courseConfig)
                    .always(self.onLoad);
					
					var courseConfig = window.bazingaApp.models.api.getCourseConfig();
			var debug = _.has(courseConfig,'debug') ? courseConfig['debug'] : true;
				
				//console.log(courseConfig);
			
			//console.log("DEBUG :"+debug);

			if(!debug){
    if(!window.console) window.console = {};
    var methods = ["log", "debug", "warn", "info"];
    for(var i=0;i<methods.length;i++){
    	console[methods[i]] = function(){};
    }
}

//console.log("test start");
				
			});
        },

        onLoad: function() {
			//console.log("-on loadd");
            var self = this;

            self.pageConfig = (window.bazingaApp.models.api.getNavForScreen());

             if (self.pageConfig) {
                self.pageId = self.pageConfig.id;
                if (self.pageConfig.visibility) {
                    if (self.pageConfig.visibility.breadcrumbs) {
                        self.breadCrumbs = window.bazingaApp.models.api.getCrumbs();
                        self.$el.find('[data-bread-crumb]').html(self.getBreadCrumbs());
                    } else {
                        self.$el.find('[data-bread-crumb]').hide();
                    }
                    self.nav = window.bazingaApp.models.api.getNav();
                    self.menuData = self.populateMenu(self.nav);
					//console.log("self.menudata");
					//console.log(self.nav);
					
                    if (self.pageConfig.visibility && (!_.has(self.pageConfig.visibility, 'blockMenuRender') || self.pageConfig.visibility.blockMenuRender == false)) {
                        self.renderMenu();
                       	//console.log("rendermenu");
                    }
                }

            }

			//console.log("-beforePageLoad");
			self.beforePageLoad();
			
			$(".courseTitle").html(window.bazingaApp.models.api.getCourseConfig().title);

			//console.log("-beforeAbstractLoad");
            self.beforeAbstractLoad();
			
			//console.log("-go to 100");
            self.preloader.incrementTo(100);
			
			document.cookie = "finishLoad=yes";
			
            self.initializeAccessibility();

            self.setTargets();
            self.onPageLoad();
            self.abstractLoads();
            self.loaded();

           	//manually save offline suspend data
			
			var offlineSuspend = "cmi.suspend_data."+window.bazingaApp.models.navigation.getOfflineId();
			//console.log("offline suspend "+offlineSuspend);
			
			if(window.localStorage.getItem(offlineSuspend) === null){
				
				//console.log("no offlineId in local storage.save now.");
				var oriSuspend = window.localStorage.getItem("cmi.suspend_data");
				window.localStorage.setItem(offlineSuspend,oriSuspend);
				//console.log(window.localStorage.getItem(offlineSuspend));
			}
			
			//console.log("force update suspend data~~~~~~~"); //only for non-dialog pages
			if(!window.bazingaApp.models.navigation.getIsDialog()){
				window.bazingaApp.models.navigation.updateSuspendData();
			}
            
        },


        keydown: function(e) {
            var self = this,
                $tgt,
                prevent = (function() {
                    if (e.ctrlKey || !self.pageConfig || !_.has(self.pageConfig, 'blockers') || !_.has(self.pageConfig.blockers, 'keys')) {
                        return false;
                    }
                    if (_.indexOf(self.pageConfig.blockers.keys, ('' + e.which)) < 0) {
                        return false; }
                    //Do nothing
                    return true;
                })();

            if (prevent) {
                e.preventDefault();
                return false;
            }

            //Accessibility
            if (e.ctrlKey && (e.which === 39)) {
                self.goNext();
            }
            if (e.ctrlKey && (e.which === 37)) {
                self.goBack();
            }

            // accessibility
            $tgt = $(e.target);
            if ($tgt.hasClass('js-skip-link')) {
                if (e.which === 32 || e.which === 13) {
                    //since 1.0 fixed by Ali for pages with multiple skip targets
                    $(".js-skip-focus:visible:first").focus();
                }
            }


        },
        abstractLoads: function() {
            //Override this in abstract views
        },

        setTargets: function() {
            var suspendData = (window.bazingaApp.models.api.getSuspendData()),
                hashed = {
                    'completion': _('completion').getKeyHash(),
                    'completed': _('completed').getKeyHash(),
                    'passed': _('passed').getKeyHash(),
                    'incomplete': _('incomplete').getKeyHash()
                },
                lockables;

            if ($('[data-completion-target]').length !== 0) {
                $('[data-completion-target]').each(function() {

                    var $el = $(this),
                        data = $el.data('completionTarget'),
                        split,
                        completed = true,
                        isIncomplete = false;

                    if (!data) {
                        return true;
                    }
                    split = ("" + data).split(",");
                    if (split.length == 0) {
                        return true;
                    }


                    _.each(split, function(tgt) {
                        var sus = _.where(suspendData, { id: tgt });
                        //The completion loop failed before
                        if (!completed) {
                            return false; }

                        if (sus.length == 0) {
                            completed = false;
                            return false;
                        }
                        sus = _.first(sus);

                        if (!_.has(sus, hashed.completion) || !sus[hashed.completion] || ($.inArray(sus[hashed.completion], [hashed.completed, hashed.passed]) == -1)) {

                            completed = false;
                            return false;
                        }

                        completed = true;
                        return true;
                    });

                    if (completed) {
                        $el.addClass('is-completed');
                    } else {
                        $el.removeClass('is-completed');
                    }
                });

            }

			//add disabled class if pages are locked
            if ($('[data-locked-if]').length > 0) {
                lockables = (window.bazingaApp.models.api.getLockables());
                $('[data-locked-if]').each(function() {
                    var $el = $(this),
                        data = $el.data('lockedIf');

                    if (_.has(lockables, data) && lockables[data].locked == true) {
                        $el.addClass('is-disabled').prop("disabled", true);
                    } else {
                        $el.removeClass('is-disabled').prop("disabled", false);
                    }
                });
            }


            if ($('[data-available-pool]').length > 0) {
                var currentPool = ((window.bazingaApp.models.api.getCurrentPool()) + "");

                $('[data-available-pool]').each(function() {
                    var $el = $(this),
                        data = $el.data('availablePool'),
                        dataSplit;

                    dataSplit = (data && data != '') ? (data + "").split(',') : [];

                    if (dataSplit.length == 0) {
                        return true; }

                    console.log("IX " + _.indexOf(dataSplit, currentPool));
                    if (_.indexOf(dataSplit, "*") >= 0 || _.indexOf(dataSplit, currentPool) >= 0) {
                        //$el.show();
                        $el.fadeIn();
                    } else {
                        $el.hide();
						if($el.hasClass("removeExtra")){
							$el.remove();
						}
                    }
                });
            }

        },
        beforePageLoad: function() {

        },
        beforeAbstractLoad: function() {

        },

        onPageLoad: function() {
            var gesture = $(".gesture"),
                count,
                mobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

            if (gesture.length > 0) {
                _.each(gesture, function(g) {
                    var $g = $(g);

                    if ($g.text() === "Click" && mobileDevice == true) {
                        $g.text("Tap");
                    } else if ($g.text() === "click" && mobileDevice == true) {
                        $g.text("tap");
                    }else if ($g.text() === "Clicking" && mobileDevice == true) {
                        $g.text("Tapping");
                    }else if ($g.text() === "clicking" && mobileDevice == true) {
                        $g.text("tapping");
                    }
                });
            }



            //If you override this function. make sure to call the super parent. Or you can just override the loaded function
            var self = this,
                previousCompletion = 'na',
                pageCount = window.bazingaApp.models.api.getPageCount(),
                hashed = {
                    completed: _('completed').getKeyHash(),
                    passed: _('passed').getKeyHash()
                },
                preventAutoComplete = !self.pageConfig || !self.pageConfig.track || _.has(self.pageConfig.track, 'manual_completion') || self.pageConfig.track.manual_completion;

            if (self.pageConfig && self.pageConfig.type !== 'page') {
                return this;
            }

            if (_.has(self.pageConfig, 'conditions') && _.has(self.pageConfig['conditions'], 'countIf')) {
                var handleCountFunctions = function(cnt) {
                        cnt = cnt || {};

                        if (_.has(cnt, 'onlyIf')) {
                            if (_.has(cnt.onlyIf, 'courseStatusCheck')) {
                                var courseCompletion = window.bazingaApp.models.api.getCourseCompletion();
                                if (cnt.onlyIf.courseStatusCheck.indexOf(courseCompletion) == -1) {
                                    //Fail return
                                    return;
                                }
                            }
                        }

                        if (cnt.show) {
                            $(cnt.show).fadeIn();
                        }
                        if (cnt.hide) {
                            $(cnt.hide).hide();
                        }

                        var score = 0,
                            status = "failed",
                            committable = [];



                        //Commit the score and status if the page has conditions
                        if (cnt.commitScore) {
                            var value = cnt.commitScore.value || "primary",
                                multiplier = cnt.commitScore.multiplier || 1;

                            switch (value) {
                                case 'primary':
                                    score = window.bazingaApp.models.api.getPrimaryScore() || 0;
                                    break;
                                case 'secondary':
                                    score = window.bazingaApp.models.api.getSecondaryScore() || 0;
                                    break;
                                case 'tertiary':
                                    score = window.bazingaApp.models.api.getTertiaryScore() || 0;
                                    break;
                                default:
                                    score = _.isNumber(cnt.commitScore) ? cnt.commitScore : 0;
                                    break;
                            }

                            committable.push({ key: 'score', value: (score * multiplier) });
                        }

                        if (cnt.commitStatus) {
                            var statusCondition = cnt.commitStatus,
                                masteryScore = statusCondition.masteryScore || 100,
                                type = statusCondition.type || "passed-failed";

                            if (type == "passed-failed") {
                                if (score <= masteryScore) {
                                    status = "failed";
                                } else {
                                    status = "passed";
                                }
                            } else {
                                if (score <= masteryScore) {
                                    status = "incomplete";
                                } else {
                                    status = "completed";
                                }
                            }

                            committable.push({ key: 'status', value: status });
                        }


                        if (committable.length !== 0) {
                            window.bazingaApp.models.api.setMultiple(committable);
                        }
                    }
                    //handle count based variables
                _.each(self.pageConfig['conditions']['countIf'], function(cnt) {
                    if (!cnt.condition || cnt.count === undefined) {
                        return true; }

                    var condition = cnt.condition || "=";

                    switch (condition) {
                        case "<":
                            if (pageCount < cnt.count) { handleCountFunctions(cnt); }
                            break;
                        case ">":
                            if (pageCount > cnt.count) { handleCountFunctions(cnt); }
                            break;
                        case "<=":
                            if (pageCount <= cnt.count) { handleCountFunctions(cnt); }
                            break;
                        case ">=":
                            if (pageCount >= cnt.count) { handleCountFunctions(cnt); }
                            break;
                        case "=":
                        default:
                            if (pageCount == cnt.count) { handleCountFunctions(cnt); }
                            break;
                    }
                });

            }
            previousCompletion = window.bazingaApp.models.api.getPageCompletion();

            previousCompletion = previousCompletion || 'na';

            //disable any thing that needs to be disabled on enter
            //since 1.0
            $('[data-disable-on-enter]').addClass('is-disabled').attr("aria-disabled", true).attr("disabled",true);
            //one time trigger
            if ($.inArray(previousCompletion, [hashed.completed, hashed.passed]) > -1 && !preventAutoComplete) {

                //No calculations necessary
                //page is already completed
                console.log("page is already complete");
				self.hideShowOnComplete();
                self.trigger("completed:page", self, { target: self });
                return this;
            }

            if (self.interactions.length == 0 && !preventAutoComplete) {
                console.info("No more interactions. Page completed . \\o//");
                window.bazingaApp.models.navigation.setPageCompletion('completed');
				self.hideShowOnComplete();
                self.trigger("completed:page", self, { target: self });
                return this;
            }



        },
        /**
         * @private : Do not change
         * @param menu
         * @returns {*}
         */
        setMenu: function(menu) {
            this.menu = menu;
            return this;
        },
        /**
         * Initialize all page components on screen
         */
        initializePageComponents: function() {
            //popup view
            var self = this,
                completionCheck = function(tgt, e) {
					console.log("completionCheck");
                    var tgtType = ((typeof tgt.getComponentType == 'function') ? tgt.getComponentType() : null);

                    tgt.off(null, completionCheck);
                    //for who ever wants to listen
                    self.trigger('completed:component', self, { target: tgt, source: e, tgtType: tgtType });
                    self.completionCheck(self, { target: tgt, source: e, tgtType: tgtType });

                    //Send page completion
                    if (tgt.getIsCompleted()) {
                        self.checkPageCompletion();
                    }

                    //trigger call to set the interactions here
                    if (typeof tgt.isInteractionType == 'function' && tgt.isInteractionType()) {
                        //call the api to set up interaction. THis will set up the id of the component and mark the interaction as complete
                        var interactionData = tgt.getInteractionData();

                        //todo : finish this off
                    }
                };

			//console.log("check to add interactions");

            //=======Audios===============
            self.audio = new window.bazingaApp.views.audioView();
            self.audio.load();

            if (self.audio.isEnabled()) {
                self.audio.on('completed:audio', completionCheck);
                this.interactions.push(self.audio);
				console.log("has audio");
				//this.interactions.push(self.audio);
            }

            //=======Videos===============
            self.video = new window.bazingaApp.views.videoView();
            self.video.load();

            if (self.video.isEnabled()) {
                this.interactions.push(self.video);
                self.video.on('completed:video', completionCheck);
                console.log(self.video.isEnabled() + " - video");
            }

            //=======Popups===============
            self.popup = new window.bazingaApp.views.popupView();
			//console.log("popuppp");
			//console.log(self.popup); //all popup buttons
            if (self.popup.isEnabled()) {
				//if(!self.popup.attr('data-prevent-track')){
				
				if(!self.popup.getIsCompleted()){
                this.interactions.push(self.popup);
				}
				
				//console.log("has popups");
				
				//}
                self.popup.on('completed:reveal', completionCheck);
                self.popup.on('data:popup', function(context, options) {
                    //if (!options) {
                      //  return false };
                    self.initializeEvents(options.$tgt);
                });
            }

            //=======Checkboxes===============
            self.checkboxes = new window.bazingaApp.views.checkboxView();
            if (self.checkboxes.isEnabled()) {
				console.log("has checkboxes");
                self.checkboxes.on('completed:checkboxes', completionCheck);
                this.interactions.push(self.checkboxes);
            }
			
			//=======Surveys===============
            self.surveys = new window.bazingaApp.views.surveyView();
            if (self.surveys.isEnabled()) {
				console.log("has surveys");
                self.surveys.on('completed:surveys', completionCheck);
                this.interactions.push(self.surveys);
            }

            //=======FILLUPS===============
            self.fillups = new window.bazingaApp.views.fillupView();
            if (self.fillups.isEnabled()) {
				console.log("has fillups");
                self.fillups.on('completed:fillups', completionCheck);
                this.interactions.push(self.fillups);
            }


            //=======??s===============
            self.tick = new window.bazingaApp.views.tickView();
			
			//console.log(self);
			//console.log(self.tick);
			
            if (self.tick.isEnabled()) {
				console.log("has tick");
                self.tick.on('completed:tick', completionCheck);
                this.interactions.push(self.tick);
            }

            //=======Carousel===============
            self.carousel = new window.bazingaApp.views.carouselView();
            self.carousel.load();

            if (self.carousel.isEnabled()) {
				console.log("has carousel");
                this.interactions.push(self.carousel);
                self.carousel.on('completed:carousel', completionCheck);
            }

            //=======Checkpoint===============
            /*self.checkpoint = new window.bazingaApp.views.checkPointView();

            if (self.checkpoint.isEnabled()) {
				console.log("has checkpoint");
                this.interactions.push(self.checkpoint);
                self.checkpoint.on('completed:checkpoint', completionCheck);
            }*/

			//console.log("num interactions "+this.interactions.length);

            self.initializeChildComponents();


            //Hide any pool specific elements by default
            $('[data-available-pool]').hide();
        },

        /**
         * Checks to see if the page is completed.
         * Page is completed when all components in screen are completed
         * @returns {*}
         */
        checkPageCompletion: function() {
            console.log("check page completion. interactions: "+this.interactions.length);
			
			/*if($(".pageBlock").length){
				//console.log("multi-page page");
				var currentPageBlock = $( ".pageBlock:visible" );
				var newCurrentPageBlock = currentPageBlock.next();
				newCurrentPageBlock.show();
				
				var currentPageNum = newCurrentPageBlock.attr("data-pageNum");
				
				$('html,body').animate({
        			scrollTop: $("[data-pageNum="+currentPageNum +"]").offset().top},
        		'slow');
				
				window.bazingaApp.models.navigation.setParam4(currentPageNum);
				
			}*/
			
            //Checking page completion
            if (this.interactions.length == 0) {
                return true;
            }

            var self = this,
                completed = true,
                previousCompletion = window.bazingaApp.models.api.getPageCompletion(),
                hashed = {
                    completed: _('completed').getKeyHash(),
                    passed: _('passed').getKeyHash()
                };

            previousCompletion = previousCompletion || 'na';

            if ($.inArray(previousCompletion, [hashed.completed, hashed.passed]) > -1) {
                console.log("already completed before");
                self.hideShowOnComplete();
				self.whenPageCompletes();
                //No calculations necessary
                return this;
            }

            _.each(self.interactions, function(iteraction) {
                if (typeof iteraction.getIsCompleted !== 'function') {
                    //todo
                    console.error("FIX YOUR CODE! Something broke. get is completed doesn't exist in the component");
                }

                if (!iteraction.getIsCompleted()) {
					//console.log(iteraction);
					//console.log("an interaction is not completed");
                    completed = false;
                    return false;
                }
            });

            preventAutoComplete = !self.pageConfig || !self.pageConfig.track || _.has(self.pageConfig.track, 'manual_completion') || self.pageConfig.track.manual_completion;

            if (completed && !preventAutoComplete) {
                self.hideShowOnComplete();
                console.info("Page completed . \o/");
                window.bazingaApp.models.navigation.setPageCompletion('completed');
                self.trigger("completed:page", self, { target: self });
				
				self.whenPageCompletes();
            } else {
                window.bazingaApp.models.api.setPageCompletion('incomplete');
            }

            return this;
        },

        hideShowOnComplete: function() {
            if ($(".pageCompleteHide")[0]) {
                $(".pageCompleteHide").fadeOut(400,
                    function() {
                        $(".pageCompleteShow").fadeIn();
                    });
            } else {
                $(".pageCompleteShow").fadeIn();
            }
        },

        /**
         * can override
         */
        initializeAccessibility: function() {
            var self = this;
            //check the keydown function to add any keydown / class specific accessibility stuff
        },

        /**
         * Set up resize of the menu
         */
        initializeMenu: function() {
            // Menu Dropdown - done using screen height
            var self = this;
            $(window).on("resize", this.onReSize);
            self.onReSize();
        },

        //don't override this
        populateMenu: function(nav) {
            if (!this.menu || this.menu.$el.length == 0) {
                return false;
            }
            var self = this,
                menu = [],
                allPages = window.bazingaApp.models.api.getAllPages(),
                currentPool = window.bazingaApp.models.api.getCurrentPool();


            _.each(nav, function(v, k) {
                var m = (_.first(_.where(allPages, { id: k })));
                if (m && m.visibility && m.visibility.menu) {
                    if (!currentPool) {
                        menu.push(m);
                    } else {
                        if (!m.track || !m.track.pool || ((m.track.pool + "") === (currentPool + ""))) {
                            menu.push(m);
                        }
                    }
                }
            });


            return menu;
        },

        goNext: function() {
            var next = (window.bazingaApp.models.api.getDecision('next'));
            nextData = (window.bazingaApp.models.api.getNavForScreen(next || window.bazingaCourseConfig.defaultHome || 'home'));

            if (!nextData) {
                console.error("Next location not located");
            }

            window.location.replace(nextData.resource);
        },
        goBack: function() {
            var back = (window.bazingaApp.models.api.getDecision('back'));
            backData = (window.bazingaApp.models.api.getNavForScreen(back || window.bazingaCourseConfig.defaultHome || 'home'));

            if (!backData) {
                console.error("back location not located");
            }

            window.location.replace(backData.resource);
        },

        exitcourse: function() {
            (window.bazingaApp.models.api.shutDown())
            return this;
        },

        goto: function(decision) {
            var self = this,
                decisionData;

            if (!decision) {
                return false;
            }
			
			console.log("goto. decision:");
				console.log(decision);
			
            decisionData = (window.bazingaApp.models.api.getNavForScreen(decision || window.bazingaCourseConfig.defaultHome || 'home'));
			
				//console.log("goto. decisionData:");
				//console.log(decisionData);

            if (!decisionData || !decisionData.resource) {
				
				console.log("doesn't work");
				
                decisionData = (window.bazingaApp.models.api.getNavForDialog(decision));
				
				if(decision == "currentScreen"){
					//used on dialog resources
				decisionData = window.bazingaApp.models.api.getNavForScreen(window.bazingaApp.models.navigation.get('previousScreen'));
					
				console.log(decisionData);
			}
				
                if (!decisionData || !decisionData.resource) {
                    return false;
                }
            }

            window.location.replace(decisionData.resource);
            return self;
        },
        triggerData: function(e) {
            var self = this,
                $target = $(e.currentTarget),
                decision = $target.data('trigger');

            if (!decision) {
                return false;
            }


            if (typeof self[decision] == 'function') {
                //self[decision].apply(self, $target.data()); 
				//changed to 'call'. reason: http://stackoverflow.com/questions/5988326/uncaught-typeerror-function-prototype-apply-arguments-list-has-wrong-type
				
				self[decision].call(self, $target.data());
				
            }

        },
        gotoDecisionById: function(e) {
            var $target = $(e.currentTarget),
                decision = $target.data('goto'),
                decisionData;


            if ($target.hasClass('is-disabled')) {
                return false;
            }


            if (!decision) {
                return false;
            }
            return this.goto(decision);
        },
        gotoDecisionPoint: function(e) {
            var $target = $(e.currentTarget),
                decision = $target.data('decision'),
                decision = (window.bazingaApp.models.api.getDecision(decision)),
                decisionData;
				
				console.log("gotoDecisionPoint "+decision);
				
            if ($target.hasClass('is-disabled')) {
                return false;
            }
            return this.goto(decision);
        },


        //=====================================================================================
        //=========================END PRIVATE FUNCTIONS====================
        //=====================================================================================

		//overrides
		
        /**
         * Anything below here can be overrided in child pages
         *
         */
        onReSize: function() {
            var windowHeight = $(window).height(),
                menuHeight = windowHeight - 115;

            // console.log("ON RESIZE height being reset on menu");
            //$(".navbar-navigation").css("height", menuHeight);
        },

        loaded: function() {
            //override this on your page view
            console.log("loaded");
        },
        render: function() {

        },
        completionCheck: function(context, options) {
            //Override this for checking which component gets completed
        },
        initializeChild: function() {
            //override this
        },
        initializeChildComponents: function() {
            //override this
        },
        whenPageCompletes: function() {
            //override this
        },

        /**
         * This will return AEC type bread crumbs (Topic Name Page 1 of 6)
         * @returns {string}
         */
            getBreadCrumbs: function() {
            //Override this function to make your own breadcrumbs
            var self = this,
                crumbs = self.breadCrumbs,
                first,
                listItems = null,
                crumbString = '',
                ix;


            if (!crumbs) {
                return "";
            }


            if (crumbs.length == 0) {
                return "<strong>" + self.pageConfig.title + "</strong>";
            }

            first = (_.first(crumbs));

            if (!first) {
                return "";
            }

            listItems = (_.filter(first.items, function(it) {
                return it.visibility && it.visibility.breadcrumbs;
            }));


            ix = (_.findIndex(listItems, function(it) {
                return "" + it.id == "" + self.pageId;
            }));

            var topicName = first.title ? (first.title + " -") : "";

            if (ix == -1) {
                return "<strong>" + topicName + "</strong>";
            }

            crumbString = "<strong>" + topicName + "</strong> <span class='page'> Page </span>" + (ix + 1) + " <span class='of'>of</span> " + listItems.length;
            return crumbString;
        },
        reattempt: function(e) {
			console.log("reattempt");
            var target = e.currentTarget,
                $target = $(target),
                self = this,
                promise;

            if ($target.data('reattempt') == 'current') {
                promise = window.bazingaApp.models.api.reattemptScreen();
                if (promise) {
                    promise.always(function() {
                        if ($target.data('reattemptThenGoto')) {
                            self.goto($target.data('reattemptThenGoto'));
                        }
                    });
                }
            }
        },
		getLanguage:function(){
			
			//console.log("get language from ");
			//console.log(bazingaCourseConfig);
			//use the default language in course config if getLang is not defined
			if (typeof bazingaCourseConfig.language != "undefined" && window.bazingaApp.models.api.getLang() == "null") {
				console.log("not undefined. it's "+bazingaCourseConfig.language);
				langExt = bazingaCourseConfig.language;
				window.bazingaApp.models.api.setLang(bazingaCourseConfig.language);
			}
			
			if(window.bazingaApp.models.api.getLang() == "en" || window.bazingaApp.models.api.getLang() == "null"){
									langExt = "";
							}
		},
        /**
         * render the menu / you can override this
         * @returns {*}
         */
        renderMenu: function() {
		
            var self = this,
                menu = self.menuData,
                allHtml = "",
                listIt,
                hashed = {
                    "completion": _('completion').getKeyHash(),
                    "completed": _('completed').getKeyHash(),
                    "passed": _('passed').getKeyHash()
                },
                //since 1.0
                courseConfig = window.bazingaApp.models.api.getCourseConfig(),
				langExt = window.bazingaApp.models.api.getLang(),
                accessibilityVersion = (_.has(courseConfig, 'accessibilityVersion') ? courseConfig['accessibilityVersion'] : 1),
                suspendData = window.bazingaApp.models.api.getSuspendData(),
                lockables = (window.bazingaApp.models.api.getLockables()),
				
                renderSubMenu = function(items) {
					//console.log("renderSubMenu items");
					//console.log(lockables);
					//console.log(items);
                    var html = "",
                        listItems = (_.filter(items, function(it) {
                            return it && it.visibility && it.visibility.menu;
                        }));
					//console.log(listItems);

                    if (listItems.length == 0) {
                        return false;
                    }
					
					self.getLanguage();
					
					//console.log("render menu suspend data");
					//console.log(suspendData);

                    _.each(listItems, function(v, k) {

                        //console.log(listItems); //only items in groups
						
						/*console.log(v);
						console.log("check "+v.id);
						console.log(v.track);
						console.log(v.track.completion);*/
						
                        var hasCompletion = (v.track && v.track.completion);
						//console.log("has completion");
						//console.log(hasCompletion);
                         var pageSuspendData = hasCompletion ? _.first(_.where(suspendData, { id: v.id })) : false,
                            isCompleted = true;
						
                        if (!pageSuspendData || !pageSuspendData[hashed.completion] || (!$.inArray(pageSuspendData[hashed.completion], [hashed.completed, hashed.passed]) == -1) || pageSuspendData.a =="i" || pageSuspendData.a =="n") {
							
                            //not attempted or incomplete
                            isCompleted = false;
                        }
						
						//override because setpagecomplete was not actually changing track.completion
						if(window.bazingaApp.models.api.getPageCompletion(v.id) == "c"){
							isCompleted = true;
						}
						
						//console.log("Teststestt:"); console.log(isCompleted);
						
						var subSub = "";
						
						//console.log(v.id +" "+v.type);
						
						if(v.type == "group"){
							//console.log(v.id+" is group (subsubgroup)");
							
							subSub = '<ul id="js-dropdown-' + v.id + '" class="dropdown-level-3 collapse" >';
							
							for(var i=0;i<v.items.length;i++){
								
								//var page = v.items[i];
								//console.log(page);
								//console.log(courseConfig.language);
								//console.log("lang ext "+langExt);
								
								if(window.bazingaApp.models.api.getPageCompletion(v.items[i].id) == "c"){
									isCompleted = true;
								}else{
									isCompleted = false;
								}
								
								subSub += 
									'<li class="l3Li"><a href="#" data-sub-menu="1" class="dropdown-button' + (isCompleted ? ' is-completed' : '') + '"' +
                             ' data-goto="' + v.items[i].id + '"> <span class="icon-tick"><span class="a11y-assist-text">- completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + v.items[i]["title"+langExt] + '</a></li>'
							}
								
								subSub += '</ul>';
							
							//console.log(subSub);
						}
						
						if(v.type == "group"){
							
							//console.log(v.id + " still group"); //console.log(v.crumbs[0]);
							
							//is sub sub group, button that opens l3 menu
							html += '<li class="subSubGroup"><a role="button" data-toggle="collapse" data-parent="#js-dropdown' +'-'+ v.crumbs[0] + '"' +
                                'href="#js-dropdown-' + v.id + '" aria-expanded="false" aria-controls="js-dropdown-' + v.id + '" ' +
                                'class="dropdown-button dropdown-button--topic menu--level1 collapsed' + (isCompleted ? 'is-completed' : '') + '" tabindex="' + self.menu.tabIndex + '"><span class="icon-tick"></span>' + v["title"+langExt] + '</a> '+ subSub + '</li>';
						}else{
							/*console.log(v.id + " not group");*/
							//console.log(v);
							//mw
							
							var isPageLocked = false;
							
							if (_.has(lockables, v.id) && lockables[v.id].locked == true) {
								//console.log(v.id +" is locked");	
								isPageLocked = true;
							}
							
							//sub li
							html += '<li class="l2Li">' +
                            '<a href="#" data-sub-menu="1" class="dropdown-button ' + (isCompleted ? 'is-completed' : '') +(isPageLocked ? 'is-disabled' : '') + '"' +
                            ' tabindex="' + self.menu.tabIndex + '" data-goto="' + v.id + '"> <span class="icon-tick"><span class="a11y-assist-text">- completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + v["title"+langExt] + '</a>' +
                            '</li>';
						}
						

                    });

                    return html;
                }; // end submenu


            //self.menu.$el.empty();
            //since 1.0
            if (accessibilityVersion >= 2) {
                self.menu.tabIndex = "0";
            }
			
			//repeated from above
					if(window.bazingaApp.models.api.getLang() == "en" || window.bazingaApp.models.api.getLang() == "null"){
									langExt = "";
							}

            listIt = (_.filter(menu, function(it) {
                return it && it.visibility && it.visibility.menu;
            }));
			
			//console.log("-- start rendermenu --");
			//console.log(listIt.length);
			
			//on first launch, menu not loaded, refresh page 
			if(listIt.length == 0 && $("#js-dropdown").length > 0 && $("#js-dropdown li").length <= 1){
				
				//dodgy fix, menu doesn't render on first load in lms, so refresh page
				
				location.reload();
				
			}
			
            _.each(listIt, function(v, k) { //k is index
				//console.log("EACH "+k);
				/*console.log(listIt);
				console.log(v.id);
				console.log("track:"+v.track+". completion:"+v.track.completion);*/

                var hasCompletion = (v.track && v.track.completion),
                    pageSuspendData = hasCompletion ? _.first(_.where(suspendData, { id: v.id })) : false,
                    isCompleted = true,
                    subMenu;

                if (!pageSuspendData || !_.has(pageSuspendData, hashed.completion) || ($.inArray(pageSuspendData[hashed.completion], [hashed.completed, hashed.passed]) < 0)) {

                    isCompleted = false;
                }

                //console.log("v.items");
                //console.log(v.items);
				//items in group
                var filtered = _.filter(v.items, function(it) {
					//it = individual item page, v is a group
                    //console.log("it");
                    //console.log(it);
                        return it && it.visibility && it.visibility.menu;
                    }),

                    isDisabled = (function() {
                        if (_.has(lockables, v.id) && lockables[v.id].locked == true) {
                            return true;
                        }
                        return false;
                    }());

                    //console.log("filtered.length "+filtered.length); 

                if (filtered.length > 1) {
                    allHtml += "<li id='"+v.id+"' class='panel l1Li'>";
					
					//console.log(v);

                    if (isDisabled) {
                        //render as a disabled button
                        allHtml += '<a href="#"  class="dropdown-button menu--level1 is-disabled ' + (isCompleted ? 'is-completed' : '') + '"' +
                            ' tabindex="' + self.menu.tabIndex + '">' + v["title"+langExt] + '<span class="icon-tick"><span class="a11y-assist-text">Is completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + '</a>';

                    } else {
						/*console.log("about to renderSubMenu");
						console.log(v);
						console.log(v.items);*/
                        subMenu = renderSubMenu(v.items);
                        if (subMenu) {
                            allHtml += '<a role="button" data-toggle="collapse" data-parent="#js-dropdown' /*+'-'+ v.id*/ + '"' +
                                'href="#js-dropdown-' + v.id + '" aria-expanded="false" aria-controls="js-dropdown-' + v.id + '" ' +
                                'class="dropdown-button dropdown-button--topic menu--level1 collapsed ' + (isCompleted ? 'is-completed' : '') + '" tabindex="' + self.menu.tabIndex + '"><span class="icon-tick"></span>' + v["title"+langExt] + '</a>';


                            if (v.items && _.isArray(v.items) && v.items.length > 0) {
                                allHtml += '<ul id="js-dropdown-' + v.id + '" class="dropdown-level-2 collapse panel" >';
                                allHtml += subMenu;
                                allHtml += '</ul>';
                            }
                        }
                    }

                    allHtml += "</li>"

                } else if (filtered.length == 1 || filtered.length == 0) {

                    var first = _.first(v.items);
					
					/*console.log("first");
					console.log(filtered);
					console.log(v);
					console.log(langExt);*/
                    if(filtered.length == 0){ //not in a group
                       first = v;
                	}
					
                    if (isDisabled) {
                        //render as a disabled button
                        allHtml += '<li class="disSingleLi">' +
                            '<a href="#"  aria-disabled="true" disabled class="dropdown-button menu--level1 is-disabled ' + (isCompleted ? 'is-completed' : '') + '"' +
                            ' tabindex="' + self.menu.tabIndex + '"> <span class="icon-tick"><span class="a11y-assist-text">Is completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + v["title"+langExt] + '</a>' +
                            '</li>';
                    } else {
                        //render as a button
                        allHtml += '<li class="singleLi">' +
                            '<a href="#"  data-sub-menu="1" class="dropdown-button menu--level1 ' + (isCompleted ? 'is-completed' : '') + '"' +
                            ' tabindex="' + self.menu.tabIndex + '"data-goto="' + first.id + '"> <span class="icon-tick"><span class="a11y-assist-text">Is completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + v["title"+langExt] + '</a>' +
                            '</li>';
                    }
                }


            });
			//console.log(allHtml);
			//console.log(self.menu.$el);
            self.menu.$el.append(allHtml);

            if (self.menu.$el.find('[data-sub-menu]').length) {
                self.menu.$el.find('[data-sub-menu]').on('click touchend', function(e) {
                    self.gotoDecisionById(e);
                });
            }

            self.initializeMenu();
            return self;
        } // end rendermenu

    });

}());

(function(){
    window.bazingaApp.views.dialogContinueView =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            $('[tabindex="1"]:first').focus();
        },
        loaded: function(){
            //override this on your page view

        }
    });

}());
(function(){
    window.bazingaApp.views.dialogResourcesView =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            $('[tabindex="1"]:first').focus();
        },
        loaded: function(){
            //override this on your page view

        }
    });

}());
(function(){
    window.bazingaApp.views.dialogResetView =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            $('[tabindex="1"]:first').focus();
        },
        loaded: function(){
            //override this on your page view

        }
    });

}());
(function(){
    window.bazingaApp.views.dialogCompleteView =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            $('[tabindex="1"]:first').focus();
        },
        loaded: function(){
            //override this on your page view

        }
    });

}());
(function(){
    window.bazingaApp.views.dialogExitView =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            $('[tabindex="1"]:first').focus();
        },
        loaded: function(){
            //override this on your page view

        }
    });

}());
(function(){
    window.bazingaApp.views.dialogHelpView =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
		
            $('[tabindex="1"]:first').focus();
        },
        loaded: function(){
            //override this on your page view

        }
    });

}());
(function(){
    window.bazingaApp.views.abstractSplash =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            $('[tabindex]:first').focus();
        }
    });

}());
(function(){
    window.bazingaApp.views.abstractClickAudioView =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            //console.log(window.bazingaApp.models.api.getCourseConfig());
            var footer = $(".footbar"),
                tabIndexNum = "850",
                playButton = footer.find(".mejs-playpause-button").children().first(),
                volumeButton = footer.find(".mejs-volume-button").children().first(),
                itemsArr = [playButton, volumeButton],
                self=this,
                i,
                courseConfig = window.bazingaApp.models.api.getCourseConfig(),
                accessibilityVersion = _.has(courseConfig,'accessibilityVersion') ? courseConfig['accessibilityVersion'] : 1;

            if(accessibilityVersion  >= 2){
                //do stuff for custom module accessibility
                tabIndexNum =  '0';
            }
            //start page level js here


            $('[data-audio-play]').click(function(elem) {
                var $elem = $(elem), data = $elem.data();

                if($elem.hasClass('is-disabled')){return false;}

                $elem.addClass('is-disabled');

                if(_.has(data,'src') && self.audio){
                    self.audio.resetSrc(data.src);
                }
                else{
                    //self.audio.play();
                    playButton.click().focus();
                    $('[data-audio-play]').unbind("click");

                }
            });

            // Fixing tabindex for player
            for (i=0; i<itemsArr.length; i++) {
                itemsArr[i].attr("tabindex", tabIndexNum);
            }

            // skip to content /local
            //$(".js-skip-link").click(function() { $(".js-skip-focus").focus() });
        },

        onReSize: function () {
            /*var vidWidth = $("#v-player").width();
            //console.log(vidWidth);
            var ratio = $("#v-player").attr("data-height");
            //console.log(ratio);
            var ratioNum = eval(ratio);
            //console.log(ratioNum);

            var newHeight = ratioNum * vidWidth;

            console.log(newHeight);

            $("#v-player object.flashVideo").attr("height",newHeight);*/
        }

    });

}());