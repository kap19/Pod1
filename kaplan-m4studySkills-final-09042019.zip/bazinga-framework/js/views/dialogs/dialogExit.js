(function(){
    window.bazingaApp.views.dialogExitView =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            $('[tabindex="1"]:first').focus();
        },
        loaded: function(){
            //override this on your page view

        }
    });

}());