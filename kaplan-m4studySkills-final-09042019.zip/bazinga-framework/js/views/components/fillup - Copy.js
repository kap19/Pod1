(function ($) {
    "use strict";
    window.bazingaApp.views.fillupManager = window.bazingaApp.views.abstractComponentView.extend({
        fillups : [],
        fuIdentifier : '[data-fu-id]',


        showNeutralFeedback : false,
        autoComplete : false,
        fuType : 'single',
        trackable : true,
        partials : {
            type :'of',
            tgt  : null
        },
        correct : [],
        totalWeightage : 0,
        state : "not-attempted",
        getState : function(){return this.state;},
        getIsTrackable : function(){return this.trackable ;},
        initialize : function(){
            _.bindAll(this,'load','randomize','loadfillups','recalculate','show','hide');
        },
        selectOrder : [],
        definedOrder : [],
        feedbacks : {show:null,hide:null},
        animations : 'fade',

        recalculate : function(e){

            if(e && e.currentTarget && ($(e.currentTarget).hasClass('is-disabled'))){
                e.stopPropagation();
                return false;
            }

            $(e.currentTarget).addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);

            var self=this,
                allFillUps = self.fillups,
                answers = {"correct" : [], "wrong" : [],"neutral":[],"partial":[]},
                score= 0,
                score_max = self.totalWeightage,
                allIds=[],
                i= 0,
                fb = 'naf';

			self.submitButton.addClass('is-submitted');

            if(self.resetButton){self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);}


            _.each(allFillUps,function(fu){
                var $el = fu.$el,
                    selected = $el.val(),
                    correct,
                    allCorrect=$el.find('[data-correct]'),
                    correctValue=[],
                    id = $el.data('fuId'),
                    intersection;

                $el.addClass('is-disabled').attr('disabled','true').attr("aria-disabled",'true').attr("disabled","true");

                if(allCorrect.length == 0){
                    $el.addClass('is-neutral');
                    answers.neutral.push({id:id,$el:$el});
                    //Always a neutral feedback
                    return true;
                }

                _.each(allCorrect, function(k){
                    correctValue.push($(k).val());
                });

                if(typeof selected == 'string'){selected = [selected];}

                intersection= _.intersection(selected,correctValue);

                if(intersection.length == correctValue.length){
                    //correct
                    answers.correct.push({id:id,$el:$el});
                    $el.addClass('is-correct');
                    score += parseInt( $(fu).data('weight') || 1);
                }
                else if(intersection.length > 0){
                    //partially right
                    answers.partial.push({id:id,$el:$el});
                    $el.addClass('is-partial');
                    score += (parseInt( $(fu).data('weight') || 1))*0.5;
                }
                else{
                    //wrong
                    answers.wrong.push({id:id,$el:$el});
                    $el.addClass('is-wrong');
                }

                allIds.push(id);
            });

            var ret = {
                target:self,
                answers:answers,
                allIds : allIds,
                score:score,
                score_max:score_max,
                percentage : ((score/score_max)*100)
            };


            ret.state="passed";

            if(allIds.length == answers.correct.length){
                ret.state = self.state = "passed";
            }
            else{
                console.log(self.partials);
                //trigger neutral
                if(self.partials.tgt){
                    if(self.partials.type == 'of'){
                        if(answers.correct.length >= self.partials.tgt[0]){
                            ret.state = 'partial';
                        }
                        else{
                            ret.state = 'failed';
                        }
                    }
                    else if(self.partials.type == 'in'){
                        var overlap = _.intersection(self.partials.tgt,answers.correct);
                        if(!_.isEmpty(overlap) && (overlap.length == self.partials.tgt.length )){
                            ret.state = 'partial';
                        }
                        else{
                            ret.state = 'failed';
                        }
                    }
                    else{
                        if(ret.percentage >= parseInt((self.partials.tgt[0] || 50))){
                            ret.state = 'partial';
                        }
                        else{
                            ret.state = 'failed';
                        }
                    }
                }
                else{
                    ret.state = 'failed';
                }
            }


            fb = '[data-caf]';
            if(self.showNeutralFeedback){
                fb='[data-naf]';
            }
            else {
                if(ret.state=='passed'){
                    fb='[data-caf]';
                }
                else if(ret.state=='failed'){
                    fb='[data-waf]';
                }
                else{
                    fb='[data-pcaf]';
                }
            }

            if(self.feedbacks.show){
                self.show(self.feedbacks.show.find(fb,null,100));

                var showFeedback = function(callback){
                        self.show(self.feedbacks.show,callback);
                    },
                    hideFeedback = function(callback){

                        console.log("hideFeedback "+self.feedbacks);
                        console.log("hideFeedback length "+self.feedbacks.length);

                        if (self.feedbacks.length == 0 || !_.has(self.feedbacks, "hide") || self.feedbacks.hide.length == 0) {
                            callback();
                        }
                        else{
                            self.hide(self.feedbacks.hide,callback);
                        }
                    };


                if(self.animateOrder =='hideShow'){

                    hideFeedback(function(){
                        showFeedback(function(){
                            $(".tip").addClass('hidden');
                            self.trigger("completed:fillup",ret);
                        });
                    });
                }
                else{
                    showFeedback(function(){
                        $(".tip").addClass('hidden');
                        hideFeedback(function(){
                            self.trigger("completed:fillup",ret);
                        });
                    });
                }
            }
            else{
                setTimeout(function(){self.trigger("completed:fillup",ret)},20);
                console.log("No feedbacks located. SO event was triggered");
            }

            console.log(ret);
            self.completed = 'completed';
      },

        show : function(element,callback,delay){
            var self=this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 300;


            if(typeof callback !== 'function'){
                callback =function(){}
            }

            switch (classOverride){
                case "fade":
                case "fadeinout":
                    promise = element.fadeIn(delay,callback);
                    break;

                case "slideUp":
                case "slideUpDown":
                    promise = element.slideUp(delay,callback);
                    break;

                case "slideDown":
                case "slideDownUp":
                    promise = element.slideDown(delay,callback);
                    break;

                default:
                    promise = element.show(delay,callback);
                    break;
            }

            return promise;
        },
        hide : function(element,callback,delay){
            var self=this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 600;

            if(typeof callback !== 'function'){
                callback =function(){}
            }


            switch (classOverride){
                case "fade":
                case "fadeinout":
                    promise = element.fadeOut(delay,callback);
                    break;

                case "slideUp":
                case "slideDownUp":
                    promise = element.slideUp(delay,callback);
                    break;

                case "slideDown":
                case "slideUpDown":
                    promise = element.slideDown(delay,callback);
                    break;

                default:
                    promise = element.hide(delay,callback);
                    break;
            }

            return promise;
        },
        loadfillups : function(reload){
            reload = reload===false ? false : true;
            if(reload){this.fillups = [];};

            var self=this,
                i= 1,
                fillups = this.$el.find(this.fuIdentifier);

            if(fillups.length == 0){
                console.error("Unable to load fillups. no data-fu ids exists");
            }

            _.each(fillups, function (fu) {
                var $fu = $(fu),
                    id = $fu.data('fuId'),
                    type = $fu.data('dropDown') || 'selectpicker';


                if (reload) {
                    self.definedOrder.push({id: id, order: ($fu.data('order') || i++)});
                    self.fillups.push({
                        id: id,
                        $el: $fu,
                        weight: ($fu.data('weight') || 1)
                    });

                    if(type == 'selectpicker'){
                        $fu.selectpicker();
                    }
                }
				
				
            });

            self.definedOrder = _.sortBy(self.definedOrder, function(o){return o.order;});
            self.totalWeightage = (_.reduce(self.fillups,function(memo,fu){return fu.weight+memo;},0));
        },
        randomize: function(){
			console.log("randomise fillup")
            var self=this,
                randomizeOptions  = function($el){
                    if(!$el || $el.length == 0){return false;}


                    _.each($el,function(elem){
                        var $elem = $(elem),
                            options = $elem.find('option');

                        $elem.empty();
                        options = _.shuffle(options);

                        _.each(options,function(op){
                            $elem.append($(op));
                        });
                    });

                    return $el;
                };  

            if(self.fillups.length == 0){return false;}

            _.each(self.fillups,function(fillup){
                var hasOptGroup = fillup.$el.find('optgroup').length;

                if(hasOptGroup){
                    randomizeOptions(fillup.$el.find('optgroup'));
                }
                else{
                    randomizeOptions(fillup.$el);
                }
            });
            self.loadfillups(false);
        },
        load : function($el){
            this.$el = $el;

            var data = this.$el.data(),
                self=this,
                allowPartials = false;

            this.loadfillups();

            if(_.has(data,'fillUpType') && $.inArray(data.fillUpType, ['multiple']) >= -1){
                self.fuType= data.fuType;
            }
			
            //todo Correct has to be loaded for each fill up

            if(!_.has(data,'submit')){
                console.error("[fillup Message] No submit button mentioned. A submit button is necessary for evaluation.");
            }
            else{
                self.submitButton = $(data.submit);
                self.submitButton.on("click",self.recalculate);
			
				if(_.has(data,'startDisabled')){
					self.submitButton.addClass("is-disabled").attr("aria-disabled",true).attr("disabled",true); 
					
					$(".fillup-select").change(function(){
						var enableSubmit = true;
						//console.log($(this).val());
						
						$('.fillup-select').each(function(i, obj) {
							//console.log(obj);
							//console.log($(this).val());
    						if($(this).val() == 0){
								enableSubmit = false;
							}
						});
						
						if(enableSubmit== true){
							self.submitButton.removeClass("is-disabled").attr("aria-disabled",false).attr("disabled",false); 
						}else{
							self.submitButton.addClass("is-disabled").attr("aria-disabled",true).attr("disabled",true); 
						}
						
				});
					
				}
				
            }
			
            if(_.has(data,'reset')){
                self.resetButton = $(data.reset);
                self.resetButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                self.resetButton.on("click",function(){
                    self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                });
            }


            self.animateOrder = (_.has(data,'animateOrder')  && data.animateOrder == 'showHide') ? data.animateOrder : "hideShow";


            if(_.has(data,'animations')){
                self.animations = data.animations;
            }
            if(_.has(data,'animation')){
                self.animations = data.animation;
            }

            //Partial set up
            if(_.has(data,'partialOn')){
                allowPartials = (data.partialOn == '1');
            }
            if(allowPartials && _.has(data,'partials') && data.partials){
                self.partials.type = data.partialType || 'of';
                self.partials.tgt = (""+(data.partials || "")).split(',');
            }
			
            if(_.has(data,'randomize') ||  _.has(data.randomize !== '0') ){
                this.randomize();
            }

            if(!_.has(data,'feedbackShowSelector')){
                console.log("[fillups] NO FEEDBACK SELECTOR IN DATA TAG>. NO FEEDBACKS WILL BE SHOWN BY THE fillup");
            }
            else{
                self.feedbacks.show = $(data.feedbackShowSelector);
                if(self.feedbacks.show.length == 0){
                    console.log("[fillups] FEEDBACK NOT LOCATED");
                }
                self.feedbacks.hide = $(data.feedbackHideSelector);


                self.hide(self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]"));
                console.log("self.feedbacks.show.find? "+self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]"));
                self.hide(self.feedbacks.show);
                self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]").hide();
                self.feedbacks.show.hide();
            }

            if(_.has(data,'preventTrack') && data.preventTrack){
                self.trackable = false;
                self.completed = 'completed';
                self.trigger("completed:fillup",self)
            }
        }
    });


    window.bazingaApp.views.fillupView = window.bazingaApp.views.abstractComponentView.extend({
        el: '[data-fillup]:not(.js-prevent-interaction)',
        fuEl : '.fillup',
        feedbacks : null,
        allow : {
            randomize : true
        },
        fuList : [],
        events: {

        },
        initialize: function () {
            if(this.$el.length == 0){this.enabled = false;}

            this.componentType='fillups';
            var self=this,
                recalculate = function(e){
                    var todo  = 0;
                    _.each(self.trackables, function(v){
                        if(v.getIsCompleted()){return false;}
                        todo++;
                    });

                    if(todo ==0){
                        self.completed = 'completed';
                        //trigger event for appview
                        self.trigger(('completed:'+self.componentType) ,self,e);
                    }
                };

            this.trackables = [];


            _.each(this.$el, function(el){
                var $el = $(el),
                    fuManager = new window.bazingaApp.views.fillupManager();

                fuManager.on("completed:fillup",function(e){recalculate(e);});
                fuManager.load($el);

                if(fuManager.getIsTrackable()){self.trackables.push(fuManager);}
                self.fuList.push(fuManager);
            });
			
        },
        setAllow : function ( allow){
            this.allow = _.extend(this.allow,allow);
            return this;
        }

    });
})(window.$ || window.JQuery);