/*
 mw - commented out
 
(function($){
    "use strict";*/

    /**
     * Backstetch view for js . TO use this file do the following
     * In appview initialize the backstetch view
     ```
     window.bazingaApp.views.components.backstretch = new window.bazingaApp.views.backstretchView();
     ```
     * Use data tags to initialize the backstetch view. There needs to be two data tags
     ```
     <div class="background" data-backstretch=1 data-backstretch-img='../img/splash_background.png'></div>
     ```
     * @type {*}
     */
    /*window.bazingaApp.views.backstretchView = Backbone.View.extend({
        el: "[data-baz-backstretch='1']",

        initialize:function(){
            this.componentType='backstretch';
            var self=this;
            self.resize();
            if(this.$el.length == 0){return false;}

            this.$el.backstretch(this.$el.data('bazBackstretchImg'));
            window.onresize = self.resize.bind(self);
        },
        resize : function(){
            if ($(window).width() <= 766) {
                this.$el.css({'position': 'relative'});
            } else {
                this.$el.css({'position': 'fixed'});
            }
            if($(window).height() <= 620) {
            	$('.splash .last').css('bottom','auto');
            } else {
            	$('.splash .last').css('bottom',20);
            }
        }
    });

})(window.$||window.JQuery);*/