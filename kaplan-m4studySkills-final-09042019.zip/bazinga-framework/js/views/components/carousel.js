(function($) {
    "use strict";

    window.bazingaApp.views.carouselView = window.bazingaApp.views.abstractComponentView.extend({
        el: '[data-ride="carousel"]:not(.js-prevent-interaction)',
        events: {},
        clickable: true,
        selector: {},
        load: function() {
            var loadedFirstTime = false;
            var self = this,
                getItemIndex = function(item) {
                    self.$items = item.parent().children('.item')
                    return self.$items.index(item)
                },
                isComplete = function($tgt) {
                    var $active = self.$el.find('.item.active'),
                        ix = getItemIndex($active),
                        focussible;
                    //since 1.0
                    if (self.$el.data('accessible') == true) {
                        //version 1.2.0 +
                        //console.log("Custom module carousel");
                        //This is an accessible carousel for CUstom modules, only difference is hitting prev/next does a focus on the contentsc
                        if (ix == 0) {
                           self.$el.find('.prevContainer').css('display','none');
                        } else {
                            self.$el.find('.prevContainer').css('display','block');
                        }

                        if (ix == (self.$items.length - 1)) {
                            //complete carousel
                            self.completed = "completed";
                            self.trigger('completed:carousel', self);
							self.$el.find('.nextContainer').css('display','none');
                        } else {
                            self.$el.find('.nextContainer').css('display','block');
                        }

                        focussible = $active.find('.js-carousel-focus');

                        //don't
                        if (loadedFirstTime) {
                            if (focussible.length > 0) {
                                $(focussible[0]).attr("tabindex", 0);
                                focussible[0].focus();
                            }
                        }
                        if (!loadedFirstTime) {
                            loadedFirstTime = true;
                        }
                    } else {
                        //AEC modules
						console.log("AEC carousel");
                        if (ix == 0) {
                            self.$el.find('[data-slide="prev"]').hide();
                            self.$el.find('[data-slide="next"]').focus();
                        } else {
                            self.$el.find('[data-slide="prev"]').show();
                        }

                        if (ix == (self.$items.length - 1)) {
                            self.completed = "completed";
                            self.trigger('completed:carousel', self);
                            if (self.isWrap) {
                                self.$el.find('[data-slide="next"]').hide();
                                self.$el.find('[data-slide="prev"]').focus();
                            }
                        } else {
                            if (self.isWrap) {
                                self.$el.find('[data-slide="next"]').show();
                            }
                        }
                    }


                };


            this.componentType = 'carousal';
            if (this.$el.length == 0) {
                this.enabled = false;
                this.completed = 'completed';
            } else {
                this.completed = "incomplete";
            }

            self.isWrap = this.$el.data('wrap');

            _.each(this.$el, function(e) {
                isComplete($(e));
            });



            this.$el.on('slid.bs.carousel', function(obj) {

                $("html,body").animate({scrollTop:$(obj.target).offset().top/*-$('.navbar').outerHeight()*/},500,"swing");

                isComplete();
            });


            this.recalculate();
        },
        recalculate: function() {}
    });
})(window.$ || window.JQuery);
