(function ($) {
    "use strict";

    /*
     *	display tick for accordion
     * 	
     * 	Mandatory Attributes:
     * 	data-accordion-type="tick" (the address the tick element by backbone, bind view on it)
     * 
     * 	useage:
     * 
     * <a class="row" data-accordion-type="tick">
     *     <span class="col-xs-10">...</span>
     *     <span class="col-xs-2 u-text-right">
     *       <span class="icon-tick"></span> //add class "hidden" in here to set default visibility if necessary
     *     </span>
     * </a>
     *
     */
    window.bazingaApp.views.tickView = window.bazingaApp.views.abstractComponentView.extend({
        el: '[data-accordion-type="tick"]:not(.js-prevent-interaction)',
        events: {
            "click": "show"
        },
        selector: {
        	container: '[data-accordion-type="tick"]'
        },

        initialize: function () {
            _.bindAll(this, 'show','recalculate');
            if(this.$el.length == 0){this.enabled = false;}

            this.componentType='accordionTick';

            $('#accordion').on('shown.bs.collapse',function(obj){
                if($(obj.target).is(':visible')){
                    $("html,body").animate({scrollTop:$(obj.target).siblings('.panel-heading').offset().top-$('.navbar').outerHeight()},500,"swing");
                }
            });

            this.recalculate();
        },
        recalculate: function () {
            if(this.getIsCompleted()) return this;

            var self = this,
                completed = self.completed = self.completed || false,
                totalCount = $(self.selector.container).length,
                incompleteCount = $(self.selector.container).not(".is-visited").length;

			//console.log(self);
			//console.log(totalCount);
			//console.log(incompleteCount);
			
            if( incompleteCount == 0){
                self.completed = 'completed';
                self.trigger('completed:tick',self);
				$(self.selector.container).parent().parent().addClass("is-completed");
            }
            else if(incompleteCount !== totalCount){
                self.completed = 'incomplete';
            }

            return self;
        },
        show: function(e) {
        	var target = e.target,
        		self = this,
                $target = $(target).data('accordionType')?$(target):$(target).closest(self.selector.container);
            
            e.preventDefault();
            //selecting the current target
            $(self.selector.container).removeClass('is-selected');
            //complete the target
            $target.addClass('is-selected').addClass('is-visited');
           
//           $('.icon-tick',$target).removeClass('hidden');
           $('.panel-heading .icon-tick',$target).show();
           self.recalculate();
			
			//console.log($target);
			var accordionContainer = $(target).parent().parent();
			//console.log(accordionContainer.find(".panel-heading").not(".is-visited").length);
			
			if(accordionContainer.find(".panel-heading").not(".is-visited").length == 0){
				console.log("an accordion is completed");
				accordionContainer.addClass("is-completed");
			}
			
        }
    });
})(window.$ || window.JQuery);