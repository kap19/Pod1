(function ($) {
    "use strict";
    window.bazingaApp.views.abstractComponentView = Backbone.View.extend({
        completed: 'not-attempted',
        componentType:'abstract',
        enabled : true,

        getComponentType : function(){return this.componentType;},
        /**
         * Make sure this is included in the component js
         */
        isEnabled : function(){return this.enabled;},
        /**
         * Make sure this is included in the component js
         */
        getIsCompleted: function () {
            return this.completed == 'completed' || this.completed === true || this.completed === 1;
        },

        init : function(){

        }

    });
})(window.$ || window.JQuery);