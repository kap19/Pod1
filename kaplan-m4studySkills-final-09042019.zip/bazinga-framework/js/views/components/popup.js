(function($) {
    "use strict";

    /*
    
Mandatory Attributes:
data-reveal-object="#pop1" for button, the id of popup should be "pop1")
data-reveal-type (the way to render the popup, options: "popup", "overlay") 

Unused types: 'dialog' (just use overlay) and 'tooltip' doesn't work and seems to only works on hover.moved to bottom

Optional:
class="js-popup-focus" (if set to one of the html element inside in popup, the element will be focused after popup displayed.)
                 (if not set, will focus the popup self)

usage:

1) html structure for type: "popup":

<button data-reveal-type="popup" data-reveal-object="#pop1">1btn</button>
<button data-reveal-type="popup" data-reveal-object="#pop2">2btn</button>

<div id="pop1" data-reveal-target="popbox">1content</div>
<div id="pop2" data-reveal-target="popbox">2content</div>
  
     */
    window.bazingaApp.views.popupView = window.bazingaApp.views.abstractComponentView.extend({
        el: $('[data-reveal-type]:not(.js-prevent-interaction)'),
		
        events: {
            "click": "dispatch",
            "touchend": "dispatch",
            "keydown": "onKeyPress"
        },
        clickable: true,
        selector: {
            container: '[data-reveal-type]',
            popup: '[data-reveal-target="popbox"]',
            tooltip: '[data-reveal-target="tooltip"]',
            dialog: '[data-reveal-target="pop-dialog"]',
            overlay: '[data-reveal-target="overlay"]',
            close: '[data-reveal-target="pop-close"]'
        },
        initialize: function() {
            _.bindAll(this, 'dispatch', 'show', 'hide', 'appendContent', 'dialog', 'recalculate', 'doFocus', 'applyAccessibility', 'delegateCloseEvent', 'onKeyPress');
            this.delegateEvents();
            this.componentType = 'popup';
            //console.log("number popups :" + this.$el.length);
            if (this.$el.length == 0) {
                //console.log("0 completed");
                this.enabled = false;
				this.completed = 'completed';
            } else {
                //console.log("not 0 incomplete");
                this.completed = "incomplete";
            }
			
			//get number of non trackables
			
			var nonTrackables = 0;
			
			for (var i=0;i<this.$el.length;i++){
				var anEl = this.$el[i];
				
				for(var e=0;e<anEl.attributes.length;e++){
					var anAttr = anEl.attributes[e];
					//console.log(anAttr);
					if(anAttr.name == "data-prevent-track"){
						nonTrackables += 1;
					}
				}
			}
			
			//console.log(this.$el);
			//console.log(this.$el[0].attributes);
			
			//console.log("trackable popups "+nonTrackables+"/"+this.$el.length);
			
			if(this.$el.length == nonTrackables){
				//only non trackables
                this.completed = 'completed';
			}


            this.delegateCloseEvent();
            this.dialog();
            this.recalculate();
        },
        onKeyPress: function(e) {
			//console.log("keypressssssssssssssss");
            if (e.keyCode == 13) {
				console.log("is 13/enter");
                this.dispatch(e);
            }
        },
        recalculate: function() {
            //console.log("recalculate");
            if (this.getIsCompleted()) {
                return this;
            }

            var self = this,
                completed = self.completed = self.completed || false,
                totalCount = $(self.selector.container) /*.not(':hidden').not('[data-prevent-track]')*/ .length,
                incompleteCount = $(self.selector.container).not('.is-visited').length,
                completedCount = $(self.selector.container + '.is-visited').not('[data-prevent-track]').length,
                nonTrackables = $(self.selector.container + '[data-prevent-track]').length;

            //console.log("completed " + completedCount);
            //console.log("nonTrackables " + nonTrackables);
            //console.log("total " + totalCount);

            if (incompleteCount == 0 || completedCount + nonTrackables >= totalCount) {
                self.completed = 'completed';
                self.trigger('completed:reveal', self, { total: totalCount });
            } else if (incompleteCount !== totalCount) {
                self.completed = 'incomplete';
            }
			
			//console.log("fin recalculate");

            return self;
        },
        dispatch: function(e) {
            //console.log("dispatch");
            var content,
                target = e.target,
                self = this,
                $target = $(target).data('revealObject') ? $(target) : $(target).closest('[data-reveal-object]'),
                revealData = $target.data('revealData'),
                revealObj = $target.data('revealObject'),
                hideObj = $target.data('hideObject'),
                revealType = $target.data('revealType'),
				addClass = $(target).data('addClass');
				
            //console.log("dispatch");

            if ($target.hasClass('is-disabled')) {
                console.log("is disabled");
                return;
            } //example: locker for simple senario homepage

            //console.log("add is visisted");
            //mw makes it work for a non-popup button
			if(!$(target).hasClass("is-disabled")){
            	$(target).addClass("is-visited");
			}

            self.type = "";
            e.preventDefault();
            //a flag to control the click behavior will only be enabled after last animation
			//removed because if you clicked fast enough before the animation finished, the completion would not trigger
            /*if (!self.clickable) {
                return;
            }*/

            //selecting the current target
            this.$el.removeClass('is-selected');
            //complete the target
            $target.addClass('is-selected');
			
			if(!$target.hasClass("is-disabled")){
				//console.log("add");
				$target.addClass('is-visited');
			}
			
            self.checkLockedBtns();
			
			//console.log("dispatch");
			//console.log(self);
			//console.log($target);
			
			if($target.closest(".btnGroup")){
					var btnGroup = $target.closest(".btnGroup");
					var totalBtns = btnGroup.find("[data-reveal-type]").not("[data-prevent-track]").length;
					var visitedBtns = btnGroup.find(".is-visited[data-reveal-type]").not("[data-prevent-track]").length;
					var incompleteBtns = btnGroup.find(".contentCompleteBtn[data-reveal-type]").not(".is-completed").not("[data-prevent-track]").length;
					//optional?  
					console.log("incompleteBtns "+incompleteBtns);
					console.log((visitedBtns - incompleteBtns)+"/"+totalBtns);
					
					if(visitedBtns - incompleteBtns == totalBtns){
						btnGroup.addClass("is-completed");
					}
					
				}

            (function() {
                var r = ($target.data('revealReflect'));

                r = ((r || "") + "").split(",");
                if (r.length == 0) {
                    return null;
                }

                _.each(r, function(v, k) {
                    $('[data-reveal-id="' + v + '"]').addClass('is-visited');
                });
            })();

			console.log("revealType "+revealType);
            switch (revealType) {
                case 'popup':
                    self.clickable = false;
                    //hide all others, keep only one opens
                    $(self.selector.popup).not(revealObj).hide();
                    if (hideObj) {
                        this.hide(hideObj);
                    }
                    this.show(revealObj);
                    $(window).trigger('resize');
                    break;
                case 'tooltip':
                    $(self.selector.tooltip).not(revealObj).hide();
                    this.show(revealObj);
                    $(window).trigger('resize');
                case 'dialog':
                    content = $(this.selector.dialog + ':eq(0) .modal-body'); //dialog content
                    this.appendContent(content, revealData);
                    break;
                case 'overlay':
                    self.type = "overlay";
                    content = $(this.selector.overlay + ' .js-overlay-content'); //overlay content
                    self.appendContent(content, revealData);
                    self.show(revealObj, revealType);
                    $(window).trigger('resize');
                    break;
            }
			
			if(addClass){
				$(revealObj).addClass(addClass);
			}
			
            self.recalculate();
        },
        show: function(el) {
            var self = this;
            $(el).fadeIn(function() {
                setTimeout(function() {
                    self.clickable = true;
                }, 100);

                self.doFocus($(this), true);
                //if ($.inArray(($(self.el).data('revealType')), ["overlay"]) > -1) {
				//console.log("show");
				//console.log($(el));
				
				if (($.inArray(($(el).data('revealType')), ["overlay"]) > -1) || $.inArray(($(el).data('revealTarget')), ["overlay"]) > -1 ){
					console.log("is overlay");
                    self.applyAccessibility($(this), true); //overlay accessibilty, makes everything outside of overlay untabbable
                }

                if ($(el).find('video').length != 0) {
                    $(window).trigger('resize');
                    /*console.log("play video");*/

                    var videoContainer = $(el).find('.mejs-container');

                    videoContainer.addClass("isVisible");
                    var videoChild = $(el).find('video:visible');
                    //autoplay video if specified attribute
                    if (videoChild.attr('autoplayOnVisible') != null) {
                        videoChild[0].play();
                    }
                }
				

            });
        },
        hide: function(el) {
			console.log("hide");
            var self = this;
			
			if($(el).attr("data-animation-hide") != "fade" || $(el).attr("data-animation-hide") == "instant"){
				$(el).hide();
			}
			
            $(el).fadeOut(function() {
                var revealId = $(this).attr('data-reveal-id');

                self.doFocus(revealId ? $('[data-reveal-data=#' + revealId + ']') : $('[data-reveal-object="#' + $(this).attr('id') + '"]:not(' + self.selector.close + ')'), false);
                if ($.inArray(($(self.el).data('revealType')), ["overlay"]) > -1 || $.inArray(($(el).data('revealTarget')), ["overlay"]) > -1) {
					console.log("close overlay");
                    self.applyAccessibility(revealId ? $('[data-reveal-data=#' + revealId + ']') : $('[data-reveal-object="#' + $(this).attr('id') + '"]:not(' + self.selector.close + ')'), false);
					
					//stop all audio
					$('audio').each(function(){
						this.pause(); // Stop playing
						if(this.currentTime){
						this.currentTime = 0; // Reset time
						}
					}); 
                }

                $(window).trigger('resize');

                //pause video if in modal window
                if ($(el).find('video').length != 0) {

                    $('video').trigger('pause');
                    var videoContainer = $(el).find('.mejs-container');

                    videoContainer.removeClass("isVisible");
                }

            });
        },
        dialog: function() {
            var self = this;
            self.doFocus($('.modal-dialog', $(this)));
            $(this.selector.dialog + ':eq(0)').on('shown.bs.modal', function() {
                self.applyAccessibility($('.modal-dialog', $(this)));
            });
        },
        appendContent: function(content, el) {
            var self = this,
                $el = $(el);

            content.closest(self.selector.overlay).attr('data-reveal-id', $(el).attr('id'));
            if ($(el, content).length == 0) {
                $el.appendTo(content);
                self.trigger("data:popup", self, { $tgt: content });
            }
            $('.js-overlay-data').hide();
            $(el).show();
        },
        doFocus: function(el, isOpen) {
			//console.log("dofocus ");
			//console.log(el);
			
            var focusEl = $('[class*=-focus]', el),
                tabEls = $('.notOverlay,input,select,textarea,button,object,button,a,[tabindex]'), //converting to tabbable element a button input 

                self = this;
            el.removeClass('is-selected');
            //focus the target for accessibility
			
			//console.log(focusEl);
			
            if ($(window).width() > 768) {
                if (focusEl.length > 0) {
                    focusEl.focus();
                } else {
                    el.attr("tabindex",0).focus();
					//focus first children instead?
 					//el.children(":first").attr("tabindex",0).focus();
				}
            }

            //mw check if item only completes when content is complete
			//console.log("doFocus");
            //console.log(el);
            //console.log(el.data('contentComplete'));
            if (el.hasClass("contentCompleteBtn")) {
                //console.log("contentComplete");
				//console.log(el);	
				
                var contentId = $(el.data('revealData'));
				var accordionChild = "[data-toggle]";

                //console.log(contentId);
				
				//console.log(contentId.find(accordionChild).length);
				
				//console.log("contentId");
				//console.log(contentId);

				//buttons, accordion, audio, video, mc submit button
				
				var incompleteCount = contentId.find(self.selector.container).not('.is-visited').length + contentId.find(accordionChild).not('.is-visited').length+contentId.find("audio").not('.optional').not('.is-completed').length+contentId.find("video").not('.is-completed').length+contentId.find("[type='submit']").not(".is-submitted").length;
				
                /*var totalCount = contentId.find(self.selector.container).length + contentId.find(accordionChild).length + contentId.find("audio").length,
                    incompleteCount = contentId.find(self.selector.container).not('.is-visited').length + contentId.find(accordionChild).not('.is-visited').length+contentId.find("audio").not('.is-completed').length+contentId.find("[type='submit']").not(".is-submitted").length,
                    completedCount = contentId.find(self.selector.container + '.is-visited').not('[data-prevent-track]').length + contentId.find(accordionChild + '.is-visited').not('[data-prevent-track]').length + contentId.find('audio.is-completed').not('[data-prevent-track]').length,
                    nonTrackables = contentId.find(self.selector.container + '[data-prevent-track]').length + contentId.find(accordionChild + '[data-prevent-track]').length + contentId.find('audio[data-prevent-track]').length;*/

				/*console.log("check incompleted " + incompleteCount);
                console.log("check completed " + completedCount);
                console.log("check nonTrackables " + nonTrackables);
                console.log("check total " + totalCount);*/

				console.log("incompleteCount "+incompleteCount);
				
                if (incompleteCount == 0 /*|| (completedCount + nonTrackables >= totalCount && nonTrackables > 0 )*/) {
                    el.addClass("is-completed");

                    self.checkLockedBtns();
                }

            };
			
			if(el.hasClass("button--hotspot") && el.parents('.timeline-slide').length){
				//console.log("is hotspot test");
				var timelineSlide = el.closest('.timeline-slide');
				
				var slideId = timelineSlide.attr("id");
				//console.log(slideId);
				//console.log(timelineSlide.find('.button--hotspot').not('.is-visited').length);
				
				if(timelineSlide.find('.button--hotspot').not('.is-visited').length == 0){
				
					$('.contentCompleteBtn[data-reveal-object]').each(function(){
						//console.log($(this).data('revealObject'));
						if($(this).data('revealObject') == "#"+slideId){
							
							$(this).addClass("is-completed");
							self.checkLockedBtns();
						};
					});
				}
			}

        },

        checkLockedBtns: function() {
            $('.is-disabled[data-locked-until]').each(function() {
                console.log("checklocked");
               var checkCompleted = $($(this).data('lockedUntil'));

               var shouldUnlock = false;

               if(checkCompleted.hasClass("contentCompleteBtn")) {
                if(checkCompleted.hasClass("is-completed")){
                    shouldUnlock = true;
                }
               }else{
                    if(checkCompleted.hasClass("is-visited")){
                        shouldUnlock = true;
                    }
               }

               if(shouldUnlock){
                    $(this).removeClass("is-disabled");
               }


            });
        },

        applyAccessibility: function(el, isOpen) {
			//console.log("applayAccessibility "+isOpen);
            var focusEl = $('[class*=-focus]', el),
                tabEls = $('.notOverlay,input,select,textarea,button,object,button,a,[tabindex]'), //converting to tabbable element a button input 

                self = this;
            el.removeClass('is-selected');
            //focus the target for accessibility
            if ($(window).width() > 768) {
                if (focusEl.length > 0) {
                    focusEl.focus();
                } else {
                    //el.focus();
					el.children(":first").attr("tabindex",0).focus();
                }
            }

            //since 1.0 make header and main content not arrow-able 
            if (isOpen) {
                $(".navbar").attr('tabindex', '-1').attr('aria-hidden', 'true');
                $(".main").attr('tabindex', '-1').attr('aria-hidden', 'true');
                $(".footbar").attr('tabindex', '-1').attr('aria-hidden', 'true');
            } else {
                $(".navbar").removeAttr('tabindex').removeAttr('aria-hidden');
                $(".main").removeAttr('tabindex').removeAttr('aria-hidden');
                $(".footbar").removeAttr('tabindex').removeAttr('aria-hidden');
            }

            //Added tabbable elements 
            //restrict tabindex in overlay      
            tabEls.each(function() {
                if (self.type == "overlay" && $(this).is(":visible") && $(this).closest(".overlay,.tip,body[class*=dialog-]").length == 0) {
                    var tabindex = $(this).attr('tabindex');
					//console.log($(this));
					//console.log(tabindex);
                    if (tabindex) {
                        if (isOpen) {
                            if (tabindex == 0) {
                                $(this).attr('tabindex', '-9827').attr('aria-hidden', 'true'); //if a tab index is 0 set it to a random number
                            } else if(tabindex > 0){
                                $(this).attr('tabindex', '-' + tabindex).attr('aria-hidden', 'true');
                            }

                        } else {
                            if (tabindex == "-9827") {
                                $(this).attr('tabindex', '0').removeAttr('aria-hidden');
                            } else if (tabindex == "-7561") {
                                $(this).removeAttr('tabindex').removeAttr('aria-hidden');
                            } else {
                                $(this).attr('tabindex', tabindex.substring(1)).removeAttr('aria-hidden');
                            }

                        }
                    } else {
                        //for a tags / btns etc
                        if (isOpen) {
                            $(this).attr('tabindex', '-7561').attr('aria-hidden', 'true'); //another random number because its easy and i m hungry @sundar
                        }
                    }

                }
            });
        },
        delegateCloseEvent: function() {
            var self = this;
            $('body').on('click', self.selector.close, function(e) {
                e.preventDefault();
                self.hide($($(this).data('revealObject')));
            });



        }
    });
})(window.$ || window.JQuery);

/* 

old example 

2) html structure for type: "tooltip":
popup:
<aside id="pop2" data-reveal-target="tooltip">
     ...
 <a href="#" class="tip-close" tabindex="204" data-reveal-type="pop-close" data-reveal-object="#pop7" >
     <span class="icon-close"></span>
 </a>
</aside>
button:
<button data-reveal-type="tooltip" data-reveal-object="#pop2">...</button>

3) html structure for type: "dialog": (use bootstrap dialog)
popup:
<div class="modal fade" id="popup-dialog" role="dialog" data-backdrop="static" data-keyboard="false" data-reveal-target="pop-dialog">
     <div class="modal-dialog" tabindex="300">
       <div class="modal-content">
         <div class="modal-header">
           <button type="button" class="close" data-dismiss="modal" aria-label="Close" tabindex="302"><span aria-hidden="true">&times;</span></button>
           <h4 class="modal-title"></h4>
         </div>
        <div class="modal-body" tabindex="301"></div>
      </div>
    </div>
</div>
button:  
<button data-reveal-type="dialog" data-reveal-data="#pop2" data-reveal-object="#popup-dialog" data-toggle="modal" data-target="#popup-dialog"></button>
 
 */
