(function($) {
    "use strict";

    /**
     * todo: convert to a template . So that the preloader gets compiled
     * @type {*}
     */

     //audio
    window.bazingaApp.views.audioView = window.bazingaApp.views.abstractComponentView.extend({
        el: $("audio:not(.js-prevent-interaction)"),

        initialize: function() {
            this.componentType = 'audio';
        },
        load: function() {
            var deferred = $.Deferred(),
                transcript = $(".js-transcript"),
				transcriptText = $(".transcript"),
                self = this,
                type = 'onStart',
                data,
                onComplete = function(mediaObj) {
					console.log("audio onComplete");
					//console.log(self.getIsCompleted());
                    if (!self.getIsCompleted()) {
					
						//console.log("media index: ");
						//console.log(mediaObj);
						//console.log(mediaObj.target.id);
						//console.log(this.$el.data());
						if(mediaObj != undefined){
							$("#"+mediaObj.target.id).addClass("is-completed");
							if($("#"+mediaObj.target.id).closest(".mediaContainer")){
								$("#"+mediaObj.target.id).closest(".mediaContainer").addClass("is-completed");
							}
						}
						
                        deferred.resolve();
						if($("audio").length == $("audio.is-completed").length ){
                        self.completed = "completed";
                        self.trigger('completed:audio', self);
						}
                    }
					
                };
			
			//console.log("ytest");
			//console.log(this.$el);

            if (this.$el.length == 0 || typeof this.$el.mediaelementplayer !== 'function') {
                this.enabled = false;
                setTimeout(function() {
                    deferred.fail();
                }, 200);
            } else {
				
                data = this.$el.data();
                data.features = data.features ? (data.features.split(',')) : ['playpause', 'progress', 'volume'];
                if (data.mediaType) { type = data.mediaType; }

                _.defaults(data, {
                    success: function(media, node, player) {
                        // do something when audio starts
                        // add event listener
                        if (type == 'onFinish') {
                            media.addEventListener('ended', onComplete);
                        } else {
                            media.addEventListener('playing', onComplete);
                        }

                    }
                });

                self.player = this.$el.mediaelementplayer(data);
				
				/*if(self.player.attr('data-transcript-btn')){
						transcript = $(self.player.attr('data-transcript-btn'));
					}
				
				console.log("transcriptBtn");
				console.log(transcript);*/

                //since 1.0 optional audio
                if (self.player.hasClass("optional")) {
                    //onComplete(this.index());
					//console.log("is optional audio");
					self.completed = "completed";
                        self.trigger('completed:audio', self);
					
					//if has optional, disable tracking of audio 
					this.enabled = false;
                setTimeout(function() {
                    deferred.fail();
                }, 200);
					
                }

                //has image slide show with audio
                if (self.player.data("slideshow") == "1") {

                    console.log("id: "+self.player[0].id);
                    console.log(self.player.index());
					
					var playerIndex = self.player.index();
					var oniPad = false;
					if(playerIndex <0){
						playerIndex = 0; // shows as -1 on ipad	?
						oniPad = true;
					}

                    var slideshowInterval = setInterval(

                        function() {
                        var currentTime = self.player[playerIndex].currentTime;
                        if(currentTime == undefined || oniPad){
                            //ie 8
                            currentTime = self.player[playerIndex].player.media.currentTime;
                        }
						
						/*console.log("-----------------");
                    	console.log(self);
                    	console.log(self.player);
                        console.log("index: ");
						console.log(self.player[playerIndex]);
                        console.log("id: "+self.player[playerIndex].id);
                        console.log("time:");
                        console.log(currentTime);*/

                        //resize slideshow

                        //if($(".imgSlideshow").hasClass("height100")){
                          //  console.log("has class");
                            $(".height100").height($("html").height());
                        //}


                        if (currentTime != 0) {
                            var imgFound = false;
                            $("div[data-audio='" + self.player[0].id + "'] .imgSlide").each(function(index) {
                                var time = $(this).data("time");
                                //console.log(currentTime);
								
								if(index == ($("div[data-audio='" + self.player[0].id + "'] .imgSlide").length -1) ){
									//last one
									if(time < currentTime){
									console.log("last one " +currentTime);
									imgFound = true;
									$(this).fadeIn();
									}else{
										$(this).fadeOut();
									}
								}if (time > currentTime) {
                                    //console.log("imgFound "+imgFound);
                                    if (!imgFound) {
                                        imgFound = true;
                                        $(this).prev().fadeIn();
                                        //console.log("fade in");
                                    } else {
                                        $(this).prev().fadeOut();
                                       //console.log("fade out");
                                    }
                                }
                            });
                        }
							
							
                    }

                        , 500);
                }

                // Transcript Button
                if ($(transcript).length) {
					
					//console.log("transcriptText");
					//console.log(transcriptText);
					
                    transcript.on("click", function(event) {
						//console.log("audio btn pressed");
						
						//console.log($(this));
						
						if($(this).attr('data-transcript')){
							transcriptText = $($(this).attr('data-transcript'));
						}
						
						console.log(transcriptText);
						
						event.stopImmediatePropagation();
                        onComplete(this.index);
                        if ($(this).hasClass("is-enabled")) {
                            $(this).removeClass("is-enabled");
							//transcript.removeClass("is-enabled");
                            //$(".transcript").slideUp();
							transcriptText.slideUp();
                        } else {
                            $(this).addClass("is-enabled");
							//transcript.addClass("is-enabled");
                            //$(".transcript").slideDown();
							transcriptText.slideDown();
                            $(".transcript-focus").attr("tabindex", 0).focus();
                        }
						
						
                    })
                }
				
            }

            $(".flashContainer").mousedown(function() {
                console.log("flash clicked");
                    window.bazingaApp.models.navigation.setPageCompletion('completed');
                    $('[data-enable-on-complete]').removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
        });

            return deferred.promise();
        },

        play: function() {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.play();
                //console.log("playyyyyyyyyyyyy");
            }
        },
        pause: function() {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.player.pause();
            }
        },
        resetSource: function(src) {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.pause();
                player.setSrc(src);
                player.play();
            }
        },
        enable: function() {
            this.$el.show();
            return this;
        },
        disable: function() {
            this.$el.hide();
            return this;
        }

    });

    //video

    window.bazingaApp.views.videoView = window.bazingaApp.views.abstractComponentView.extend({
        el: $("video:not(.js-prevent-interaction)"),
        initialize: function() {
            this.componentType = 'video';
        },
        load: function() {
            var deferred = $.Deferred(),
                transcript = $(".js-transcript"),
				transcriptText = $(".transcript"),
                data,
                self = this,
                type = 'onStart',
                data,
                onComplete = function(mediaObj) {
                    if (!self.getIsCompleted()) {
						
						if(mediaObj != undefined){
							//console.log("id: ");
							//console.log($("#"+mediaObj.target.id));
						$("#"+mediaObj.target.id).addClass("is-completed");
							
							if($("#"+mediaObj.target.id).closest(".mediaContainer")){
								$("#"+mediaObj.target.id).closest(".mediaContainer").addClass("is-completed");
							}
							
						}
						
                        deferred.resolve(); 

                        if($("video").length == $("video.is-completed").length ){
                        self.completed = "completed";
                        self.trigger('completed:video', self);
                        }

                        
                    }
                };

            if (this.$el.length == 0 || typeof this.$el.mediaelementplayer !== 'function') {
                this.enabled = false;
                setTimeout(function() { deferred.fail(); }, 200);
            } else {
                data = this.$el.data();
                data.features = data.features ? (data.features.split(',')) : ['playpause', 'progress', 'fullscreen'];
                type = data.mediaType || 'onStart';
				
                _.defaults(data, {
                    success: function(media, node, player) {
                        // do something when audio starts
                        // add event listener
                        if (type == 'onFinish') {
                            media.addEventListener('ended', onComplete);

                        } else {
                            media.addEventListener('playing', onComplete);
                        }

                    }
                });
                self.player = this.$el.mediaelementplayer(data);
				
                //console.log(self.player);
                // Transcript Button
                if ($(transcript).length) {
					
					if($(transcript).attr('data-transcript')){
						transcriptText = $($(transcript).attr('data-transcript'));
					}
					
                    transcript.on("click", function(event) {
						//console.log("video btn pressed");
						event.stopImmediatePropagation();
                        onComplete(this.index);
                        if (transcript.hasClass("is-enabled")) {
                            transcript.removeClass("is-enabled");
                            //$(".transcript").slideUp();
							transcriptText.slideUp();
                        } else {
                            transcript.addClass("is-enabled");
                            //$(".transcript").slideDown();
							transcriptText.slideDown();
                        }
						
                    })
                }
            }
			
			if(self.player){
			if (self.player.hasClass("optional")) {
                    //onComplete(this.index());
					//console.log("is optional audio");
					self.completed = "completed";
                        self.trigger('completed:completed', self);
					
					//if has optional, disable tracking of audio 
					this.enabled = false;
                setTimeout(function() {
                    deferred.fail();
                }, 200);
					
                }
			}

            $(".flashContainer").mousedown(function() {
               // console.log("flash clicked");
                    window.bazingaApp.models.navigation.setPageCompletion('completed');
                    $('[data-enable-on-complete]').removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
        });


            return deferred.promise();
        },
        play: function() {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.play();
            }
        },
        pause: function() {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.player.pause();
            }
        },
        resetSource: function(src) {
            if (this.player.length > 0) {
                var player = _.first(this.player);
                player.pause();
                player.setSrc(src);
                player.play();
            }
        },
        enable: function() {
            this.$el.show();
            return this;
        },
        disable: function() {
            this.$el.hide();
            return this;
        }

    });
})(window.$ || window.JQuery);
