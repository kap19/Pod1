(function($) {
    "use strict";
	
	//checkbox manaager
    window.bazingaApp.views.checkboxManager = window.bazingaApp.views.abstractComponentView.extend({
        checkboxes: [],
        cbIdentifier: '[data-cbid]',
        showNeutralFeedback: false,
        autoComplete: false,
		handled:false,
        cbType: 'single',
		minOptions:false,
        trackable: true,
		maxOptions:0,
        partials: {
            type: 'of',
            tgt: null
        },
        correct: [],
        totalWeightage: 0,
        state: "not-attempted",
        getState: function() {
            return this.state;
        },
        getIsTrackable: function() {
            return this.trackable;
        },
        initialize: function() {
            _.bindAll(this, 'load', 'randomize', 'loadCheckboxes', 'recalculate', 'show', 'hide');
        },
        selectOrder: [],
        definedOrder: [],
        feedbacks: {
            show: null,
            hide: null
        },
        animations: 'fade',
		
        recalculate: function(e) {
			
			//console.log("recalculate");
			
            if (e && e.target && ($(e.target).hasClass('is-disabled'))) {
                e.stopPropagation();
                return false;
            }	

            var self = this,
                correct = self.correct,
                neutral = self.neutral,
                allCheckboxes = self.$el.find(self.cbIdentifier),
                answers = {
                    "correct": [],
                    "wrong": []
                },
                score = 0,
                score_max = self.totalWeightage,
                allIds = [],
                i = 0,
                fb = 'naf',
				addClass = "",
				courseConfig = window.bazingaApp.models.api.getCourseConfig(),
				accessibilityVersion = _.has(courseConfig,'accessibilityVersion') ? courseConfig['accessibilityVersion'] : 1;
			
			if(self.submitButton){
			self.submitButton.addClass('is-submitted');
			}else{
				return false;
				//no submit button
			}
			
            if (self.resetButton) {
                self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
            }

            if (!self.autoComplete) {
                self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
            }

            allCheckboxes.addClass('is-disabled').off('click');

            if (self.cbType == 'order') {
                _.each(self.definedOrder, function(v) {
                    var ix = self.selectOrder[i++];
					if(ix != undefined){
                    allIds.push(v.id);
					}
					//console.log(ix);
					//console.log(allIds);
					//console.log(v);
					//console.log("---");

                    if (v.id == ix && ix != undefined) {

                        answers.correct.push(ix);
                    } else {
                        answers.wrong.push(ix);
                    }
                });
            } else {
                _.each(allCheckboxes, function(cb) {
                    var $cb = $(cb),
                        id = "" + $cb.data('cbid'),
						assistText = (function(){
                            var assistText = $cb.find(".a11y-assist-text");
                            if(assistText.length > 0){
                                return assistText;     
                            }
                            $cb.append("<div class='a11y-assist-text'></div>")                            
                            assistText = $cb.find(".a11y-assist-text");
                            return assistText; 
                        }()),
                        isCorrect = (_.indexOf(correct, id) > -1),
					
                        isChecked = $cb.hasClass('is-selected'),
                        showIfCorrect = $cb.data('showIfCorrect'),
                        showIfWrong = $cb.data('showIfWrong');

                    allIds.push(id);
                    $cb.addClass(isCorrect ? 'is-correct' : 'is-wrong');
					assistText.text(isCorrect ? 'Correct answer' : 'Incorrect answer'); //Needed for IE 

                    if ((isCorrect && isChecked) || (!isCorrect && !isChecked)) {
                        answers.correct.push(id);
                        if(showIfCorrect){
                            self.show($(showIfCorrect),null,100);
                        }
                        $cb.addClass('is-answered-correct');
                        score += parseInt($(cb).data('weight') || 1);
                    } else {
                        $cb.addClass('is-answered-wrong');
                        if(showIfWrong){
                            self.show($(showIfWrong),null,100);
                        }
                        answers.wrong.push(id);
                    }
                });
            }

			console.log(answers.correct);
			console.log(answers.wrong);

            var ret = {
                target: self,
                answers: answers,
                allIds: allIds,
                score: score,
                score_max: score_max,
                percentage: ((score / score_max) * 100)
            };


            if (allIds.length == answers.correct.length) {
                ret.state = self.state = "passed";
            } else {
                //trigger neutral
                if (self.partials.tgt) {
                    if (self.partials.type == 'of') {
                        if (answers.correct.length >= self.partials.tgt[0]) {
                            ret.state = 'partial';
                        } else {
                            ret.state = 'failed';
                        }
                    } else if (self.partials.type == 'in') {
                        var overlap = _.intersection(self.partials.tgt, answers.correct);
                        if (!_.isEmpty(overlap) && (overlap.length == self.partials.tgt.length)) {
                            ret.state = 'partial';
                        } else {
                            ret.state = 'failed';
                        }
                    } else {
                        if (ret.percentage >= parseInt((self.partials.tgt[0] || 50))) {
                            ret.state = 'partial';
                        } else {
                            ret.state = 'failed';
                        }
                    }
                } else {
                    ret.state = 'failed';
                }
            }
            fb = '[data-caf]';
			
			
            if (self.showNeutralFeedback) {
				console.log("show neutral feedback");
                fb = '[data-naf]';
				
				//console.log();
				
				if($(".checkbox.is-selected").data("feedbackId") != undefined){
				if($(".checkbox.is-selected").data("feedbackId").length > 0){
					
					fb = '[data-'+$(".checkbox.is-selected").data("feedbackId")+']';
					var $selectedCheckbox = $(".checkbox.is-selected");
					var fbClass = $selectedCheckbox.attr('data-add-class') || "";
					//console.log("fb");
					//console.log(fb);
					
					var $fb = $(fb);
					
					if(fbClass != ""){
						//$cb.addClass(fbClass);
						//$fb.addClass(fbClass); //mw needs testing
						$fb.parent().addClass(fbClass);
					}
					//console.log(fb);
				}
				}else{
					console.log("ERROR. neutral feedback but feedbackId not defined");
				}
            } else {
                if (ret.state == 'passed') {
                    fb = '[data-caf]';
					addClass = $(self.$el[0].getAttribute('data-correct-class')) || "";
                } else if (ret.state == 'failed') {
                    fb = '[data-waf]';
					addClass = $(self.$el[0].getAttribute('data-incorrect-class')) || "";
                } else {
                    fb = '[data-pcaf]';
                }
            }
			
            if (self.feedbacks.show) {
				//console.log("showFeedback");
				//console.log(self);
				self.feedbacks.show = $(self.$el[0].getAttribute('data-feedback-show-selector')); //.dataset.feedbackShowSelector doesn't work in ie9
				//console.log(self.feedbacks.show);
				//added to target individual feedbacks
				
                self.show(self.feedbacks.show.find(fb, null, 100));

                var showFeedback = function(callback) {
					
					//console.log(self.feedbacks);
					//console.log(self.feedbacks.show);
                        self.show(self.feedbacks.show, callback);
					
					
					
					var jump = $(self.$el[0].getAttribute('data-jump-to-feedback'));
					
					var fbId = self.feedbacks.show[0].id;
					var $fb = $("#"+fbId);
					//console.log("add class");
					//console.log(addClass.selector);
					
					if(jump){
						
						$('html,body').animate({
        			scrollTop: $fb.offset().top});
					}
					
						if(addClass != ""){
							$fb.addClass(addClass.selector);
						}
                    },
                    hideFeedback = function(callback) {
						//console.log("hideFeedback");
                        if (self.feedbacks.length == 0 || !_.has(self.feedbacks, "hide") || self.feedbacks.hide.length == 0) {
							//console.log("no feedbacks hide");
                            callback();
                        } else {
							//console.log("recalculate hide the feedback");
							//console.log(self.feedbacks.hide);
							self.feedbacks.hide = $(self.$el[0].getAttribute('data-feedback-hide-selector'));
							
                            self.hide(self.feedbacks.hide, callback);
						
							//self.hide(self.$el.context.attributes["data-feedback-hide-Selector"], callback);
							
                        }
                    };


                if (self.animateOrder == 'hideShow') {
					//console.log("animateOrder hideShow");
                    hideFeedback(function() {
                        showFeedback(function() {
                        	var el = self.feedbacks.show,
                        		navBar = $('.navbar');
                            self.trigger("completed:checkbox", ret);
                            //nice to have: scroll to feedback section on mobile view
							if($(window).width()<767&&el.hasClass("js-scrollTop")){
								$("html,body").animate({scrollTop:el.offset().top-navBar.outerHeight()},500,function(){
									if(accessibilityVersion >= 2){
									el.find(fb).find('[tabindex]:first').focus();
									}
								});
							}
							
							//since 1.0 add  even on desktop for accessibility
							if(accessibilityVersion  >= 2){
							el.find(fb).find('[tabindex]:first').focus();
							}
                        });
                    });
                } else {
                    showFeedback(function() {
						
                        hideFeedback(function() {
                            self.trigger("completed:checkbox", ret);
							if(accessibilityVersion  >= 2){
                            self.feedbacks.show.find(fb).find('[tabindex]:first').focus();
							}
                        });
                    });
                }
            } else {
                setTimeout(function() {
                    self.trigger("completed:checkbox", ret)
                }, 20);
                console.log("No feedbacks located. SO event was triggered");
            }

            self.completed = 'completed';
        },

        show: function(element, callback, delay) {
            var self = this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 300;


            if (typeof callback !== 'function') {
                callback = function() {}
            }

            switch (classOverride) {
                case "fade":
                case "fadeinout":
                    promise = element.fadeIn(delay, callback);
                    //promise = element.fadeIn(delay, callback).css("display","inline-block");
                    break;

                case "slideUp":
                case "slideUpDown":
                    promise = element.slideUp(delay, callback);
                    break;

                case "slideDown":
                case "slideDownUp":
                    promise = element.slideDown(delay, callback);
                    break;

                default:
                    promise = element.show(delay, callback);
                    break;
            }

            return promise;
        },
        hide: function(element, callback, delay) {
			
			//console.log(element);
			
            var self = this,
                promise,
                classOverride = element.data('animationHide') || self.animations;

            delay = delay || 600;

            if (typeof callback !== 'function') {
                callback = function() {}
            }

			//console.log("hide "+classOverride+ " "+delay);
			
			//console.log(element);
			//console.log(element.data('animationHide'));

            switch (classOverride) {
                case "fade":
                case "fadeinout":
                    promise = element.fadeOut(delay, callback);
                    break;

                case "slideUp":
                case "slideDownUp":
                    promise = element.slideUp(delay, callback);
                    break;

                /*case "slideDown":
                case "slideUpDown":
                    promise = element.slideDown(delay, callback); //not working?
                    break;*/

                default:
					delay = 0;
                    promise = element.hide(delay, callback);
                    break;
            }

            return promise;
        },
        loadCheckboxes: function(reload) {
			//console.log("loadCheckboxes");
            reload = reload === false ? false : true;

            if (reload) {
                this.checkboxes = [];
            };


            var self = this,
                i = 1,
                checkboxes = this.$el.find(this.cbIdentifier),
                
                
                clickHandler = function(e) {
					console.log("checkbox clickHandler");
                    if (e && e.target && ($(e.target).hasClass('is-disabled'))) {
                        e.stopPropagation();
                        return false;
                    }
				
                    var tgt = e.target,
                        $target = $(tgt),
                        data,
                        id,
                        totalCheckboxes = self.checkboxes.length,
                        notSelected;

                    data = $target.data();
                    id = data.cbid; 
					
					//show/hides when clicked on the checkboxes themselves

                    if (_.has(data, 'showSelector') && data.showSelector) {
                        self.show($(data.showSelector));
                    }
                    if (_.has(data, 'hideSelector') && data.hideSelector) {
                        self.hide($(data.hideSelector));
                    }


                    if ($target.hasClass('is-selected')) {
                        $target.removeClass('is-selected').attr("aria-checked",false);

                        //set up order
                        if (self.cbType == 'order') {
                            //remove the id from the list if it is not selected

                            var currentIx = _.indexOf(self.selectOrder, id);
                            if (currentIx > -1) {
                                //remove the current select order
                                self.selectOrder = _.reject(self.selectOrder, function(num) {
                                    return (("" + num) == ("" + id));
                                });
                                $target.find('[data-cb-selected-order]').remove();


                                //redo other select orders
                                _.each(self.selectOrder, function(so) {
                                    var soOb = $('[data-cbid="' + so + '"]').find('[data-cb-selected-order]'),
                                        selectedOrder = (soOb.data('cbSelectedOrder'));

                                    selectedOrder = parseInt(selectedOrder);
                                    if (!_.isNaN(selectedOrder) && selectedOrder > currentIx) {
                                        selectedOrder = (selectedOrder - 1);

                                        soOb.data('cbSelectedOrder', ("" + selectedOrder)).html(("" + selectedOrder));

                                    }
                                });
                            }

                        }
                    } else {
                        if (self.cbType == 'single') {
                            self.$el.find(self.cbIdentifier).removeClass('is-selected').attr("aria-checked",false);
                           
                        }
						
						console.log($('.checkbox.is-selected').length+"/"+self.maxOptions);
						
						if (self.maxOptions > 0 && ($('.checkbox.is-selected').length == self.maxOptions)) {
                        	//reached limit of options
						}else{
							//selet checkbox
							$target.addClass('is-selected').attr("aria-checked",true);
						}

                        //set up order
                        if (self.cbType == 'order') {
                            if (_.indexOf(self.selectOrder, id) < 0) {
                                self.selectOrder.push(id);
                                $target.find('.icon-checkbox').html('<div class="cb--order" data-cb-selected-order="' + self.selectOrder.length + '">' + self.selectOrder.length + '</div>');
                            }
                        }
                    }

                    if (self.autoComplete) {
                        self.recalculate();
                    } else {
                        notSelected = self.$el.find(self.cbIdentifier).not('.is-selected').length;

                        if (self.cbType == 'order') {
							console.log("ordering checkbox");
							
							var minOptionsReached = false;
							
							if(self.minOptions){
									var numSelected = totalCheckboxes - notSelected;
									if(numSelected >= eval(self.minOptions)){
										minOptionsReached = true;
									}
							}
							
                            if (notSelected == 0 || minOptionsReached) {
                                console.log("no checkboxes selected");
                                self.submitButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                            } else {
                                self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                            }

                            if (totalCheckboxes == notSelected) {
                                if (self.resetButton) {
                                    self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                                }
                            } else {
                                if (self.resetButton) {
                                    self.resetButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                                }
                            }
                        } else {
							
                            if (totalCheckboxes == notSelected) {
                                console.log("no checkboxes selected");
                                self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                                if (self.resetButton) {
                                    self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                                }
                            } else {
                                console.log("some checkboxes selected");
								
								if(self.minOptions){
								   //only enable submit button if enough checkboxes are selected
									var numSelected = totalCheckboxes - notSelected;
									
									var correctAnswersString = self.correct;
									
									//console.log(correctAnswersString); //undfined
									
									if(numSelected != correctAnswersString.length){
										//number selection not matching number of correct answers
										self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
										
										return false;
										
									}
								   
								   }
								
                                self.submitButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
								
                                if (self.resetButton) {
                                    self.resetButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                                }
                            }
                        }

                    }
                };


            self.selectOrder = [];

            if (checkboxes.length == 0) {
                console.error("Unable to load checkboxes. no data-cbids exists");
            }



            _.each(checkboxes, function(cb) {
                var $cb = $(cb),
                    id = $cb.data('cbid'),
                    showIfCorrect = $cb.data('showIfCorrect'),
                    showIfWrong = $cb.data('showIfWrong');

                //load the assist text for the checkboxes
                //$cb.find(".a11y-assist-text").html("Not Selected");

                
                if(showIfCorrect){
                    $(showIfCorrect).hide();
                }
                if(showIfWrong){
                    $(showIfWrong).hide();
                }
				
				
                $cb.on("click", function(e) {
					
					/*if($(this).hasClass("is-disabled")){
						return false;
					}*/
					
					//this needs to be tested on office ipad
					self.handled = false;
					
					console.log(e.type);
					console.log(self.handled);
					if(e.type == "touchend"){
						e.target = (this);
						clickHandler(e);
						self.handled = true;
					}else if(e.type == "click" && !self.handled){
						console.log("clicked");
						e.target = (this);
						clickHandler(e);
						self.handled = true;
					}
                });

                if (reload) {
                    self.definedOrder.push({
                        id: id,
                        order: ($cb.data('order') || i++)
                    });
                    self.checkboxes.push({
                        id: $(cb).data('cbid'),
                        $el: $cb,
                        weight: ($(cb).data('weight') || 1)
                    });

                }
            });

            self.definedOrder = _.sortBy(self.definedOrder, function(o) {
                return o.order;
            });
            self.totalWeightage = (_.reduce(self.checkboxes, function(memo, cb) {
                return cb.weight + memo;
            }, 0));

        },
        randomize: function() {
            var self = this;

            if (self.checkboxes.length == 0) {
                return false;
            }

            self.$el.empty();
            self.checkboxes = _.shuffle(self.checkboxes);

            _.each(self.checkboxes, function(cb) {
                self.$el.append(cb.$el);
            });

            self.loadCheckboxes(false);
        },
        load: function($el) {
            this.$el = $el;

            var data = this.$el.data(),
                self = this,
                allowPartials = false;

            this.loadCheckboxes();
			
			console.log("loadCheckboxes");

            if (!(_.has(data, 'correct'))) {
                //Always load neutral response feedback
                self.showNeutralFeedback = true;
                console.log("[Checkbox Message] no correct answers. showNeutralFeedback");
            } else {
                self.correct = ((data.correct + "") || "").split(',');
            }
			
			if (_.has(data, 'cbType')) {
				//console.log("has cbtype");
				if($.inArray(data.cbType, ['multiple', 'order']) >= -1){
                self.cbType = data.cbType;
			}
            }else{
				//console.log("no cbtype, get correct length:"+self.correct);
				
				//work out if multiple automatically
				if(self.correct.length > 1){
					//console.log("auto calculate to multiple");
					self.cbType = 'multiple';
				}
			}

            if (!_.has(data, 'submit')) {
                self.autoComplete = true;
                console.log("[Checkbox Message] No submit button mentioned. Checkbox will auto complete");
            } else {
                self.submitButton = $(data.submit);
				if (_.has(data, 'minOptions') && (data.minOptions != "0")) {
                self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
				}
                self.submitButton.on("click touchend", self.recalculate);
            }

            if (_.has(data, 'reset')) {
                self.resetButton = $(data.reset);
                self.resetButton.removeClass('is-disabled').attr("aria-disabled",false).attr("disabled",false);
                self.resetButton.on("click touchend", function(e) {
                    if ($(e.currentTarget).hasClass('is-disabled')) {
                        return false;
                    }

                    self.submitButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
                    self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);

                    self.selectOrder = [];
                    if (self.cbType == 'order') {
                        $('[data-cb-selected-order]').remove();

                    }

                    self.$el.find(self.cbIdentifier)
                        .removeClass('is-selected')
                        .removeClass('is-correct')
                        .removeClass('is-wrong');
                });

                self.resetButton.addClass('is-disabled').attr("aria-disabled",true).attr("disabled",true);
            }


            self.animateOrder = (_.has(data, 'animateOrder') && data.animateOrder == 'showHide') ? data.animateOrder : "hideShow";

            if (_.has(data, 'partialOn')) {
                allowPartials = (data.partialOn == '1');
            }

            if (_.has(data, 'animations')) {
                self.animations = data.animations;
            }
            if (_.has(data, 'animation')) {
                self.animations = data.animation;
            }
			
			if (_.has(data, 'max')) {
                self.maxOptions = data.max;
            }
			
			//console.log("max "+self.maxOptions);

            if (allowPartials && _.has(data, 'partials') && data.partials) {
                self.partials.type = data.partialType || 'of';
                self.partials.tgt = ("" + (data.partials || "")).split(',');
            }
			
			//console.log("data.randomize");
			//console.log(data.randomize);

            if (_.has(data, 'randomize') && (data.randomize != "0")) {
				//console.log("RANDOM");
                this.randomize();
            }
			
			if (_.has(data, 'minOptions') && (data.minOptions != "0")) {
				this.minOptions = true;
				if(data.minOptions !== ""){
					this.minOptions = data.minOptions;
				}
				console.log("MINOPTIONS "+this.minOptions);
			}

            if (!_.has(data, 'feedbackShowSelector')) {
                console.log("[CHECKBOXES] NO FEEDBACK SELECTOR IN DATA TAG>. NO FEEDBACKS WILL BE SHOWN BY THE CHECKBOX");
            } else {
                self.feedbacks.show = $(data.feedbackShowSelector);
				
				//console.log("has feedbackShowSelector");
				//console.log(self.feedbacks.show);
				//overrides each other
				
                if (self.feedbacks.show.length == 0) {
                    console.log("[CHECKBOXES] FEEDBACK NOT LOCATED");
                }
				
                self.feedbacks.hide = $(data.feedbackHideSelector);
				//console.log("self.feedbacks.hide");
				//console.log(self.feedbacks.hide);
				//self.feedbacks.hide = self.$el.context.attributes["data-feedback-hide-Selector"];
				
				//console.log("self.feedbacks.hide");
				//console.log(self.$el.context.attributes);
				//console.log("self.$el.context.attributes.data-feedback-hide-selector");
				//console.log(self.$el.context.attributes["data-feedback-hide-Selector"]);

                self.hide(self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]"));
                self.hide(self.feedbacks.show);
                //self.feedbacks.show.find("[data-caf], [data-waf], [data-naf], [data-pcaf]").hide();
                //self.feedbacks.show.hide();
            }

            if (_.has(data, 'preventTrack') && data.preventTrack) {
                self.trackable = false;
            }

			//console.log(self.feedbacks);

        }
    });

	var submitPressed = false;
	
//checkbox
    window.bazingaApp.views.checkboxView = window.bazingaApp.views.abstractComponentView.extend({
        el: '[data-checkbox]:not(.js-prevent-interaction)',
        cbEl: '.checkbox',
        feedbacks: null,
        allow: {
            randomize: true
        },
        cbList: [],
        events: {
        },
		
        initialize: function() {
            if (this.$el.length == 0) {
                this.enabled = false;
            }

            this.componentType = 'checkboxes';
            var self = this,
                //Recalculate the completion of all child components
                //If all the children are completed , the completed event is triggered and this is tracked by appView
                recalculate = function(e) {
					
					//console.log("init recalculate");
					
					//console.log(self.cbList);
					
                    var todo = 0;
                    _.each(self.trackables, function(v) {
                        if (v.getIsCompleted()) {
                            return false;
                        }

                        todo++;
                    });

                    //console.log("recalculate init todo: "+todo);
                    if (todo == 0) {
                        self.completed = 'completed';
                        //trigger event for appview
                        self.trigger('completed:checkboxes', self, e);
						//return;
                    }
					
					
                };

            this.trackables = [];


            _.each(this.$el, function(el,index) {
                var $el = $(el),
                    cbManager = new window.bazingaApp.views.checkboxManager();
				
				
                //Loop through each of the child components and make sure all the components are loaded 
                cbManager.on("completed:checkbox", function(e) {
					
                    recalculate(e);
                });
                cbManager.load($el);

                //If the child component is trackable then then track it 
                if (cbManager.getIsTrackable()) {
                    self.trackables.push(cbManager);
                }

                self.cbList.push(cbManager);
            });



        },
        setAllow: function(allow) {
            this.allow = _.extend(this.allow, allow);
            return this;
        }

    });
})(window.$ || window.JQuery);
