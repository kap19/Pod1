(function ($) {
    "use strict";
	/**
     * checkpoint module. Different options will bring you to different path.
     * complete the page once one of the option has been choosed.
     *
     */
    window.bazingaApp.views.checkPointView = window.bazingaApp.views.abstractComponentView.extend({
        el: $('[data-type=checkpoint]'),
        events: {
            "click": "recalculate"
        },
        initialize: function () {
            _.bindAll(this, 'recalculate');
            if(this.$el.length == 0){
                this.enabled = false;
                this.completed= 'completed';
            }
            else{
                this.completed = "incomplete";
            }
        },
        recalculate: function (e) {
            var self = this,
                completed = self.completed = self.completed || false,
                el = $(e.target),
                forwardBtn = $('.footbar [data-goto]:eq(0)');
			
			if(forwardBtn.length == 0){return;}
			
			//remove all "is-selected" class from all other options except itself
			self.$el.not(e.target).removeClass('is-selected');
			el.addClass('is-selected');
			
			self.completed = 'completed';
			self.trigger('completed:checkpoint',self);
			
			forwardBtn.attr('data-goto',el.attr('data-checkpoint-goto'));
			
            return self;
        }
    });
})(window.$ || window.JQuery);