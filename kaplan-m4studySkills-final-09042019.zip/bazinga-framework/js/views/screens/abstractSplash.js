(function(){
    window.bazingaApp.views.abstractSplash =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            $('[tabindex]:first').focus();
        }
    });

}());