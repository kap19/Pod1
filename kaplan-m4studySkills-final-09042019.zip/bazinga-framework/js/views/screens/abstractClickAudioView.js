(function(){
    window.bazingaApp.views.abstractClickAudioView =window.bazingaApp.views.appView.extend({
        el:$('#js-app'),
        abstractLoads : function(){
            //console.log(window.bazingaApp.models.api.getCourseConfig());
            var footer = $(".footbar"),
                tabIndexNum = "850",
                playButton = footer.find(".mejs-playpause-button").children().first(),
                volumeButton = footer.find(".mejs-volume-button").children().first(),
                itemsArr = [playButton, volumeButton],
                self=this,
                i,
                courseConfig = window.bazingaApp.models.api.getCourseConfig(),
                accessibilityVersion = _.has(courseConfig,'accessibilityVersion') ? courseConfig['accessibilityVersion'] : 1;

            if(accessibilityVersion  >= 2){
                //do stuff for custom module accessibility
                tabIndexNum =  '0';
            }
            //start page level js here


            $('[data-audio-play]').click(function(elem) {
                var $elem = $(elem), data = $elem.data();

                if($elem.hasClass('is-disabled')){return false;}

                $elem.addClass('is-disabled');

                if(_.has(data,'src') && self.audio){
                    self.audio.resetSrc(data.src);
                }
                else{
                    //self.audio.play();
                    playButton.click().focus();
                    $('[data-audio-play]').unbind("click");

                }
            });

            // Fixing tabindex for player
            for (i=0; i<itemsArr.length; i++) {
                itemsArr[i].attr("tabindex", tabIndexNum);
            }

            // skip to content /local
            //$(".js-skip-link").click(function() { $(".js-skip-focus").focus() });
        },

        onReSize: function () {
            /*var vidWidth = $("#v-player").width();
            //console.log(vidWidth);
            var ratio = $("#v-player").attr("data-height");
            //console.log(ratio);
            var ratioNum = eval(ratio);
            //console.log(ratioNum);

            var newHeight = ratioNum * vidWidth;

            console.log(newHeight);

            $("#v-player object.flashVideo").attr("height",newHeight);*/
        }

    });

}());