(function($) {
	"use strict";
	$(function() {
		/**
         * control the visibility of global navigation bar
         */
		var conbinationMenu = $('#js-dropdown-mobile'),
		    mainMenu = $('#js-dropdown-mobile > ul:first-child'),
		    subMenu = $('#js-dropdown');
		function setVisibility() {
			if ($(window).width() <= 768) {//mobile
				conbinationMenu.addClass('collapse');//in mobile view, conbinationMenu should be hidden
				if (subMenu.hasClass('in')) {//if submenu has already opened in largeScreen
					conbinationMenu.addClass('collapse in');
				}
			} else {//large screen
				conbinationMenu.removeClass('collapse in');//in large screen, conbinationMenu should be shown
				if (conbinationMenu.hasClass('in')) {//conbinationMenu has already opened in mobile
					subMenu.addClass('collapse in');
				}
			}
		}

		//detect on page load
		setVisibility();
		//detect on window resize
		$(window).on('resize', function() {
			setVisibility();
		});
		//ready for show, remove all hidden classes
		$('.navbar').on('show.bs.collapse', function() {
			if ($(window).width() <= 768) {
				$('#js-dropdown-mobile > ul', $(this)).addClass('in');
			}
		});
		//ready for hidden, remove all display classes
		$('.navbar').on('hidden.bs.collapse', function(e) {
			if ($(window).width() <= 768) {
				if(e.target.id == 'js-dropdown-mobile'){
					subMenu.removeClass('in');
					mainMenu.removeClass('in');
				}
			}else{
				conbinationMenu.removeClass('in');
			}
		});
	});
})(window.$ || window.JQuery); 