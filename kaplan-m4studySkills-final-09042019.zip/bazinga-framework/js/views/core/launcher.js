(function() {
        window.bazingaApp.views.launcherView = Backbone.View.extend({
                el: $('#js-app'),
                events: {},
                /**
                 * Load the application
                 */
                load: function() {
					
					//console.log("framework launcher load");
					
					function get_browser() {
                                var ua = navigator.userAgent,
                                    tem, M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
                                if (/trident/i.test(M[1])) {
                                    tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                                    return { name: 'IE', version: (tem[1] || '') };
                                }
                                if (M[1] === 'Chrome') {
                                    tem = ua.match(/\bOPR\/(\d+)/)
                                    if (tem != null) {
                                        return { name: 'Opera', version: tem[1] };
                                    }
                                }
                                M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
                                if ((tem = ua.match(/version\/(\d+)/i)) != null) { M.splice(1, 1, tem[1]); }
                                return {
                                    name: M[0],
                                    version: M[1]
                                };
                            }
					
					var browser = get_browser();
					
					//console.log(browser);
					
					 // IE9 console fix
					if(Number(browser.version) == 9){
						if(!window.console) {
							if (!window.console) window.console = {};
								if (!window.console.log) window.console.log = function () { };
						}
					}
				
					if (window.console) {
                    console.log("start launcherView");
					}
					
                    //self.backstretch = new window.bazingaApp.views.backstretchView();
                    self.preloader = new window.bazingaApp.views.preloaderView();
                    self.preloader.setLabel('Loading..').setPercentage(0);
                    self.popup = null;

					if (window.console) {
                    console.log(location.protocol + "//" + location.host);
					}
					 
					//get course config
                    $.getJSON("../config/config.json", function(courseConfig) {
							
                            courseConfig = _.defaults(courseConfig, {
                                "launchPage": "pages/splash.html",
                                "popup": false,
								"offline":false,
                                "popupWidth":"1012",
                                "popupHeight":"688",
								"offlineId":""
                            });
                            self.courseConfig = courseConfig;
						
						//offline id
						var offlineId = self.courseConfig.title.replace(/[^\w\s]|_/g, "");
						offlineId = offlineId.split(' ').join('');
						window.localStorage.setItem("offlineId", offlineId );
						console.log("set offlineId: "+offlineId);
						
                            }).error(function(){
						
						
												try {
							console.log("offline. use courseconfig.js");
												courseConfig = offlineConfig;
						}
						catch(err) {
							console.log("courseconfig.js DOES NOT EXIST");
						}
						  
						
					}).complete(function(){
						
							if (window.console) {
                            console.log("Launcher loading");
                            console.log("Settting local storage");
							}
							
                            //check if ie7 or less
                            
                            var oldBrowser = false;

                            if (browser.name == "MSIE" && Number(browser.version) < 8) {
                                oldBrowser = true;
                            }

                            if (self.courseConfig.popup) {
                                self.preloader
                                    .incrementTo(100, 10)
                                    .always(function() {
                                            var props = "width="+self.courseConfig.popupWidth+",height="+self.courseConfig.popupHeight+",resizable=no,status=no,toolbar=no,menubar=no,location=no",
                                                check;

                                            self.popup = window.open(self.courseConfig.launchPage, "", props);


                                            check = function() {
                                                setTimeout(function() {
                                                        if (self.popup && !self.popup.closed) {
                                                            check();
                                                        } else {
                                                            if (!oldBrowser) {
                                                                
                                                                    //window.location.replace(courseConfig.finishPage || 'finish.html'); //jumps to complete even if popup blocked
                                                                }
                                                            }
                                                        } ,
                                                        1000);
                                                };

												window.localStorage.setItem("firstLaunch", true);
                                                //if (window.focus) { self.popup.focus() } //breaks on ie9?
                                                check();
                                            });
                                    }
                                else {
                                    if (!oldBrowser) {
                                        console.log("compatible browser - firstLaunch");
                                        window.location.replace((courseConfig.launchPage || 'splash.html'));
                                        window.localStorage.setItem("firstLaunch", true);
                                    }
                                }
							console.log("complete");
					});
					
					
					
                    }
                });
        }());
