(function() {
    window.bazingaApp.views.appView = Backbone.View.extend({
        el: $('#js-app'),
        events: {
            "click [data-decision]": "gotoDecisionPoint",
            "click [data-goto]": "gotoDecisionById",
            "click [data-trigger]": "triggerData",
            "click [data-reattempt]": "reattempt",

            "touchend [data-decision]": "gotoDecisionPoint",
            "touchend [data-goto]": "gotoDecisionById",
            "touchend [data-trigger]": "triggerData",
            "touchend [data-reattempt]": "reattempt",
            "keydown": "keydown"
        },
        menu: {
            $el: $('#js-dropdown'),
            tabIndex: 4
        },

        initializeEvents: function($el) {
            var self = this;
            $el.find('[data-decision]').off("click touchend").on("click touchend", self.gotoDecisionPoint);
            $el.find('[data-goto]').off("click touchend").on("click touchend", self.gotoDecisionById);
            $el.find('[data-trigger]').off("click touchend").on("click touchend", self.triggerData);
        },

        reloadParentEvents: function() {
            //hack. this had to happen because the popup triggers were switching events off
            $('[data-goto]').on("click touchend", self.gotoDecisionById);
            $('[data-decision]').on("click touchend", self.gotoDecisionPoint);
            $('[data-trigger]').on("click touchend", self.triggerData);
        },
        /**
         * List of all interactions on screen
         * When there are interactions like checkboxes, they are automatically recognized.
         * Unless a force_screen_on_complete is true, you have to complete all interactions on screen before the screen completes
         */
        interactions: [],
        initialize: function() {
            var self = this;

            _.bindAll(this, 'goNext', 'gotoDecisionPoint', 'gotoDecisionById', 'triggerData', 'goto',
                'goBack', 'getBreadCrumbs', 'initializePageComponents', 'populateMenu', 'initializeAccessibility',
                'initializeMenu', 'onReSize', 'onLoad', 'onPageLoad', 'setTargets', 'initializeEvents', 'reloadParentEvents', 'keydown');


            this.on("completed:page", function(e) {
                //console.log("data-enable-on-complete " + $('[data-enable-on-complete]').length);
                
				
				var checkSaved = setInterval(function(){
					//console.log(window.bazingaApp.models.api.getPageCompletion());
				if(window.bazingaApp.models.api.getPageCompletion() == "c"){
                $('[data-enable-on-complete]').removeClass('is-disabled').attr("aria-disabled", false).attr("disabled",false);
						clearInterval(checkSaved);
				}
					}, 400);
				
            });
			
			

            this.initializePageComponents();
            this.initializeChild();


            /*$(window).on('beforeunload', function() {
                console.log("f:onbeforeunload");
                //self.exitcourse(); // mw why is this here? on page load, course exits sometimes
                });*/

            //Do not have a initialize function within your application.
            //Use Initialize child instead
        },


        /**
         * This function needs to be called for the screen to start initializing. THis allows all initializations to run before the init is called.
		 
         * Load the application
         */
        load: function() {
			
			//ie9 console not open hack
			if (!window.console) window.console = {};
			if (!window.console.log) window.console.log = function () { };
			
			if (window.console) {
            console.log("start loading application view");
			}
			
			//non commit cookie
			document.cookie = "finishLoad=no";
			
			var self = this;
            //self.backstretch = new window.bazingaApp.views.backstretchView();
            window.bazingaApp.preloader = self.preloader = new window.bazingaApp.views.preloaderView();

            window.bazingaApp.models.api = self.api = new window.bazingaApp.models.API();
			//console.log("set to 0");
            self.preloader.setLabel('Loading').setPercentage(0);
			
			console.log("getJSON appView");
			
            $.getJSON("../config/config.json", function(courseConfig) {
				
                //course config is now set up
				window.bazingaCourseConfig = self.courseConfig = courseConfig;
				//console.log("JSON");
				//console.log(courseConfig);
					
            }).error(function(courseConfig){
				
				if(offlineConfig != undefined){
					console.log("error: no use offlineConfig");
				window.bazingaCourseConfig = offlineConfig;
				self.courseConfig = offlineConfig;
				courseConfig = offlineConfig;
				}else{
					console.log("error: no offlineConfig");
				}
					
			}).complete(function(courseConfig){
				
				//console.log(window.bazingaCourseConfig);
				
                window.bazingaApp.models.api.once('initialize:dataModel', function() {
					//console.log("datamodel done. go to 10-----------------------------");
                    self.preloader.incrementTo(10);
                });
                window.bazingaApp.models.api.once('initialize:api', function() {
					//console.log("api done. go to 20-----------------------------------");
                    //doesn't actually trigger
					self.preloader.incrementTo(20);
                });
                window.bazingaApp.models.api.once('initialize:handshake', function() {
					//console.log("handshake done. go to 30------------------------------");
                    self.preloader.incrementTo(30);
                });
                window.bazingaApp.models.api.once('initialize:suspendData', function() {
                    self.preloader.incrementTo(40);
                });
                window.bazingaApp.models.api.once('initialize:page', function() {
                    self.preloader.incrementTo(50);
                });

                //The api loads the following
                //courseConfig
                //Nav file
                //Set up bread crumbs
                //Populates and renders menu
                //initializeAccessibility
                //Calls loaded

                window.bazingaApp.models.api
                    .load(courseConfig)
                    .always(self.onLoad);
					
					var courseConfig = window.bazingaApp.models.api.getCourseConfig();
			var debug = _.has(courseConfig,'debug') ? courseConfig['debug'] : true;
			
			//console.log("DEBUG :"+debug);

			if(!debug){
    if(!window.console) window.console = {};
    var methods = ["log", "debug", "warn", "info"];
    for(var i=0;i<methods.length;i++){
    	console[methods[i]] = function(){};
    }
}

//console.log("test start");
				
			});
        },

        onLoad: function() {
			//console.log("-on loadd");
            var self = this;

            self.pageConfig = (window.bazingaApp.models.api.getNavForScreen());

             if (self.pageConfig) {
                self.pageId = self.pageConfig.id;
                if (self.pageConfig.visibility) {
                    if (self.pageConfig.visibility.breadcrumbs) {
                        self.breadCrumbs = window.bazingaApp.models.api.getCrumbs();
                        self.$el.find('[data-bread-crumb]').html(self.getBreadCrumbs());
                    } else {
                        self.$el.find('[data-bread-crumb]').hide();
                    }
                    self.nav = window.bazingaApp.models.api.getNav();
                    self.menuData = self.populateMenu(self.nav);
					//console.log("self.self");
					//console.log(self.nav);
					
                    if (self.pageConfig.visibility && (!_.has(self.pageConfig.visibility, 'blockMenuRender') || self.pageConfig.visibility.blockMenuRender == false)) {
                        self.renderMenu();
                        //console.log("rendermenu");
                    }
                }

            }

			//console.log("-beforePageLoad");
			self.beforePageLoad();

			//console.log("-beforeAbstractLoad");
            self.beforeAbstractLoad();
			
			//console.log("-go to 100");
            self.preloader.incrementTo(100);
			
			document.cookie = "finishLoad=yes";
			
            self.initializeAccessibility();

            self.setTargets();
            self.onPageLoad();
            self.abstractLoads();
            self.loaded();

           	//manually save offline suspend data
			
			var offlineSuspend = "cmi.suspend_data."+window.bazingaApp.models.navigation.getOfflineId();
			//console.log("offline suspend "+offlineSuspend);
			
			if(window.localStorage.getItem(offlineSuspend) === null){
				
				//console.log("no offlineId in local storage.save now.");
				var oriSuspend = window.localStorage.getItem("cmi.suspend_data");
				window.localStorage.setItem(offlineSuspend,oriSuspend);
				//console.log(window.localStorage.getItem(offlineSuspend));
			}
			
			//console.log("force update suspend data~~~~~~~"); //only for non-dialog pages
			if(!window.bazingaApp.models.navigation.getIsDialog()){
				window.bazingaApp.models.navigation.updateSuspendData();
			}
            
        },


        keydown: function(e) {
            var self = this,
                $tgt,
                prevent = (function() {
                    if (e.ctrlKey || !self.pageConfig || !_.has(self.pageConfig, 'blockers') || !_.has(self.pageConfig.blockers, 'keys')) {
                        return false;
                    }
                    if (_.indexOf(self.pageConfig.blockers.keys, ('' + e.which)) < 0) {
                        return false; }
                    //Do nothing
                    return true;
                })();

            if (prevent) {
                e.preventDefault();
                return false;
            }

            //Accessibility
            if (e.ctrlKey && (e.which === 39)) {
                self.goNext();
            }
            if (e.ctrlKey && (e.which === 37)) {
                self.goBack();
            }

            // accessibility
            $tgt = $(e.target);
            if ($tgt.hasClass('js-skip-link')) {
                if (e.which === 32 || e.which === 13) {
                    //since 1.0 fixed by Ali for pages with multiple skip targets
                    $(".js-skip-focus:visible:first").focus();
                }
            }


        },
        abstractLoads: function() {
            //Override this in abstract views
        },

        setTargets: function() {
            var suspendData = (window.bazingaApp.models.api.getSuspendData()),
                hashed = {
                    'completion': _('completion').getKeyHash(),
                    'completed': _('completed').getKeyHash(),
                    'passed': _('passed').getKeyHash(),
                    'incomplete': _('incomplete').getKeyHash()
                },
                lockables;

            if ($('[data-completion-target]').length !== 0) {
                $('[data-completion-target]').each(function() {

                    var $el = $(this),
                        data = $el.data('completionTarget'),
                        split,
                        completed = true,
                        isIncomplete = false;

                    if (!data) {
                        return true;
                    }
                    split = ("" + data).split(",");
                    if (split.length == 0) {
                        return true;
                    }


                    _.each(split, function(tgt) {
                        var sus = _.where(suspendData, { id: tgt });
                        //The completion loop failed before
                        if (!completed) {
                            return false; }

                        if (sus.length == 0) {
                            completed = false;
                            return false;
                        }
                        sus = _.first(sus);

                        if (!_.has(sus, hashed.completion) || !sus[hashed.completion] || ($.inArray(sus[hashed.completion], [hashed.completed, hashed.passed]) == -1)) {

                            completed = false;
                            return false;
                        }

                        completed = true;
                        return true;
                    });

                    if (completed) {
                        $el.addClass('is-completed');
                    } else {
                        $el.removeClass('is-completed');
                    }
                });

            }

			//add disabled class if pages are locked
            if ($('[data-locked-if]').length > 0) {
                lockables = (window.bazingaApp.models.api.getLockables());
                $('[data-locked-if]').each(function() {
                    var $el = $(this),
                        data = $el.data('lockedIf');

                    if (_.has(lockables, data) && lockables[data].locked == true) {
                        $el.addClass('is-disabled');
                    } else {
                        $el.removeClass('is-disabled');
                    }
                });
            }


            if ($('[data-available-pool]').length > 0) {
                var currentPool = ((window.bazingaApp.models.api.getCurrentPool()) + "");

                $('[data-available-pool]').each(function() {
                    var $el = $(this),
                        data = $el.data('availablePool'),
                        dataSplit;

                    dataSplit = (data && data != '') ? (data + "").split(',') : [];

                    if (dataSplit.length == 0) {
                        return true; }

                    console.log("IX " + _.indexOf(dataSplit, currentPool));
                    if (_.indexOf(dataSplit, "*") >= 0 || _.indexOf(dataSplit, currentPool) >= 0) {
                        //$el.show();
                        $el.fadeIn();
                    } else {
                        $el.hide();
                    }
                });
            }

        },
        beforePageLoad: function() {

        },
        beforeAbstractLoad: function() {

        },

        onPageLoad: function() {
            var gesture = $(".gesture"),
                count,
                mobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

            if (gesture.length > 0) {
                _.each(gesture, function(g) {
                    var $g = $(g);

                    if ($g.text() === "Click" && mobileDevice == true) {
                        $g.text("Tap");
                    } else if ($g.text() === "click" && mobileDevice == true) {
                        $g.text("tap");
                    }
                });
            }



            //If you override this function. make sure to call the super parent. Or you can just override the loaded function
            var self = this,
                previousCompletion = 'na',
                pageCount = window.bazingaApp.models.api.getPageCount(),
                hashed = {
                    completed: _('completed').getKeyHash(),
                    passed: _('passed').getKeyHash()
                },
                preventAutoComplete = !self.pageConfig || !self.pageConfig.track || _.has(self.pageConfig.track, 'manual_completion') || self.pageConfig.track.manual_completion;

            if (self.pageConfig && self.pageConfig.type !== 'page') {
                return this;
            }

            if (_.has(self.pageConfig, 'conditions') && _.has(self.pageConfig['conditions'], 'countIf')) {
                var handleCountFunctions = function(cnt) {
                        cnt = cnt || {};

                        if (_.has(cnt, 'onlyIf')) {
                            if (_.has(cnt.onlyIf, 'courseStatusCheck')) {
                                var courseCompletion = window.bazingaApp.models.api.getCourseCompletion();
                                if (cnt.onlyIf.courseStatusCheck.indexOf(courseCompletion) == -1) {
                                    //Fail return
                                    return;
                                }
                            }
                        }

                        if (cnt.show) {
                            $(cnt.show).fadeIn();
                        }
                        if (cnt.hide) {
                            $(cnt.hide).hide();
                        }

                        var score = 0,
                            status = "failed",
                            committable = [];



                        //Commit the score and status if the page has conditions
                        if (cnt.commitScore) {
                            var value = cnt.commitScore.value || "primary",
                                multiplier = cnt.commitScore.multiplier || 1;

                            switch (value) {
                                case 'primary':
                                    score = window.bazingaApp.models.api.getPrimaryScore() || 0;
                                    break;
                                case 'secondary':
                                    score = window.bazingaApp.models.api.getSecondaryScore() || 0;
                                    break;
                                case 'tertiary':
                                    score = window.bazingaApp.models.api.getTertiaryScore() || 0;
                                    break;
                                default:
                                    score = _.isNumber(cnt.commitScore) ? cnt.commitScore : 0;
                                    break;
                            }

                            committable.push({ key: 'score', value: (score * multiplier) });
                        }

                        if (cnt.commitStatus) {
                            var statusCondition = cnt.commitStatus,
                                masteryScore = statusCondition.masteryScore || 100,
                                type = statusCondition.type || "passed-failed";

                            if (type == "passed-failed") {
                                if (score <= masteryScore) {
                                    status = "failed";
                                } else {
                                    status = "passed";
                                }
                            } else {
                                if (score <= masteryScore) {
                                    status = "incomplete";
                                } else {
                                    status = "completed";
                                }
                            }

                            committable.push({ key: 'status', value: status });
                        }


                        if (committable.length !== 0) {
                            window.bazingaApp.models.api.setMultiple(committable);
                        }
                    }
                    //handle count based variables
                _.each(self.pageConfig['conditions']['countIf'], function(cnt) {
                    if (!cnt.condition || cnt.count === undefined) {
                        return true; }

                    var condition = cnt.condition || "=";

                    switch (condition) {
                        case "<":
                            if (pageCount < cnt.count) { handleCountFunctions(cnt); }
                            break;
                        case ">":
                            if (pageCount > cnt.count) { handleCountFunctions(cnt); }
                            break;
                        case "<=":
                            if (pageCount <= cnt.count) { handleCountFunctions(cnt); }
                            break;
                        case ">=":
                            if (pageCount >= cnt.count) { handleCountFunctions(cnt); }
                            break;
                        case "=":
                        default:
                            if (pageCount == cnt.count) { handleCountFunctions(cnt); }
                            break;
                    }
                });

            }
            previousCompletion = window.bazingaApp.models.api.getPageCompletion();

            previousCompletion = previousCompletion || 'na';

            //disable any thing that needs to be disabled on enter
            //since 1.0
            $('[data-disable-on-enter]').addClass('is-disabled').attr("aria-disabled", true).attr("disabled",true);
            //one time trigger
            if ($.inArray(previousCompletion, [hashed.completed, hashed.passed]) > -1 && !preventAutoComplete) {

                //No calculations necessary
                //page is already completed
                console.log("page is already complete");
				self.hideShowOnComplete();
                self.trigger("completed:page", self, { target: self });
                return this;
            }

            if (self.interactions.length == 0 && !preventAutoComplete) {
                console.info("No more interactions. Page completed . \\o//");
                window.bazingaApp.models.navigation.setPageCompletion('completed');
				self.hideShowOnComplete();
                self.trigger("completed:page", self, { target: self });
                return this;
            }



        },
        /**
         * @private : Do not change
         * @param menu
         * @returns {*}
         */
        setMenu: function(menu) {
            this.menu = menu;
            return this;
        },
        /**
         * Initialize all page components on screen
         */
        initializePageComponents: function() {
            //popup view
            var self = this,
                completionCheck = function(tgt, e) {
					console.log("completionCheck");
                    var tgtType = ((typeof tgt.getComponentType == 'function') ? tgt.getComponentType() : null);

                    tgt.off(null, completionCheck);
                    //for who ever wants to listen
                    self.trigger('completed:component', self, { target: tgt, source: e, tgtType: tgtType });
                    self.completionCheck(self, { target: tgt, source: e, tgtType: tgtType });

                    //Send page completion
                    if (tgt.getIsCompleted()) {
                        self.checkPageCompletion();
                    }

                    //trigger call to set the interactions here
                    if (typeof tgt.isInteractionType == 'function' && tgt.isInteractionType()) {
                        //call the api to set up interaction. THis will set up the id of the component and mark the interaction as complete
                        var interactionData = tgt.getInteractionData();

                        //todo : finish this off
                    }
                };

			//console.log("check to add interactions");

            //=======Audios===============
            self.audio = new window.bazingaApp.views.audioView();
            self.audio.load();

            if (self.audio.isEnabled()) {
                self.audio.on('completed:audio', completionCheck);
                this.interactions.push(self.audio);
				console.log("has audio");
				//this.interactions.push(self.audio);
            }

            //=======Videos===============
            self.video = new window.bazingaApp.views.videoView();
            self.video.load();

            if (self.video.isEnabled()) {
                this.interactions.push(self.video);
                self.video.on('completed:video', completionCheck);
                console.log(self.video.isEnabled() + " - video");
            }

            //=======Popups===============
            self.popup = new window.bazingaApp.views.popupView();
			//console.log("popuppp");
			//console.log(self.popup); //all popup buttons
            if (self.popup.isEnabled()) {
				//if(!self.popup.attr('data-prevent-track')){
				
				if(!self.popup.getIsCompleted()){
                this.interactions.push(self.popup);
				}
				
				//console.log("has popups");
				
				//}
                self.popup.on('completed:reveal', completionCheck);
                self.popup.on('data:popup', function(context, options) {
                    //if (!options) {
                      //  return false };
                    self.initializeEvents(options.$tgt);
                });
            }

            //=======Checkboxes===============
            self.checkboxes = new window.bazingaApp.views.checkboxView();
            if (self.checkboxes.isEnabled()) {
				console.log("has checkboxes");
                self.checkboxes.on('completed:checkboxes', completionCheck);
                this.interactions.push(self.checkboxes);
            }

            //=======FILLUPS===============
            self.fillups = new window.bazingaApp.views.fillupView();
            if (self.fillups.isEnabled()) {
				console.log("has fillups");
                self.fillups.on('completed:fillups', completionCheck);
                this.interactions.push(self.fillups);
            }


            //=======??s===============
            self.tick = new window.bazingaApp.views.tickView();
			
			//console.log(self);
			//console.log(self.tick);
			
            if (self.tick.isEnabled()) {
				console.log("has tick");
                self.tick.on('completed:tick', completionCheck);
                this.interactions.push(self.tick);
            }

            //=======Carousel===============
            self.carousel = new window.bazingaApp.views.carouselView();
            self.carousel.load();

            if (self.carousel.isEnabled()) {
				console.log("has carousel");
                this.interactions.push(self.carousel);
                self.carousel.on('completed:carousel', completionCheck);
            }

            //=======Checkpoint===============
            /*self.checkpoint = new window.bazingaApp.views.checkPointView();

            if (self.checkpoint.isEnabled()) {
				console.log("has checkpoint");
                this.interactions.push(self.checkpoint);
                self.checkpoint.on('completed:checkpoint', completionCheck);
            }*/

			//console.log("num interactions "+this.interactions.length);

            self.initializeChildComponents();


            //Hide any pool specific elements by default
            $('[data-available-pool]').hide();
        },

        /**
         * Checks to see if the page is completed.
         * Page is completed when all components in screen are completed
         * @returns {*}
         */
        checkPageCompletion: function() {
            console.log("check page completion. interactions: "+this.interactions.length);
			
			/*if($(".pageBlock").length){
				//console.log("multi-page page");
				var currentPageBlock = $( ".pageBlock:visible" );
				var newCurrentPageBlock = currentPageBlock.next();
				newCurrentPageBlock.show();
				
				var currentPageNum = newCurrentPageBlock.attr("data-pageNum");
				
				$('html,body').animate({
        			scrollTop: $("[data-pageNum="+currentPageNum +"]").offset().top},
        		'slow');
				
				window.bazingaApp.models.navigation.setParam4(currentPageNum);
				
			}*/
			
            //Checking page completion
            if (this.interactions.length == 0) {
                return true;
            }

            var self = this,
                completed = true,
                previousCompletion = window.bazingaApp.models.api.getPageCompletion(),
                hashed = {
                    completed: _('completed').getKeyHash(),
                    passed: _('passed').getKeyHash()
                };

            previousCompletion = previousCompletion || 'na';

            if ($.inArray(previousCompletion, [hashed.completed, hashed.passed]) > -1) {
                console.log("already completed before");
                self.hideShowOnComplete();
				self.whenPageCompletes();
                //No calculations necessary
                return this;
            }

            _.each(self.interactions, function(iteraction) {
                if (typeof iteraction.getIsCompleted !== 'function') {
                    //todo
                    console.error("FIX YOUR CODE! Something broke. get is completed doesn't exist in the component");
                }

                if (!iteraction.getIsCompleted()) {
					//console.log(iteraction);
					//console.log("an interaction is not completed");
                    completed = false;
                    return false;
                }
            });

            preventAutoComplete = !self.pageConfig || !self.pageConfig.track || _.has(self.pageConfig.track, 'manual_completion') || self.pageConfig.track.manual_completion;

            if (completed && !preventAutoComplete) {
                self.hideShowOnComplete();
                console.info("Page completed . \o/");
                window.bazingaApp.models.navigation.setPageCompletion('completed');
                self.trigger("completed:page", self, { target: self });
				
				self.whenPageCompletes();
            } else {
                window.bazingaApp.models.api.setPageCompletion('incomplete');
            }

            return this;
        },

        hideShowOnComplete: function() {
            if ($(".pageCompleteHide")[0]) {
                $(".pageCompleteHide").fadeOut(400,
                    function() {
                        $(".pageCompleteShow").fadeIn();
                    });
            } else {
                $(".pageCompleteShow").fadeIn();
            }
        },

        /**
         * can override
         */
        initializeAccessibility: function() {
            var self = this;
            //check the keydown function to add any keydown / class specific accessibility stuff
        },

        /**
         * Set up resize of the menu
         */
        initializeMenu: function() {
            // Menu Dropdown - done using screen height
            var self = this;
            $(window).on("resize", this.onReSize);
            self.onReSize();
        },

        //don't override this
        populateMenu: function(nav) {
            if (!this.menu || this.menu.$el.length == 0) {
                return false;
            }
            var self = this,
                menu = [],
                allPages = window.bazingaApp.models.api.getAllPages(),
                currentPool = window.bazingaApp.models.api.getCurrentPool();


            _.each(nav, function(v, k) {
                var m = (_.first(_.where(allPages, { id: k })));
                if (m && m.visibility && m.visibility.menu) {
                    if (!currentPool) {
                        menu.push(m);
                    } else {
                        if (!m.track || !m.track.pool || ((m.track.pool + "") === (currentPool + ""))) {
                            menu.push(m);
                        }
                    }
                }
            });


            return menu;
        },

        goNext: function() {
            var next = (window.bazingaApp.models.api.getDecision('next'));
            nextData = (window.bazingaApp.models.api.getNavForScreen(next || window.bazingaCourseConfig.defaultHome || 'home'));

            if (!nextData) {
                console.error("Next location not located");
            }

            window.location.replace(nextData.resource);
        },
        goBack: function() {
            var back = (window.bazingaApp.models.api.getDecision('back'));
            backData = (window.bazingaApp.models.api.getNavForScreen(back || window.bazingaCourseConfig.defaultHome || 'home'));

            if (!backData) {
                console.error("back location not located");
            }

            window.location.replace(backData.resource);
        },

        exitcourse: function() {
            (window.bazingaApp.models.api.shutDown())
            return this;
        },

        goto: function(decision) {
            var self = this,
                decisionData;

            if (!decision) {
                return false;
            }
			
			console.log("goto. decision:");
				console.log(decision);
			
            decisionData = (window.bazingaApp.models.api.getNavForScreen(decision || window.bazingaCourseConfig.defaultHome || 'home'));
			
				//console.log("goto. decisionData:");
				//console.log(decisionData);

            if (!decisionData || !decisionData.resource) {
				
				console.log("doesn't work");
				
                decisionData = (window.bazingaApp.models.api.getNavForDialog(decision));
				
				if(decision == "currentScreen"){
					//used on dialog resources
				decisionData = window.bazingaApp.models.api.getNavForScreen(window.bazingaApp.models.navigation.get('previousScreen'));
					
				console.log(decisionData);
			}
				
                if (!decisionData || !decisionData.resource) {
                    return false;
                }
            }

            window.location.replace(decisionData.resource);
            return self;
        },
        triggerData: function(e) {
            var self = this,
                $target = $(e.currentTarget),
                decision = $target.data('trigger');

            if (!decision) {
                return false;
            }


            if (typeof self[decision] == 'function') {
                //self[decision].apply(self, $target.data()); 
				//changed to 'call'. reason: http://stackoverflow.com/questions/5988326/uncaught-typeerror-function-prototype-apply-arguments-list-has-wrong-type
				
				self[decision].call(self, $target.data());
				
            }

        },
        gotoDecisionById: function(e) {
            var $target = $(e.currentTarget),
                decision = $target.data('goto'),
                decisionData;


            if ($target.hasClass('is-disabled')) {
                return false;
            }


            if (!decision) {
                return false;
            }
            return this.goto(decision);
        },
        gotoDecisionPoint: function(e) {
            var $target = $(e.currentTarget),
                decision = $target.data('decision'),
                decision = (window.bazingaApp.models.api.getDecision(decision)),
                decisionData;
				
				console.log("gotoDecisionPoint "+decision);
				
            if ($target.hasClass('is-disabled')) {
                return false;
            }
            return this.goto(decision);
        },


        //=====================================================================================
        //=========================END PRIVATE FUNCTIONS====================
        //=====================================================================================

        /**
         * Anything below here can be overrided in child pages
         *
         */
        onReSize: function() {
            var windowHeight = $(window).height(),
                menuHeight = windowHeight - 115;

            // console.log("ON RESIZE height being reset on menu");
            //$(".navbar-navigation").css("height", menuHeight);
        },

        loaded: function() {
            //override this on your page view
            console.log("loaded");
        },
        render: function() {

        },
        completionCheck: function(context, options) {
            //Override this for checking which component gets completed
        },
        initializeChild: function() {
            //override this
        },
        initializeChildComponents: function() {
            //override this
        },
        whenPageCompletes: function() {
            //override this
        },

        /**
         * This will return AEC type bread crumbs (Topic Name Page 1 of 6)
         * @returns {string}
         */
            getBreadCrumbs: function() {
            //Override this and use this
            var self = this,
                crumbs = self.breadCrumbs,
                first,
                listItems = null,
                crumbString = '',
                ix;


            if (!crumbs) {
                return "";
            }


            if (crumbs.length == 0) {
                return "<strong>" + self.pageConfig.title + "</strong>";
            }

            first = (_.first(crumbs));

            if (!first) {
                return "";
            }

            listItems = (_.filter(first.items, function(it) {
                return it.visibility && it.visibility.breadcrumbs;
            }));


            ix = (_.findIndex(listItems, function(it) {
                return "" + it.id == "" + self.pageId;
            }));

            var txt = first.title ? (first.title + " -") : "";

            if (ix == -1) {
                return "<strong>" + txt + "</strong>";
            }

            crumbString = "<strong>" + txt + "</strong> <span class='page'> Page </span>" + (ix + 1) + " <span class='of'>of</span> " + listItems.length;
            return crumbString;
        },
        reattempt: function(e) {
			console.log("reattempt");
            var target = e.currentTarget,
                $target = $(target),
                self = this,
                promise;

            if ($target.data('reattempt') == 'current') {
                promise = window.bazingaApp.models.api.reattemptScreen();
                if (promise) {
                    promise.always(function() {
                        if ($target.data('reattemptThenGoto')) {
                            self.goto($target.data('reattemptThenGoto'));
                        }
                    });
                }
            }
        },
		getLanguage:function(){
			
			//console.log("get language from ");
			//console.log(bazingaCourseConfig);
			//use the default language in course config
			if (typeof bazingaCourseConfig.language != "undefined") {
				//console.log("not undefined. it's "+bazingaCourseConfig.language);
				langExt = bazingaCourseConfig.language;
				window.bazingaApp.models.api.setLang(bazingaCourseConfig.language);
			}
			
			if(window.bazingaApp.models.api.getLang() == "en" || window.bazingaApp.models.api.getLang() == "null"){
									langExt = "";
							}
		},
        /**
         * render the menu / you can override this
         * @returns {*}
         */
        renderMenu: function() {
			
            var self = this,
                menu = self.menuData,
                allHtml = "",
                listIt,
                hashed = {
                    "completion": _('completion').getKeyHash(),
                    "completed": _('completed').getKeyHash(),
                    "passed": _('passed').getKeyHash()
                },
                //since 1.0
                courseConfig = window.bazingaApp.models.api.getCourseConfig(),
				langExt = window.bazingaApp.models.api.getLang(),
                accessibilityVersion = (_.has(courseConfig, 'accessibilityVersion') ? courseConfig['accessibilityVersion'] : 1),
                suspendData = window.bazingaApp.models.api.getSuspendData(),
                lockables = (window.bazingaApp.models.api.getLockables()),
                renderSubMenu = function(items) {
					//console.log("renderSubMenu items");
					//console.log(lockables);
					//console.log(items);
                    var html = "",
                        listItems = (_.filter(items, function(it) {
                            return it && it.visibility && it.visibility.menu;
                        }));
					//console.log(listItems);

                    if (listItems.length == 0) {
                        return false;
                    }
					
					self.getLanguage();
					
					//console.log("render menu suspend data");
					//console.log(suspendData);

                    _.each(listItems, function(v, k) {

                        //console.log(listItems); //only items in groups
						
						/*console.log(v);
						console.log("check "+v.id);
						console.log(v.track);
						console.log(v.track.completion);*/
						
                        var hasCompletion = (v.track && v.track.completion);
						//console.log("has completion");
						//console.log(hasCompletion);
                         var pageSuspendData = hasCompletion ? _.first(_.where(suspendData, { id: v.id })) : false,
                            isCompleted = true;
						
                        if (!pageSuspendData || !pageSuspendData[hashed.completion] || (!$.inArray(pageSuspendData[hashed.completion], [hashed.completed, hashed.passed]) == -1) || pageSuspendData.a =="i" || pageSuspendData.a =="n") {
							
                            //not attempted or incomplete
                            isCompleted = false;
                        }
						
						//override because setpagecomplete was not actually changing track.completion
						if(window.bazingaApp.models.api.getPageCompletion(v.id) == "c"){
							isCompleted = true;
						}
						
						//console.log("Teststestt:");
						//console.log(isCompleted);
						
						var subSub = "";
						
						//console.log(v.id +" "+v.type);
						
						if(v.type == "group"){
							//console.log(v.id+" is group (subsubgroup)");
							
							subSub = '<ul id="js-dropdown-' + v.id + '" class="dropdown-level-3 collapse" >';
							
							for(var i=0;i<v.items.length;i++){
								
								//var page = v.items[i];
								//console.log(page);
								//console.log(courseConfig.language);
								//console.log("lang ext "+langExt);
								
								if(window.bazingaApp.models.api.getPageCompletion(v.items[i].id) == "c"){
									isCompleted = true;
								}else{
									isCompleted = false;
								}
								
								subSub += 
									'<li><a href="#" data-sub-menu="1" class="dropdown-button' + (isCompleted ? ' is-completed' : '') + '"' +
                             ' data-goto="' + v.items[i].id + '"> <span class="icon-tick"><span class="a11y-assist-text">- completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + v.items[i]["title"+langExt] + '</a></li>'
							}
								
								subSub += '</ul>';
							
							//console.log(subSub);
							
						}
						
						if(v.type == "group"){
							
							//console.log(v.id + " still group");
							//console.log(v.crumbs[0]);
							
							//is sub sub group, button that opens sub sub menu
							html += '<li class="subSubGroup"><a role="button" data-toggle="collapse" data-parent="#js-dropdown' +'-'+ v.crumbs[0] + '"' +
                                'href="#js-dropdown-' + v.id + '" aria-expanded="true" aria-controls="js-dropdown-' + v.id + '" ' +
                                'class="dropdown-button dropdown-button--topic menu--level1 ' + (isCompleted ? 'is-completed' : '') + '" tabindex="' + self.menu.tabIndex + '"><span class="icon-tick"></span>' + v["title"+langExt] + '</a> '+ subSub + '</li>';
						}else{
							/*console.log(v.id + " not group");*/
							//console.log(v);
							//mw
							
							var isPageLocked = false;
							
							if (_.has(lockables, v.id) && lockables[v.id].locked == true) {
								//console.log(v.id +" is locked");	
								isPageLocked = true;
							}
							
							html += '<li>' +
                            '<a href="#" data-sub-menu="1" class="dropdown-button ' + (isCompleted ? 'is-completed' : '') +(isPageLocked ? 'is-disabled' : '') + '"' +
                            ' tabindex="' + self.menu.tabIndex + '" data-goto="' + v.id + '"> <span class="icon-tick"><span class="a11y-assist-text">- completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + v["title"+langExt] + '</a>' +
                            '</li>';
						}
						

                    });

                    return html;
                }; // end submenu


            self.menu.$el.empty();
            //since 1.0
            if (accessibilityVersion >= 2) {
                self.menu.tabIndex = "0";
            }
			
			//repeated from above
					if(window.bazingaApp.models.api.getLang() == "en" || window.bazingaApp.models.api.getLang() == "null"){
									langExt = "";
							}

            listIt = (_.filter(menu, function(it) {
                return it && it.visibility && it.visibility.menu;
            }));
			
			//console.log("-- start rendermenu --");
            _.each(listIt, function(v, k) { //k is index
				/*console.log(listIt);
				console.log(v.id);
				console.log("track:"+v.track+". completion:"+v.track.completion);*/

                var hasCompletion = (v.track && v.track.completion),
                    pageSuspendData = hasCompletion ? _.first(_.where(suspendData, { id: v.id })) : false,
                    isCompleted = true,
                    subMenu;

                if (!pageSuspendData || !_.has(pageSuspendData, hashed.completion) || ($.inArray(pageSuspendData[hashed.completion], [hashed.completed, hashed.passed]) < 0)) {

                    isCompleted = false;
                }

                //console.log("v.items");
                //console.log(v.items);
				//items in group
                var filtered = _.filter(v.items, function(it) {
					//it = individual item page, v is a group
                    //console.log("it");
                    //console.log(it);
                        return it && it.visibility && it.visibility.menu;
                    }),

                    isDisabled = (function() {
                        if (_.has(lockables, v.id) && lockables[v.id].locked == true) {
                            return true;
                        }
                        return false;
                    }());

                    //console.log("filtered.length "+filtered.length); 

                if (filtered.length > 1) {
                    allHtml += "<li id='"+v.id+"' class='panel'>";
					
					//console.log(v);

                    if (isDisabled) {
                        //render as a disabled button
                        allHtml += '<a href="#"  class="dropdown-button menu--level1 is-disabled ' + (isCompleted ? 'is-completed' : '') + '"' +
                            ' tabindex="' + self.menu.tabIndex + '">' + v["title"+langExt] + '<span class="icon-tick"><span class="a11y-assist-text">Is completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + '</a>';

                    } else {
						/*console.log("about to renderSubMenu");
						console.log(v);
						console.log(v.items);*/
                        subMenu = renderSubMenu(v.items);
                        if (subMenu) {
                            allHtml += '<a role="button" data-toggle="collapse" data-parent="#js-dropdown' /*+'-'+ v.id*/ + '"' +
                                'href="#js-dropdown-' + v.id + '" aria-expanded="true" aria-controls="js-dropdown-' + v.id + '" ' +
                                'class="dropdown-button dropdown-button--topic menu--level1 ' + (isCompleted ? 'is-completed' : '') + '" tabindex="' + self.menu.tabIndex + '"><span class="icon-tick"></span>' + v["title"+langExt] + '</a>';


                            if (v.items && _.isArray(v.items) && v.items.length > 0) {
                                allHtml += '<ul id="js-dropdown-' + v.id + '" class="dropdown-level-2 collapse panel" >';
                                allHtml += subMenu;
                                allHtml += '</ul>';
                            }
                        }
                    }

                    allHtml += "</li>"

                } else if (filtered.length == 1 || filtered.length == 0) {

                    var first = _.first(v.items);
					
					/*console.log("first");
					console.log(v);
					console.log(langExt);*/
                    if(filtered.length == 0){ //not in a group
                       first = v;
                }
					
                    if (isDisabled) {
                        //render as a disabled button
                        allHtml += '<li>' +
                            '<a href="#"  aria-disabled="true" disabled class="dropdown-button menu--level1 is-disabled ' + (isCompleted ? 'is-completed' : '') + '"' +
                            ' tabindex="' + self.menu.tabIndex + '"> <span class="icon-tick"><span class="a11y-assist-text">Is completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + v["title"+langExt] + '</a>' +
                            '</li>';
                    } else {
                        //render as a button
                        allHtml += '<li>' +
                            '<a href="#"  data-sub-menu="1" class="dropdown-button menu--level1 ' + (isCompleted ? 'is-completed' : '') + '"' +
                            ' tabindex="' + self.menu.tabIndex + '"data-goto="' + first.id + '"> <span class="icon-tick"><span class="a11y-assist-text">Is completed</span></span> <span class="icon-lock"><span class="a11y-assist-text">- locked</span></span>' + v["title"+langExt] + '</a>' +
                            '</li>';
                    }
                }


            });

            self.menu.$el.html(allHtml);

            if (self.menu.$el.find('[data-sub-menu]').length) {
                self.menu.$el.find('[data-sub-menu]').on('click touchend', function(e) {
                    self.gotoDecisionById(e);
                });
            }

            self.initializeMenu();
            return self;
        } // end rendermenu

    });

}());
