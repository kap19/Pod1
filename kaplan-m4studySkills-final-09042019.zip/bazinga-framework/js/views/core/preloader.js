(function($){
    "use strict";

    /**
     * todo: convert to a template . So that the preloader gets compiled
     * @type {*}
     */
    window.bazingaApp.views.preloaderView = Backbone.View.extend({
        el:$("[data-preloader='1']"),
        selector : {
            'icon':"[data-icon]",
            'label':"[data-label]",
            'percentage':"[data-percentage]"
        },

        show : {
            'label':true,
            "percentage":true,
            "icon":true,
            "symbol" : "%"
        },

        shown : true,
        label : "Loading..",
        percentage : 0,
        delay : 15,


        initialize:function(){
            this.$el.find(this.selector.label).text(this.label);
            this.$el.find(this.selector.percentage).text(this.percentage);
            this.resetVisibleElements();
            _.bindAll(this, 'setPercentage', 'incrementTo');
        },
        setLabel : function(label){
            this.label = label;
            this.$el.find(this.selector.label).text(label);
            return this;
        },
        setPercentage : function(percentage){
            this.percentage = percentage;
            this.$el.find(this.selector.percentage).text(percentage + this.show.symbol);
            if(percentage == 100){
                this.shown = false;
                this.$el.hide();
            }
            else{
                if(!this.shown){
                    this.$el.show();
                    this.shown = true;
                }
            }
            return this;
        },

        incrementTo : function(incrementTo,delay){
            var current = this.percentage,
                self = this,
                interval,
                deferred = $.Deferred();
                delay = delay || self.delay || 30;

                interval = setInterval(function(){
                    if(current > 100){
                        current = 100;
                    }
                    else if(current > incrementTo){
                        current = incrementTo;
                    }
                    if(current == 100 || current == incrementTo /*|| incrementTo == 100*/){
						//preloader finished
                        clearInterval(interval);
                        deferred.resolve();
						//self.setPercentage(100); maybe change this to 100 if incrementTo is 100
                        return false;
                    }
                    current +=10; //1
                    self.setPercentage(current);
					//console.log("incrementinggggg "+current+"/"+incrementTo);
                },delay);

                return deferred.promise();
        },
        resetVisibleElements: function(){
            if(this.show.icon){
                this.$el.find(this.selector.icon).show();
            }
            else{
                this.$el.find(this.selector.icon).hide();
            }

            if(this.show.percentage){
                this.$el.find(this.selector.percentage).show();
            }
            else{
                this.$el.find(this.selector.percentage).hide();
            }

            if(this.show.label){
                this.$el.find(this.selector.label).show();
            }
            else{
                this.$el.find(this.selector.label).hide();
            }

            return this;
        },
        setShow : function(show){
            _.extend(this.show,show );
            return this.resetVisibleElements();
        },

        enable : function(){
            this.$el.show();
            return this;
        },
        disable : function(){
            this.$el.hide();
            return this;
        }

    });
})(window.$||window.JQuery);