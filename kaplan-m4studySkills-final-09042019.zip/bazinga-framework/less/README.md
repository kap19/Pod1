## LESS VERSIONING

/* old - moved to bazingathemes folder
Bazinga 1.0.0 - First edition of the framework, Author: @cory_mayfield

Bazinga 1.0.1 - AEC APS version of the framework, Author: @cory_mayfield

Bazinga 1.1.0 - AEC CEA version of the framework, Author: @cory_mayfield, Editors: @markwong
*/

Bazinga 2.0.0 - AEC fork to custom version of the framework, Author: @markwong

Bazinga 3.0.0 - Rewrite of framework with striped back Bootstrap 3.3.6 and variables, Author: @cory_mayfield

4.0.0 ???