var headerHTML = '<div class="navbar">     <!--Skip to Content-->     <!--<a href="#js-skip-focus" class="a11y-skip-link js-skip-link">Skip to content</a>-->     <!--Logo-->     <!--<a href="home.html" class="logo">--><img src="../bazinga-framework/theme/kaplan-study/img/logo.png" alt="Kaplan Professional" class="logo"><!--</a>--> <img src="../bazinga-framework/theme/kaplan-study/img/build-your-skillls-logo.png" class="buildYourSkillsLogo" alt="Build your skills logo">'+
	'<button id="menuBtn" href="#navContainer" class="navigation-button collapsed">         <span class="a11y-assist-text">Menu</span>          <span class="a11y-assist-text assist-expand">- expand</span><span class="a11y-assist-text assist-collapse">- collapse</span></button>     </div> '+
	'<div class="errorPrompt u-hidden"><div class="errorText">error</div><img src="../bazinga-framework/theme/kaplan-study/img/popup-triangle.png" alt=""></div>'+
	'<img src="../bazinga-framework/theme/kaplan-study/img/dummy-next.png" class="dummyNext" alt=""/>';

var navHTML = '<div id="navContainer"><div id="navContainer2"><button class="navCloseBtn u-unstyled-button" href="#navContainer"><span class="a11y-assist-text">close</span></button><ul id="js-dropdown" class="navigation-dropdown panel-group" role="navigation"></ul><div class="links"><a href="#" data-goto="dh" class="supportLink" >Support</a><a href="#" data-goto="dex" class="exitLink">Exit</a></div></div></div>';

if(document.getElementById("navOverlay")){
	console.log("has navOverlay");
	document.getElementById("navOverlay").innerHTML = navHTML;
}

var footerHTML = '<ul class="list-page-navigation pull-right u-unstyled-list"><li>         <a href="#" class="footbar-button backBtn" data-decision="back">             <img alt="Back" src="../img/btn-back.png">         </a></li><li id="nextBtnContainer"></li></ul> ';