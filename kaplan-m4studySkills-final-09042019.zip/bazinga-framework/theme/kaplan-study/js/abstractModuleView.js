(function () {
	window.bazingaApp.views.abstractModuleView = window.bazingaApp.views.appView.extend({

		beforePageLoad: function () {
			var self = this;
			
			var initScroll = false;
			var scrolling = false;
			
			$("#headerContainer").append(headerHTML);

			$("#js-dropdown li:first-child").addClass("first");

				//$("#js-dropdown").appendTo("#navContainer");
				//$('.breadcrumb').html(self.getBreadCrumbs());
				//self.renderMenu();

			/*$("#footerContainer").append(footerHTML);
				$("#nextBtn").appendTo("#nextBtnContainer").removeClass("u-hidden");
				if ($("body").hasClass("assessment")) {
					$(".backBtn").remove();
				}*/
			
			/*$("#menuBtn,#closeNavBtn").on("click", function () {

				$("#megamenu").fadeToggle();

			});*/
			
			//load page
			
			$(window).resize(function() {
				//console.log("resize "+$(window).height());
				$('.pageBlock').css({'height': $(window).height()}); //window.innerHeight
				
			});
			
			/*$(window).scroll(function(){
				
				$('.svgSlide').each(function(i, obj) {
				//console.log($(this).width());
				//$(this).css({'margin-left': (window.innerWidth - $(this).width())/2});
					
				});
				
			});
			
			$(window).trigger('scroll');*/
			
			pageNum = parseInt(self.getQueryVariable("p")) || window.bazingaApp.models.navigation.getParam4() || 1;
			window.bazingaApp.models.navigation.setParam4(pageNum);

			console.log("pageNum is "+pageNum);
			
			//$("[data-pageNum="+pageNum+"]").show();

			
				
			
			$( ".pageBlock" ).each(function() {
				var thisPageNum = $(this).attr("data-pageNum");
				//console.log(thisPageNum+"/"+pageNum);

				if($(this).hasClass("nonePageBlock")){
					$(this).find(".nextPageBlock").removeClass("is-disabled").removeAttr("disabled");
					//$(".dummyNext").hide();
				}

				if(parseInt(thisPageNum) == pageNum){

					console.log("EQUALS. set id currentPageBlock");

					$(".pageBlock"+thisPageNum).show().attr("id","currentPageBlock");

					var preId = $("body").attr("data-pre-id") || 1;
				var currentPageId = preId + "" + pageNum;

				console.log("currentPageId: "+currentPageId);

					if($("#currentPageBlock").hasClass("nonePageBlock") || window.bazingaApp.models.api.getPageCompletion(currentPageId) =="c"){
					self.unlockNext();


				}

					console.log("show "+thisPageNum);
					//setTimeout(function(){

						var pageScrollHeight = document.getElementById("currentPageBlock").scrollHeight;

						var pageAttrHeight = parseInt($("#currentPageBlock").css('height').slice(0,-2));

						console.log("initial height:"+ pageScrollHeight + " "+ pageAttrHeight );

						$("#currentPageBlock .mejs-container").fadeIn("fast");

					/*if( pageScrollHeight > pageAttrHeight && (pageScrollHeight - pageAttrHeight ) > 1 ){
						// +1 before for some reason ie11 adds 1 to scrollHeight 
						console.log("make next relative");
						$("#currentPageBlock").find(".nextPageBlock").addClass("relative");
					}*/

				//}, 100);

				}
			});

			
			

			//if no page matches, show the last one

			if($(".pageBlock:visible").length == 0){
					$(".pageBlock"+$(".pageBlock").length).show().attr("id","currentPageBlock");
			}

			self.checkTopicComplete();

			$(document).on( "click touchstart", function(event) {

				console.log("doc click");

				var clicked = event.target;

				console.log(clicked);

				if(scrolling){
					return false;
				}

				//if($(clicked).attr("alt") == "next section" || $(clicked).hasClass("nextPageBlock")){
					if($(clicked).hasClass("dummyNext")){
					//console.log($(clicked).parents(".nextPageBlock"));

					//console.log($(clicked).parents(".pageBlock"));

					/*if($(clicked).hasClass("unlocked") || $(clicked).parents(".nextPageBlock").hasClass("unlocked") || $(clicked).parents(".pageBlock").hasClass("nonePageBlock")){
						//next button is unlocked or it's on a static page type
					}else{*/
					console.log("isDisabled");

					var errorTxt = "Complete the activity to progress";

					if($("#currentPageBlock").find(".imgSlideshow").length != 0){
						errorTxt = "Watch the video to progress";
					}

					$(".errorText").html(errorTxt);

					//$(".errorPrompt").appendTo( $(clicked).parents(".nextPageBlock") );
					$(".errorPrompt").fadeIn().delay(4000).fadeOut();


				}

					

			});
			
			//frontend module code starts here
			$( ".nextPageBlock,.prevPageBlock" ).on( "click", function(event) {
				console.log("nextpageblock click "+scrolling);

				if($(this).hasClass("is-disabled") || scrolling){
					return false;
				}

				scrolling = true;

				console.log("hide error prompt");
				$(".errorPrompt").hide();

				$('#currentPageBlock audio,#currentPageBlock video').each(function(){

					console.log("has audio");

					//ie 8 flash version
					if(  $(this).prev().attr('id') == "me_flash_0_container"){

						console.log("is flash container");

					if(this.player){
						//console.log("1");
						this.player.pause();
					}
					}

					if(this.pause){
						//console.log(this);
						this.pause(); // Stop playing
					}
					if(this.currentTime){
						this.currentTime = 0; // Reset time
					}
				});
				
				var scrollTime = 1000;
				/*if($(this).hasClass("nextPageBlockInstant")){
					console.log("TIME 0");
					scrollTime = 0;
				}*/
				
				var currentPageBlock = $("#currentPageBlock"); //$( ".pageBlock:visible" ).last();
				console.log("prev page block num: "+currentPageBlock.attr("data-pageNum"));
				//currentPageBlock.css({'height': "auto"});
				
				//complete the section you were on
				var preId = $("body").attr("data-pre-id") || 1;
				//console.log(preId);
				var prevPageNum = currentPageBlock.attr("data-pageNum");
				//console.log(prevPageNum);
				var pageId = parseInt(preId + prevPageNum);
				var currentPageNum;
				if($(this).hasClass("prevPageBlock")){
					currentPageNum = parseInt(prevPageNum)-1;
				}else{
				 	currentPageNum = parseInt(prevPageNum)+1;
				}
				var currentPageId = preId + "" + currentPageNum;
				console.log("complete page: "+pageId);
				window.bazingaApp.models.navigation.setPageCompletion("completed",pageId);

				//update menu
				if($(this).hasClass("nextPageBlock")){
				$("#js-dropdown li:nth-child("+prevPageNum+") a").addClass("is-completed");
				$("#js-dropdown li:nth-child("+currentPageNum+") a").removeClass("is-disabled").removeAttr("disabled").attr("aria-disabled","false").attr("data-goto",currentPageId);

				//if next page is static, complete it
				console.log("check... "+currentPageNum);
				if($("[data-pageNum='"+currentPageNum+"']").hasClass("nonePageBlock")){
					console.log(currentPageNum+" nonePageBlock");
						$("#js-dropdown li:nth-child("+currentPageNum+") a").addClass("is-completed");
				}

				}

				//console.log("last page block:");
				//console.log(currentPageBlock);
				
				var newCurrentPageBlock = currentPageBlock.next();
				
				if($(this).hasClass("prevPageBlock")){
					newCurrentPageBlock = currentPageBlock.prev();
				}

				//console.log("checking current page block:");
				//console.log(newCurrentPageBlock);
				
				/*if(!newCurrentPageBlock.hasClass("pageBlock")){
					console.log("not pageBlock, go next");
					newCurrentPageBlock = newCurrentPageBlock.next();
				}
				
				if(newCurrentPageBlock.attr("data-pageNum") == undefined){
						console.log("no pageNum, revert to old pageBlock");
						newCurrentPageBlock = currentPageBlock;
				};*/
				
				if(initScroll){
					newCurrentPageBlock = $( ".pageBlock:visible" ).last();
					initScroll = false;
				}
				
				newCurrentPageBlock.show();

				//if current page has no interactions or going back, unlock next

					console.log("checking completion "+currentPageId +":"+window.bazingaApp.models.api.getPageCompletion(currentPageId));

					

				if(newCurrentPageBlock.hasClass("nonePageBlock") || $(this).hasClass("prevPageBlock") || window.bazingaApp.models.api.getPageCompletion(currentPageId) =="c"){
					console.log("unlock next");
					setTimeout(function(){ self.unlockNext(); }, 1000);
					
				}else{
					setTimeout(function(){ $(".dummyNext").show(); }, 1000);
					
				}

				//reset popups
				newCurrentPageBlock.find("[data-reveal-target='popbox']").hide();

				if(!newCurrentPageBlock.hasClass("hideAllPopups")){
				newCurrentPageBlock.find("[data-reveal-target='popbox']:first-child").show();
				}

				if($(this).hasClass("prevPageBlock")){
				$('html,body').animate({
        			scrollTop: $("#currentPageBlock").offset().top},
        			0,function(){
        				//
					});
				};
				
				var currentPageNum = newCurrentPageBlock.attr("data-pageNum");
				
				var newPageId = parseInt(preId + currentPageNum);
				window.bazingaApp.models.api.setLessonLocation(newPageId); //set current page to new section that you scrolled to
				
				console.log("new currentPageNum "+currentPageNum);
				
				window.bazingaApp.models.navigation.setParam4(currentPageNum);
				console.log("p4 is now: "+window.bazingaApp.models.navigation.getParam4());

				$(".pageBlock").removeAttr('id');

				$("[data-pageNum="+currentPageNum +"]").attr('id', 'currentPageBlock');

				//console.log(document.getElementById("currentPageBlock").scrollHeight+"/"+$("#currentPageBlock").css('height'));

				//self.checkNextBtnPos();
				
				if( $("[data-pageNum="+currentPageNum +"]").length > 0 ){

					$(".prevPageBlock img,.nextPageBlock img").fadeOut("fast");
					scrolling = true;
				$('html,body').animate({
        			scrollTop: $("[data-pageNum="+currentPageNum +"]").offset().top},
        			scrollTime,function(){
					
					//weird hack for ipad
					$(".pageBlock:not(#currentPageBlock)").css('opacity', '0');

					setTimeout(function(){
					$(".pageBlock:not(#currentPageBlock)").hide().css('opacity', '100');
					}, 0);

					$(".prevPageBlock img,.nextPageBlock img").fadeIn("fast");

					$("#currentPageBlock .mejs-container").fadeIn("fast");

					//console.log("page "+$("#currentPageBlock").attr("data-pageNum")+"/"+$(".pageBlock").length);

					if(parseInt($("#currentPageBlock").attr("data-pageNum")) == $(".pageBlock").length){

						console.log("last page, complete");
						window.bazingaApp.models.api.setCourseStatus("completed");

						//complete the section you were on
						var preId = $("body").attr("data-pre-id");
						var prevPageNum = $("#currentPageBlock").attr("data-pageNum");
						var pageId = parseInt(preId + prevPageNum);
						
						setTimeout(function(){  

						console.log("complete last page: "+pageId);
						window.bazingaApp.models.navigation.setPageCompletion("completed",pageId);

						}, 3000);

					}

					scrolling = false;
					$(window).trigger('resize');

					});
				}
				
				
			});
			
			//end nextpageblock onclick
			
			/*setTimeout(function() {
			if(pageNum == 1){
				
				try {
					console.log("pagenum is 1. autoplay audio");
				$("[data-pageNum='1'] audio:not(.manualPlay)")[0].play();
				//$("[data-pageNum='1'] audio")[0].play();
					
				}catch(err) {
    					console.log("error: pagenum is 1. but no audio");
						}
			}else{
				console.log("pagenum is "+pageNum+". go to it");
				initScroll = true;
				$( ".nextPageBlock" ).trigger( "click" );
			}
			},1000);*/
		
			//when audio finishes
			
			$(".finishUnlockNext").bind('ended', function(){
				// done playing
				console.log("audio finished");
				self.unlockNext();
			});

			$(".clickUnlockNext,.mejs-play,.mejs-video").on( "click touchend", function(event) {

				console.log("play button");

				if(!$(this).hasClass("is-disabled") || $(this).hasClass("is-submitted")){
				self.unlockNext();
				}
			});

			$("[type='submit']").on( "click touchend", function(event) {
				self.checkNextBtnPos();
			});

			/*$(".pageBlock").scroll(function(){
				self.checkNextBtnPos();
			});*/

			$("#menuBtn,.navCloseBtn").on( "click", function(event) {
				$("#navOverlay").fadeToggle();
			});

			$(".focusBtn").on( "click", function(event) {
				var obj = $(this).attr("data-focus");
				$(obj).focus();
			});

			//instant submit checkboxes

			$(".checkbox[type='submit']").on( "click touchend", function(event) {
				//console.log("instant submit");
				$(this).parents(".questionContainer").find(".checkbox-controls [type='submit']").trigger("click");
			});

			//accordion 
			$(".panel-heading").on( "click touchend", function(event) {
				//self.checkNextBtnPos();

				var accordion = $(this).parent().parent();

				//console.log(accordion.find(".is-visited").length+"/"+accordion.find(".panel").length);

				//check if complete
				if(accordion.find(".panel").length == accordion.find(".is-visited").length){
					self.unlockNext();
				}

			});

			//popups

			$("[data-reveal-type]").on( "click touchend", function(event) {
				//self.checkNextBtnPos();

				//var btnContainer = $(this).parents();

				console.log($("#currentPageBlock").find("[data-reveal-type]:not(.closeBtn):visible").length+"/"+$("#currentPageBlock").find("[data-reveal-type].is-visited:visible").length);

				//check if complete
				if($("#currentPageBlock").find("[data-reveal-type]:not(.closeBtn):visible").length == $("#currentPageBlock").find("[data-reveal-type].is-visited:visible").length){
					self.unlockNext();
				}

			});

			//carousel
			$(".carousel-control,[data-target='#carousel']").on( "click touchend", function(event) {
				console.log(".carousel-control");
				setTimeout(function(){
					if($(".nextContainer").hasClass("is-disabled")) {

						self.unlockNext();
					}
				}, 1000);
	
				});

			/*$(".finishPlay").bind('ended', function(){
				// done playing
				$(this).closest( ".pageBlock" ).find(".vidEndHide").hide();
				$(this).closest( ".pageBlock" ).find(".vidEndShow").show();
				
				$(window).trigger('resize');
				
				try {
				$(".vidEndShow:visible audio:not(.manualPlay)")[0].play();
					console.log("vid ended, play audio");
				}catch(err) {
    					console.log("vid ended, no audio");
						}
				
			});*/
			
			/*$(".carousel-audio").bind('ended', function(){
				// done playing
				//console.log("audio finished, show next");
				
				$(".right.carousel-control").show();
				
			});
			
			$(".feedback-audio").bind('ended', function(){
				// done playing
				console.log("feedback audio finished, show next");
				
				$(".feedback:visible .nextPageBlockInstant").show();
				
			});*/
			
			$(window).trigger('resize');
			
			//carousel
			
			/*$(".carousel-control").on( "click", function(event) {
				
				$(".right.carousel-control").hide();
				
						$('audio').each(function(){
						this.pause(); // Stop playing
							if(this.currentTime){
						this.currentTime = 0; // Reset time
							}
					});
				
				setTimeout(function() {
					$(window).trigger('resize');
				try {
				$(".carousel-inner .item.active audio:not(.manualPlay)")[0].play();
					console.log("autoplay carousel");
				}catch(err) {
    					console.log("no audio in carousel");
						}
					}, 1000);
					
			});*/
			
			//generic checkbox autoplay audio, overridden in topic 2 because has meter
							
			/*$("[role='checkbox']").on( "touchstart click", function() {
  				//console.log("pressed");	
				
				var feedbackId = $(this).closest(".checkbox-container").attr("data-feedback-show-selector");
				
					$(window).trigger('resize');
				
				console.log("generic checkbox clicked");
					
				setTimeout(function() {
			try {
					
					$(feedbackId + "> div:visible audio")[0].play()}
					catch(err) {
    					console.log("no audio");
						}
					},1500);
				
			});*/
			
		},

		unlockNext:function(){
			$("#currentPageBlock").find(".nextPageBlock").removeClass("is-disabled").removeAttr("disabled").addClass("unlocked");
			$(".dummyNext").hide();
		},

		checkNextBtnPos:function(){
			/*if(document.getElementById("currentPageBlock").scrollHeight > parseInt($("#currentPageBlock").css('height').slice(0,-2))){
						$("#currentPageBlock").find(".nextPageBlock").addClass("relative");
				}else{
					$("#currentPageBlock").find(".nextPageBlock").removeClass("relative");
				}*/
		},
		
		checkTopicComplete:function(){
			//show all pages if complete
			//get 2nd to last page

			setTimeout(function(){
			
			console.log("check if topic complete");
			
			if($("#checkTopicComplete").hasClass("is-completed")){
				console.log("topic complete - show all");
				//$(".pageBlock").show();

				$(".nextPageBlock").removeClass("is-disabled").removeAttr("disabled");
				$(".dummyNext").remove();

			}

		}, 1000);

		},
		
		getQueryVariable: function (variable) {
                var query = window.location.search.substring(1);
                var vars = query.split("&");
                for (var i = 0; i < vars.length; i++) {
                    var pair = vars[i].split("=");
                    if (pair[0] == variable) {
                        return pair[1];
                    }
                }
                return (false);
            },

		beforeAbstractLoad: function () {
			
		},

		abstractLoads: function () {
			console.log("-----------------------------");
			//window.bazingaApp.models.navigation.setInfo('name','something');
			//console.log(window.bazingaApp.models.navigation.getInfo('name'));
			
		}
				
	});
}());
